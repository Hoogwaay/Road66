# ARZscaner - Arizona Market Scanner

## Overview

A Flask-based web application for scanning and finding arbitrage opportunities on the Arizona (arz.market) game marketplace. The app helps players find the best deals for buying and selling items across different game servers.

## Architecture

- **Backend**: Python 3.11 + Flask web framework
- **Frontend**: Vanilla HTML/CSS/JS served by Flask templates
- **No database**: Uses local JSON files for data persistence

## Key Files

- `app.py` — Main Flask application with all routes and business logic
- `run.py` — Application launcher (runs on `0.0.0.0:5000`)
- `arbitrage_engine.py` — Core arbitrage scanning logic
- `arbitrage_servers/` — 32 server-specific arbitrage modules
- `templates/index.html` — Main frontend template
- `static/` — CSS and JavaScript assets
- `inventory.json` — Persistent inventory data
- `balance.json` — Persistent balance tracking data
- `currencyrate.json` — Currency exchange rates per server

## Features

- **Scanner**: Scans inventory items against the marketplace to find best sell opportunities
- **Arbitrage**: Finds cross-server price arbitrage opportunities (buy on one server, sell on another)
- **Best Deals**: Scans all 32 servers for the top arbitrage opportunities
- **Market Search**: Search the marketplace for specific items by name
- **Inventory Management**: Add/remove items with purchase price tracking
- **Balance Tracker**: Track balance history and daily income

## Running the App

```bash
python3 run.py
```

Starts Flask development server on `0.0.0.0:5000`.

## Deployment

Configured to use Gunicorn for production:
```
gunicorn --bind=0.0.0.0:5000 --reuse-port app:app
```

## Dependencies

- Flask 3.0.3
- requests 2.32.3
- gunicorn (production server)
