# Road66 — Arizona Scanner v3.0

## Overview
A web-based dashboard for monitoring arbitrage opportunities, inventory tracking, and activity logs related to the Arizona (SAMP) online game marketplace.

## Tech Stack
- **Backend:** Python 3.11 (Flask)
- **Frontend:** HTML/CSS/JavaScript (Jinja2 templates)
- **Database:** SQLite (`average_prices.db`, `sync_data.db`)
- **Data Storage:** JSON files (inventory, balance, config, logs)
- **Automation:** Lua script for in-game data collection

## Project Structure
```
.
├── Road66/
│   ├── backend/                  # Python Flask server
│   │   ├── app.py                # Main Flask application
│   │   ├── run.py                # Development server launcher
│   │   ├── arbitrage_engine.py   # Core arbitrage logic
│   │   ├── chatlog_scanner.py    # In-game chatlog → inventory parser
│   │   ├── arbitrage_servers/    # Per-server arbitrage scripts (32 servers)
│   │   ├── data/                 # Runtime state (JSON + SQLite databases)
│   │   └── requirements.txt
│   ├── frontend/                 # Static web assets served by Flask
│   │   ├── templates/            # Jinja2 templates (index.html, landing.html)
│   │   └── static/               # CSS, JS, images, uploads
│   ├── lua/                      # In-game Lua automation script
│   │   └── road66.lua
│   └── pyproject.toml            # Python project metadata
└── replit.md
```

The Flask app in `Road66/backend/app.py` is configured with `template_folder` and `static_folder` pointing to the sibling `frontend/` directory.

## Running the App
- Development: `cd Road66 && python backend/run.py` (port 5000, host 0.0.0.0) — managed by the `Start application` workflow.
- Production: `cd Road66 && gunicorn --bind=0.0.0.0:5000 --reuse-port --workers=1 --timeout=120 --chdir backend app:app`

## Replit Environment Setup
- Python 3.11 runtime configured; dependencies (`flask`, `gunicorn`, `requests`) installed.
- Workflow `Start application` runs `cd Road66 && python backend/run.py`, listens on port 5000, output type `webview`.
- Flask binds `0.0.0.0:5000` — works with the Replit iframe preview as-is.
- Deployment target: VM (always-running, uses background threads + SQLite state).

## Key Features
- Arbitrage scanner across multiple game servers
- Real-time price scanning and average price tracking
- Inventory management with buy/sell tracking
- Balance history and trade log (via Lua sync)
- User authentication with admin/basic/pro/free plans
- Arizona in-game map integration
- Admin section toggle panel (enable/disable sections for all users)
