# Road66 — Arizona Scanner v3.0

## Overview
A web-based dashboard for monitoring arbitrage opportunities, inventory tracking, and activity logs related to the Arizona (SAMP) online game marketplace.

## Tech Stack
- **Backend:** Python 3.11 (Flask)
- **Frontend:** HTML/CSS/JavaScript (Jinja2 templates)
- **Database:** SQLite (`average_prices.db`, `sync_data.db`)
- **Data Storage:** JSON files (inventory, balance, config, logs)
- **Automation:** Lua script for in-game data collection

## Project Structure
```
.
├── backend/                  # Python Flask server
│   ├── app.py                # Main Flask application
│   ├── run.py                # Development server launcher
│   ├── arbitrage_engine.py   # Core arbitrage logic
│   ├── chatlog_scanner.py    # In-game chatlog → inventory parser
│   ├── arbitrage_servers/    # Per-server arbitrage scripts (32 servers)
│   ├── data/                 # Runtime state (JSON + SQLite databases)
│   └── requirements.txt
├── frontend/                 # Static web assets served by Flask
│   ├── templates/            # Jinja2 templates (index.html, landing.html)
│   └── static/               # CSS, JS, images, uploads
├── lua/                      # In-game Lua automation script
│   └── road66.lua
├── pyproject.toml            # Python project metadata
└── replit.md
```

The Flask app in `backend/app.py` is configured with `template_folder` and `static_folder` pointing to the sibling `frontend/` directory, and `/download/road66.lua` serves the script from the `lua/` directory.

## Running the App
- Development: `python backend/run.py` (port 5000, host 0.0.0.0) — managed by the `Start application` workflow.
- Production: `cd backend && gunicorn --bind=0.0.0.0:5000 --reuse-port --workers=1 --timeout=120 app:app`

## Replit Environment Setup (April 28, 2026)
- Imported from a Github archive. The project was nested under a `Road66/` folder; contents were lifted to the repo root.
- Python 3.11 runtime configured via `pyproject.toml`; dependencies (`flask`, `gunicorn`, `requests`) installed into the workspace virtualenv.
- Workflow `Start application` runs `python backend/run.py`, listens on port 5000, output type `webview`.
- Flask binds `0.0.0.0:5000` (proxy-friendly) — works with the Replit iframe preview as-is.
- Deployment target: VM (always-running, uses background threads + SQLite state).

## Frontend UI (Premium Redesign — May 2026)
- CSS v=14, Tailwind CDN included (preflight disabled — used for utility classes only)
- Deep dark palette: `--bg-base #06060E`, `--bg-surface #0B0B1A`, `--bg-card #0D0D1E`
- Ambient radial glows: 1200px purple top-left, 1000px purple-to-pink bottom-right
- Glassmorphism via `backdrop-filter: blur()` on all cards, sidebar, topbar, modals (32 uses)
- `--radius-2xl: 24px` for modals; `--radius-xl: 20px` for all cards and sections
- Sidebar: deeper gradient, purple border `rgba(168,85,247,0.14)`, 4px box-shadow
- Topbar: `blur(20px)`, purple-gradient `::after` line, strong drop shadow
- `btn-primary`: gradient `#7C3AED → #A855F7 → #C084FC`, glow `0 4px 24px rgba(168,85,247,0.45)`, h=38px
- `btn-ghost`: h=38px, purple border glow on hover
- All cards (lavka, arb, stats, dash-stat, settings, market-col, etc.): `border-radius-xl`, glassmorphism, `translateY(-1px)` hover lift
- Modals + logout modal: glassmorphism `rgba(11,11,28,0.92)`, `blur(28px)`, purple border, deep shadow
- Colored stat cards (green/cyan/amber): colored border + background tint + text-shadow glow
- Table headers: dark bg `rgba(10,10,22,0.90)`, purple-tinted bottom border
- Filter inputs + market search: `rgba(9,9,26,0.70)` bg, purple focus ring
- Status bar: purple-tinted border, backdrop-filter
- Rate pills: glass bg, purple border glow on hover

## Key Features
- Arbitrage scanner across multiple game servers
- Real-time price scanning and average price tracking
- Inventory management with buy/sell tracking
- Balance history and trade log (via Lua sync)
- User authentication with admin/basic/pro/free plans
- Arizona in-game map integration (GPU-accelerated via `will-change: transform`)
- Admin section toggle panel (enable/disable sections for all users)
- Blocked-account session polling: frontend checks `/api/me` every 60s, redirects to landing if blocked/401

## In-game Lua panel (lua/road66.lua)
- Toggle window with `/r66` chat command **or** the global hotkey **CTRL+N** (EN layout) / **CTRL+T** (RU layout). Hotkey input is ignored while the SAMP chat or a SAMP dialog is active.
- Window opens floating (centered, fixed size). Topbar has a **Развернуть/Свернуть** button to switch between floating and fullscreen modes. ESC no longer closes the window.
- Tabs implemented in-game: **Арбитраж** (auto-scans on open + on tab activation, header shows "N связок - Brand → Brand" with HH:MM:SS countdown timer right-aligned), **Рынок** (search + server combo + buy/sell columns), **Топ сделки** (cross-server best deals scan).
- Backend endpoints used by the panel: `/api/sync/arbitrage`, `/api/sync/servers`, `/api/sync/market`, `/api/sync/top`, `/api/sync/top/scan` (all auth via `X-API-Key`).
- Note: the in-game ImGui font does not render some Unicode glyphs (`→`, `•`); the Lua UI uses ASCII fallbacks (`->`, `-`).
- **Visual identity (ROUTE66 · MARKET mockup, April 2026):** purple-on-very-dark palette — bg `#080a12`, accents `#a855f7` / `#c084fc`, text `#e8eaf6`, semantic green `#22c55e` / red `#f43f5e`. Topbar shows the hex `66` logo, ROUTE66/MARKET text, a center "Торговая аналитика" tag, status pill, outlined "Развернуть/Свернуть" button and a red-tinted close button. Sidebar footer carries Состояние + Версия rows and a shimmering purple progress bar.

## In-game Lua panel — CEF version (lua/road66cef.lua + lua/road66_cef/)
- Alternative renderer using embedded Chromium (mod_cef) instead of mimgui — same backend, same hotkeys, same protocol, but full HTML/CSS/JS UI for "pretty" rendering on stronger PCs.
- Files: `lua/road66cef.lua` (orchestrator + JS↔Lua bridge), `lua/road66_cef/{index.html,style.css,app.js}` (panel UI). Resources should be deployed to `moonloader/resource/road66_cef/`.
- Requires `mod_cef.asi` runtime + `lib/cef.lua` wrapper. CEF API differences are absorbed by a small `Browser` shim at the top of `road66cef.lua` (handles `cef.create`/`cef.new`/`cef.CreateBrowser` variants).
- Hotkey CTRL+N or chat `/r66cef` toggles the panel. Settings stored in `config/road66cef_config.json`.
- JS↔Lua bridge: Lua pushes via `browser:execute('window.r66.dispatch(...)')`, JS sends events via `window.cef.call(name, payload)` (with fallbacks for `cef.send`, `cefQuery`, `external.notify`).
- Same purple ROUTE66 aesthetic as the mimgui version, with native HTML perks (web fonts, gradients, smooth animations, sticky topbar via real CSS `position:sticky`).
