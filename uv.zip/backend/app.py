import requests
import threading
import time
import json
import os
import uuid
import string
import random
import secrets
import smtplib
import ssl
import sqlite3
import stripe as stripe_lib
from collections import defaultdict
from datetime import datetime, date, timedelta
from email.message import EmailMessage
from email.utils import formataddr
from functools import wraps
from flask import Flask, render_template, request, jsonify, make_response, session, redirect, url_for, send_from_directory

from arbitrage_engine import scan_arbitrage_for_server, fetch_lavki, fetch_items_db, scan_best_deals, _calc_profit

PROJECT_ROOT  = os.path.abspath(os.path.dirname(__file__))
REPO_ROOT     = os.path.abspath(os.path.join(PROJECT_ROOT, os.pardir))
DATA_DIR      = os.path.join(PROJECT_ROOT, 'data')
FRONTEND_DIR  = os.path.join(REPO_ROOT, 'frontend')
LUA_DIR       = os.path.join(REPO_ROOT, 'lua')

os.makedirs(DATA_DIR, exist_ok=True)

app = Flask(
    __name__,
    template_folder=os.path.join(FRONTEND_DIR, 'templates'),
    static_folder=os.path.join(FRONTEND_DIR, 'static'),
)
app.secret_key = 'route66-market-secret-key-2024'

INVENTORY_FILE    = os.path.join(DATA_DIR, "inventory.json")
BALANCE_FILE      = os.path.join(DATA_DIR, "balance.json")
CURRENCY_FILE     = os.path.join(DATA_DIR, "currencyrate.json")
CREDS_FILE        = os.path.join(DATA_DIR, "Data_Cred.json")
LOG_FILE          = os.path.join(DATA_DIR, "activity_log.json")
MAP_CACHE_FILE    = os.path.join(DATA_DIR, "arizona_map_cache.json")
TRASH_MAP_FILE    = os.path.join(DATA_DIR, "trash_map.json")
AVTOMARKET_FILE   = os.path.join(DATA_DIR, "avtomarket.json")
AVERAGE_PRICES_DB = os.path.join(DATA_DIR, "average_prices.db")
SYNC_DB           = os.path.join(DATA_DIR, "sync_data.db")
ITEMS_URL       = "https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items"
MARKETPLACE_URL = "https://api.arz.market/api/getSelectedMarketplace/-1"
SELL_COMMISSION = 0.91
PRICE_SCAN_INTERVAL = 1800

PLAN_SCAN_COOLDOWN = {
    'free':  3600,
    'basic': 1800,
    'pro':   0,
}

# In-memory scan cooldown tracking: {username: timestamp}
scan_last_time     = {}
scan_last_time_lock = threading.Lock()
price_scan_lock = threading.Lock()
price_scanner_started = False


# ─── Currency rates ────────────────────────────────────────────────────────────

def load_currency_rates():
    try:
        with open(CURRENCY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return {s['id']: s for s in data['servers']}
    except Exception:
        return {}

CURRENCY_RATES = load_currency_rates()


# ─── Activity log ─────────────────────────────────────────────────────────────

def write_log(username, action, details=''):
    try:
        log = []
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                log = json.load(f)
        log.append({
            'time':     datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'username': username,
            'action':   action,
            'details':  details,
            'ip':       request.remote_addr if request else '',
        })
        log = log[-2000:]
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(log, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ─── Credentials ──────────────────────────────────────────────────────────────

def load_creds():
    try:
        with open(CREDS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'users': [], 'activation_codes': []}


def save_creds(creds):
    with open(CREDS_FILE, 'w', encoding='utf-8') as f:
        json.dump(creds, f, ensure_ascii=False, indent=2)


def get_user_from_session():
    username = session.get('username', '')
    if not username:
        return None
    creds = load_creds()
    return next((u for u in creds.get('users', []) if u.get('username') == username), None)


def get_effective_plan(user):
    if not user:
        return 'free'
    if user.get('role') == 'admin':
        return 'pro'
    plan = user.get('plan', 'free')
    expires = user.get('plan_expires')
    if plan in ('basic', 'pro') and expires:
        try:
            exp_dt = datetime.fromisoformat(expires)
            if datetime.now() > exp_dt:
                return 'free'
        except Exception:
            pass
    return plan


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect('/')
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return jsonify({'success': False, 'error': 'Not logged in'}), 401
        user = get_user_from_session()
        if not user or user.get('role') != 'admin':
            return jsonify({'success': False, 'error': 'Forbidden'}), 403
        return f(*args, **kwargs)
    return decorated


@app.before_request
def _enforce_account_status():
    if not session.get('logged_in'):
        return None
    if request.endpoint == 'static':
        return None
    user = get_user_from_session()
    if user is None:
        session.clear()
        if request.path.startswith('/api/'):
            return jsonify({'success': False, 'error': 'Сессия завершена'}), 401
        return redirect('/')
    if user.get('blocked', False):
        username = session.get('username', '')
        session.clear()
        if request.path.startswith('/api/'):
            return jsonify({'success': False, 'error': 'Аккаунт заблокирован администратором', 'blocked': True}), 403
        return redirect('/')


# ─── Section availability (admin-controlled) ──────────────────────────────────

SECTIONS_FILE = os.path.join(DATA_DIR, "sections.json")
DEFAULT_SECTIONS = {
    'scanner':         True,
    'arbitrage':       True,
    'market':          True,
    'average-prices':  True,
    'bestdeals':       True,
    'dashboard':       True,
    'favorites':       True,
    'avtomarket':      True,
    'arizona-map':     True,
}

def load_sections():
    try:
        if os.path.exists(SECTIONS_FILE):
            with open(SECTIONS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return {**DEFAULT_SECTIONS, **(data or {})}
    except Exception:
        pass
    return dict(DEFAULT_SECTIONS)

def save_sections(data):
    safe = {k: bool(data.get(k, True)) for k in DEFAULT_SECTIONS}
    with open(SECTIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump(safe, f, ensure_ascii=False, indent=2)
    return safe


# ─── Scan cooldown helpers ────────────────────────────────────────────────────

def check_scan_cooldown(username, plan, scan_type='scanner'):
    cooldown = PLAN_SCAN_COOLDOWN.get(plan, 3600)
    if cooldown == 0:
        return True, 0
    key = f"{username}:{scan_type}"
    with scan_last_time_lock:
        last = scan_last_time.get(key, 0)
    elapsed = time.time() - last
    if elapsed >= cooldown:
        return True, 0
    remaining = int(cooldown - elapsed)
    return False, remaining


def mark_scan_done(username, scan_type='scanner'):
    key = f"{username}:{scan_type}"
    with scan_last_time_lock:
        scan_last_time[key] = time.time()


# ─── Arbitrage state (keyed by "buy_sell") ────────────────────────────────────

arb_cache      = {}
arb_cache_lock = threading.Lock()

bd_cache      = {'deals': [], 'status': 'Нажмите «Скан»', 'last_update': None, 'timestamp': None}
bd_cache_lock = threading.Lock()

def get_bd_state():
    with bd_cache_lock:
        return dict(bd_cache)

def set_bd_state(state):
    global bd_cache
    with bd_cache_lock:
        bd_cache = state

def arb_key(buy, sell):
    return f"{buy}_{sell}"

def get_arb_state(buy, sell):
    with arb_cache_lock:
        return dict(arb_cache.get(arb_key(buy, sell), {
            'deals': [], 'status': 'Нажмите «Скан»', 'last_update': None, 'timestamp': None
        }))

def set_arb_state(buy, sell, state):
    with arb_cache_lock:
        arb_cache[arb_key(buy, sell)] = state


# ─── Scanner state ────────────────────────────────────────────────────────────

scanner_data = None
scanner_lock = threading.Lock()

auto_scanner_running   = False
auto_arbitrage_running = False
auto_bd_running        = False
auto_arb_buy  = 2
auto_arb_sell = 0


# ─── Inventory ────────────────────────────────────────────────────────────────

def load_inventory():
    if not os.path.exists(INVENTORY_FILE):
        return {}
    try:
        with open(INVENTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def get_items_data_from_json():
    inventory = load_inventory()
    items_data = []
    for item_name, data in inventory.items():
        total_qty = data.get('qty', 0)
        entries   = data.get('entries', [])
        if total_qty <= 0 or not entries:
            continue
        total_cost = sum(e.get('qty', 0) * e.get('price_per_unit', 0) for e in entries)
        avg_price  = total_cost / total_qty if total_qty > 0 else 0
        min_sell   = min((e.get('price_per_unit', 0) for e in entries), default=0)
        min_sell   = int(min_sell * 1.1) if min_sell > 0 else 0
        items_data.append({
            'name':              item_name,
            'quantity':          total_qty,
            'buy_price':         int(total_cost),
            'buy_price_per_unit':int(avg_price),
            'min_sell_price':    min_sell,
            'entries':           entries,
        })
    return items_data


def get_inventory_summary():
    inventory = load_inventory()
    items_meta = get_items_meta_by_name()
    items_list, total_items, total_cost = [], 0, 0
    for item_name, data in inventory.items():
        qty = data.get('qty', 0)
        if qty > 0:
            cost = sum(e.get('qty', 0) * e.get('price_per_unit', 0) for e in data.get('entries', []))
            meta = items_meta.get(item_name.strip().lower(), {})
            item_id = meta.get('id')
            items_list.append({
                'name': item_name,
                'qty': qty,
                'total_cost': int(cost),
                'item_id': item_id,
                'image_url': f'https://pc.az-ins.com/resource/image/donate/{item_id}.png' if item_id else '',
                'description': meta.get('description') or meta.get('desc') or meta.get('category') or 'Описание предмета пока не добавлено.',
                'avg_price': int(cost / qty) if qty else 0,
            })
            total_items += qty
            total_cost  += cost
    return {'items': items_list, 'total_items': total_items,
            'total_cost': int(total_cost), 'item_types': len(items_list)}


def get_items_meta_by_name():
    try:
        items = fetch_with_retry(ITEMS_URL, retries=1, timeout=6)
        return {
            item.get('name', '').strip().lower(): item
            for item in items
            if item.get('name')
        }
    except Exception:
        return {}


# ─── Balance ──────────────────────────────────────────────────────────────────

def load_balance():
    if not os.path.exists(BALANCE_FILE):
        return []
    try:
        with open(BALANCE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []

def save_balance(records):
    with open(BALANCE_FILE, 'w', encoding='utf-8') as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


# ─── Fetch helper ─────────────────────────────────────────────────────────────

def fetch_with_retry(url, retries=3, timeout=15):
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except Exception:
            pass
        if attempt < retries:
            time.sleep(min(2 ** attempt, 10))
    return []


def get_price_db():
    conn = sqlite3.connect(AVERAGE_PRICES_DB, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init_average_prices_db():
    with get_price_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS price_items (
                item_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS price_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                captured_at TEXT NOT NULL,
                day TEXT NOT NULL,
                server_id INTEGER NOT NULL,
                item_id INTEGER NOT NULL,
                item_name TEXT NOT NULL,
                max_buy_price INTEGER,
                min_sell_price INTEGER
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_price_snapshots_server_day ON price_snapshots(server_id, day)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_price_snapshots_item ON price_snapshots(server_id, item_id, captured_at)")


# ─── Sync DB (balance + trades from Lua) ──────────────────────────────────────

def get_sync_db():
    conn = sqlite3.connect(SYNC_DB, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init_sync_db():
    with get_sync_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS balance_history (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                username  TEXT NOT NULL,
                balance   INTEGER NOT NULL,
                ts        TEXT NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_bh_username_ts ON balance_history(username, ts)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS trade_log (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                username  TEXT NOT NULL,
                action    TEXT NOT NULL,
                item      TEXT NOT NULL DEFAULT '',
                quantity  INTEGER NOT NULL DEFAULT 0,
                price     INTEGER NOT NULL DEFAULT 0,
                total     INTEGER NOT NULL DEFAULT 0,
                ts        TEXT NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tl_username_ts ON trade_log(username, ts)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS commands_queue (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                username  TEXT NOT NULL,
                command   TEXT NOT NULL,
                ts        TEXT NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cq_username_id ON commands_queue(username, id)")


def push_command_for_user(username, command):
    if not username or not command:
        return False
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with get_sync_db() as conn:
        conn.execute(
            "INSERT INTO commands_queue (username, command, ts) VALUES (?, ?, ?)",
            (username, command, ts)
        )
        # cap queue size per user
        conn.execute(
            "DELETE FROM commands_queue WHERE id IN (SELECT id FROM commands_queue WHERE username=? ORDER BY id DESC LIMIT -1 OFFSET 50)",
            (username,)
        )
    return True


def pop_command_for_user(username):
    if not username:
        return None
    with get_sync_db() as conn:
        row = conn.execute(
            "SELECT id, command, ts FROM commands_queue WHERE username=? ORDER BY id ASC LIMIT 1",
            (username,)
        ).fetchone()
        if not row:
            return None
        conn.execute("DELETE FROM commands_queue WHERE id=?", (row['id'],))
        return {'command': row['command'], 'ts': row['ts']}


def get_user_by_api_key(api_key):
    creds = load_creds()
    for u in creds.get('users', []):
        if u.get('api_key') == api_key:
            return u
    return None


def generate_api_key():
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=24))


def ensure_api_keys():
    creds = load_creds()
    changed = False
    for u in creds.get('users', []):
        if not u.get('api_key'):
            u['api_key'] = generate_api_key()
            changed = True
    if changed:
        save_creds(creds)


def get_sync_stats(username):
    try:
        with get_sync_db() as conn:
            row = conn.execute(
                "SELECT balance, ts FROM balance_history WHERE username=? ORDER BY ts DESC LIMIT 1",
                (username,)
            ).fetchone()
            current = dict(row) if row else None

            today_str = date.today().isoformat()
            row_today = conn.execute(
                "SELECT balance FROM balance_history WHERE username=? AND ts>=? ORDER BY ts ASC LIMIT 1",
                (username, today_str + ' 00:00:00')
            ).fetchone()
            today_start = row_today['balance'] if row_today else None

            row_first = conn.execute(
                "SELECT balance FROM balance_history WHERE username=? ORDER BY ts ASC LIMIT 1",
                (username,)
            ).fetchone()
            first_balance = row_first['balance'] if row_first else None

        current_balance = current['balance'] if current else None
        current_ts      = current['ts']      if current else None
        today_income    = (current_balance - today_start)   if (current_balance is not None and today_start is not None)   else None
        alltime_income  = (current_balance - first_balance) if (current_balance is not None and first_balance is not None) else None

        return {
            'current_balance': current_balance,
            'current_ts':      current_ts,
            'today_income':    today_income,
            'alltime_income':  alltime_income,
        }
    except Exception:
        return {'current_balance': None, 'current_ts': None, 'today_income': None, 'alltime_income': None}


def normalize_item_id(raw_id):
    try:
        return int(raw_id if isinstance(raw_id, int) else str(raw_id).split('(')[0])
    except Exception:
        return None


def sync_average_price_items():
    items = fetch_with_retry(ITEMS_URL, retries=2, timeout=15)
    if not items:
        return 0
    rows = []
    for item in items:
        try:
            item_id = int(item.get('id'))
            name = item.get('name', '').strip()
            if name:
                rows.append((item_id, name))
        except Exception:
            continue
    if not rows:
        return 0
    with get_price_db() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO price_items (item_id, name) VALUES (?, ?)",
            rows
        )
    return len(rows)


def is_average_price_scan_stale():
    try:
        with get_price_db() as conn:
            row = conn.execute("SELECT MAX(captured_at) AS last_update FROM price_snapshots").fetchone()
        if not row or not row['last_update']:
            return True
        last = datetime.fromisoformat(row['last_update'])
        return (datetime.now() - last).total_seconds() >= PRICE_SCAN_INTERVAL
    except Exception:
        return True


def collect_average_price_snapshot():
    if not price_scan_lock.acquire(blocking=False):
        return {'success': False, 'error': 'scan_running'}
    try:
        init_average_prices_db()
        sync_average_price_items()
        items_db = fetch_items_db()
        lavki = fetch_lavki()
        if not lavki:
            return {'success': False, 'error': 'Нет данных лавок'}

        stats = {}
        for lavka in lavki:
            try:
                server_id = int(lavka.get('serverId', 0))
            except Exception:
                continue

            for idx, raw_id in enumerate(lavka.get('items_buy') or []):
                item_id = normalize_item_id(raw_id)
                if item_id is None:
                    continue
                try:
                    price = int(float((lavka.get('price_buy') or [])[idx]))
                except Exception:
                    continue
                key = (server_id, item_id)
                rec = stats.setdefault(key, {'max_buy_price': None, 'min_sell_price': None})
                if rec['max_buy_price'] is None or price > rec['max_buy_price']:
                    rec['max_buy_price'] = price

            for idx, raw_id in enumerate(lavka.get('items_sell') or []):
                item_id = normalize_item_id(raw_id)
                if item_id is None:
                    continue
                try:
                    price = int(float((lavka.get('price_sell') or [])[idx]))
                except Exception:
                    continue
                key = (server_id, item_id)
                rec = stats.setdefault(key, {'max_buy_price': None, 'min_sell_price': None})
                if rec['min_sell_price'] is None or price < rec['min_sell_price']:
                    rec['min_sell_price'] = price

        captured_at = datetime.now().replace(microsecond=0).isoformat()
        day = date.today().isoformat()
        rows = []
        item_rows = []
        for (server_id, item_id), rec in stats.items():
            name = items_db.get(item_id, f'ID_{item_id}')
            rows.append((captured_at, day, server_id, item_id, name, rec['max_buy_price'], rec['min_sell_price']))
            if not str(name).startswith('ID_'):
                item_rows.append((item_id, name))

        with get_price_db() as conn:
            if item_rows:
                conn.executemany("INSERT OR REPLACE INTO price_items (item_id, name) VALUES (?, ?)", item_rows)
            conn.executemany("""
                INSERT INTO price_snapshots
                (captured_at, day, server_id, item_id, item_name, max_buy_price, min_sell_price)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, rows)
        return {'success': True, 'count': len(rows), 'captured_at': captured_at}
    finally:
        price_scan_lock.release()


def average_price_scanner_loop():
    init_average_prices_db()
    while True:
        try:
            if is_average_price_scan_stale():
                collect_average_price_snapshot()
        except Exception:
            pass
        time.sleep(60)


def start_average_price_scanner():
    global price_scanner_started
    if price_scanner_started:
        return
    price_scanner_started = True
    threading.Thread(target=average_price_scanner_loop, daemon=True).start()


# ─── Scanner ─────────────────────────────────────────────────────────────────

def scan_scanner():
    global scanner_data
    try:
        with scanner_lock:
            items_data_api = fetch_with_retry(ITEMS_URL, retries=3, timeout=20)
            lavki_data     = fetch_with_retry(MARKETPLACE_URL, retries=3, timeout=20)
            all_lavki      = [l for l in lavki_data if l.get('serverId') == 0]
            sheet_items    = get_items_data_from_json()

            def get_item_id_by_name(name, db):
                for item in db:
                    if item['name'].strip().lower() == name.strip().lower():
                        return item['id']
                return None

            def find_all_lavki_for_item(item_id, lavki):
                offers = []
                for lavka in lavki:
                    items_buy = lavka.get('items_buy', [])
                    price_buy = lavka.get('price_buy', [])
                    count_buy = lavka.get('count_buy', [])
                    for i, bid in enumerate(items_buy):
                        if (str(bid).split('(')[0] == str(item_id) and
                                i < len(price_buy) and i < len(count_buy) and count_buy[i] > 0):
                            offers.append({'lavka_uid': lavka['LavkaUid'],
                                           'price': price_buy[i], 'count': count_buy[i]})
                return sorted(offers, key=lambda x: x['price'], reverse=True)

            def calculate_profit(buy_price_sa_total, lavka_price_vc, quantity):
                buy_per_unit  = buy_price_sa_total // quantity if quantity > 0 else 0
                vc_after_comm = lavka_price_vc * SELL_COMMISSION
                sa_per_unit   = vc_after_comm * 107
                return int((sa_per_unit - buy_per_unit) * quantity)

            item_offers = []
            for json_item in sheet_items:
                item_id = get_item_id_by_name(json_item['name'], items_data_api)
                if item_id:
                    offers = find_all_lavki_for_item(item_id, all_lavki)
                    if offers:
                        best   = offers[0]
                        profit = calculate_profit(
                            json_item['buy_price'], best['price'], json_item['quantity'])
                        item_offers.append({
                            'name':              json_item['name'],
                            'quantity':          json_item['quantity'],
                            'buy_price':         json_item['buy_price'],
                            'buy_price_per_unit':json_item['buy_price_per_unit'],
                            'min_sell_price':    json_item['min_sell_price'],
                            'lavka_uid':         best['lavka_uid'],
                            'lavka_price':       best['price'],
                            'lavka_count':       best['count'],
                            'profit':            profit,
                            'entries':           json_item['entries'],
                        })

            lavka_item_groups = defaultdict(lambda: defaultdict(list))
            total_stats = {'total_profit': 0, 'total_items': 0,
                           'lavka_count': 0, 'item_groups': 0}
            for item in item_offers:
                lavka_item_groups[item['lavka_uid']][item['name']].append(item)
                total_stats['total_profit'] += item['profit']
                total_stats['total_items']  += 1

            total_stats['item_groups'] = sum(len(v) for v in lavka_item_groups.values())
            sorted_lavki = sorted(
                lavka_item_groups.items(),
                key=lambda x: max(i['lavka_price'] for items in x[1].values() for i in items),
                reverse=True)
            total_stats['lavka_count'] = len(sorted_lavki)
            scanner_data = (sorted_lavki, total_stats)
    except Exception:
        with scanner_lock:
            scanner_data = None


# ─── Arbitrage scan ───────────────────────────────────────────────────────────

def do_scan_arbitrage(buy_id, sell_id):
    set_arb_state(buy_id, sell_id, {
        'deals': [], 'status': '⏳ Сканирую...', 'last_update': None, 'timestamp': None
    })
    try:
        result = scan_arbitrage_for_server(buy_id, sell_id, CURRENCY_RATES)
        set_arb_state(buy_id, sell_id, result)
    except Exception as e:
        set_arb_state(buy_id, sell_id, {
            'deals': [], 'status': f'❌ {str(e)}', 'last_update': time.strftime('%H:%M:%S'), 'timestamp': None
        })


def do_scan_best_deals():
    set_bd_state({'deals': [], 'status': '⏳ Сканирую все серверы...', 'last_update': None, 'timestamp': None})
    try:
        result = scan_best_deals(CURRENCY_RATES)
        set_bd_state(result)
    except Exception as e:
        set_bd_state({'deals': [], 'status': f'❌ {str(e)}', 'last_update': time.strftime('%H:%M:%S'), 'timestamp': None})


# ─── Auto loops ───────────────────────────────────────────────────────────────

def auto_scanner_loop():
    global auto_scanner_running
    while auto_scanner_running:
        try:
            scan_scanner()
            time.sleep(30)
        except Exception:
            time.sleep(5)


def auto_arbitrage_loop():
    global auto_arbitrage_running
    while auto_arbitrage_running:
        try:
            do_scan_arbitrage(auto_arb_buy, auto_arb_sell)
            time.sleep(15)
        except Exception:
            time.sleep(5)


def auto_bd_loop():
    global auto_bd_running
    while auto_bd_running:
        try:
            do_scan_best_deals()
            time.sleep(30)
        except Exception:
            time.sleep(5)


# ─── Code generator ───────────────────────────────────────────────────────────

def generate_code():
    chars = string.ascii_uppercase + string.digits
    parts = [''.join(random.choices(chars, k=4)) for _ in range(4)]
    return '-'.join(parts)


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if session.get('logged_in'):
        return redirect('/panel')
    return render_template('landing.html')


@app.route("/panel")
@login_required
def panel():
    return render_template('index.html')


@app.route("/api/login", methods=["POST"])
def api_login():
    data     = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    ip       = request.remote_addr or ''
    creds    = load_creds()
    for user in creds.get('users', []):
        if user.get('username') == username and user.get('password') == password:
            if user.get('blocked', False):
                write_log(username, 'login_blocked', f'IP: {ip}')
                return jsonify({'success': False, 'error': 'Аккаунт заблокирован'})
            if not user.get('activated', True):
                write_log(username, 'login_not_activated', f'IP: {ip}')
                return jsonify({'success': False, 'error': 'Аккаунт не активирован. Обратитесь к администратору'})
            user['last_ip'] = ip
            save_creds(creds)
            session['logged_in'] = True
            session['username']  = username
            write_log(username, 'login', f'IP: {ip}')
            return jsonify({'success': True})
    write_log(username, 'login_fail', f'IP: {ip}')
    return jsonify({'success': False, 'error': 'Неверный логин или пароль'})


@app.route("/logout")
def logout():
    username = session.get('username', '')
    if username:
        write_log(username, 'logout')
    session.clear()
    return redirect('/')


@app.route("/api/activate", methods=["POST"])
@login_required
def api_activate():
    data     = request.json or {}
    code_val = data.get('code', '').strip().upper()
    if not code_val:
        return jsonify({'success': False, 'error': 'Код не указан'})
    username = session.get('username', '')
    creds    = load_creds()
    codes    = creds.get('activation_codes', [])
    found    = None
    for c in codes:
        if isinstance(c, dict):
            if c.get('code', '').upper() == code_val:
                found = c
                break
        elif isinstance(c, str):
            if c.upper() == code_val:
                found = {'code': c, 'plan': 'basic', 'duration_days': 30}
                break
    if not found:
        return jsonify({'success': False, 'error': 'Неверный или уже использованный код'})

    plan     = found.get('plan', 'basic')
    days     = found.get('duration_days', 30)
    expires  = (datetime.now() + timedelta(days=days)).isoformat()

    for user in creds.get('users', []):
        if user.get('username') == username:
            user['plan']         = plan
            user['plan_expires'] = expires
            break

    creds['activation_codes'] = [c for c in codes if
        (c.get('code', '').upper() if isinstance(c, dict) else c.upper()) != code_val]
    save_creds(creds)
    write_log(username, 'activate_code', f'code={code_val} plan={plan} days={days}')

    plan_names = {'free': 'Бесплатный', 'basic': 'Базовый', 'pro': 'Профи'}
    return jsonify({'success': True,
                    'message': f'Тариф «{plan_names.get(plan, plan)}» активирован на {days} дней!'})


@app.route("/api/me")
@login_required
def api_me():
    username = session.get('username', 'User')
    creds    = load_creds()
    user     = next((u for u in creds.get('users', []) if u.get('username') == username), None)
    if user:
        is_admin = user.get('role', '').lower() == 'admin'
        plan     = get_effective_plan(user)
        expires  = user.get('plan_expires')
        commission = user.get('commission', 9)
        user_server = user.get('user_server', 2)
        server_changed_at = user.get('server_changed_at')
        api_key   = user.get('api_key', '')
    else:
        is_admin = False
        plan     = 'free'
        expires  = None
        commission = 9
        user_server = 2
        server_changed_at = None
        api_key   = ''

    days_left = None
    if expires and not is_admin:
        try:
            exp_dt = datetime.fromisoformat(expires)
            days_left = max(0, (exp_dt - datetime.now()).days)
        except Exception:
            pass

    return jsonify({
        'success':          True,
        'username':         username,
        'is_admin':         is_admin,
        'plan':             plan,
        'plan_expires':     expires,
        'days_left':        days_left,
        'commission':       commission,
        'user_server':      user_server,
        'server_changed_at': server_changed_at,
        'api_key':          api_key,
    })


@app.route("/api/save_settings", methods=["POST"])
@login_required
def api_save_settings():
    data       = request.json or {}
    commission = data.get('commission')
    if commission is None:
        return jsonify({'success': False, 'error': 'Не указана комиссия'})
    try:
        commission = float(commission)
        if commission < 0 or commission > 100:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Некорректное значение'})

    username = session.get('username', '')
    creds    = load_creds()
    updated  = False
    for user in creds.get('users', []):
        if user.get('username') == username:
            user['commission'] = commission
            updated = True
            break
    if updated:
        try:
            save_creds(creds)
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': True})


@app.route("/api/save_server", methods=["POST"])
@login_required
def api_save_server():
    data      = request.json or {}
    server_id = data.get('server_id')
    if server_id is None:
        return jsonify({'success': False, 'error': 'Не указан сервер'})
    try:
        server_id = int(server_id)
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Некорректный сервер'})
    if server_id == 0:
        return jsonify({'success': False, 'error': 'Vice City нельзя выбрать как основной сервер'})

    username = session.get('username', '')
    creds    = load_creds()
    for user in creds.get('users', []):
        if user.get('username') == username:
            user['user_server']      = server_id
            user['server_changed_at'] = datetime.now().isoformat()
            save_creds(creds)
            write_log(username, 'server_change', f'server={server_id}')
            return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Пользователь не найден'})


@app.route("/api/register", methods=["POST"])
def api_register():
    data     = request.json or {}
    username = data.get('username', '').strip()
    email    = data.get('email', '').strip()
    password = data.get('password', '').strip()
    ip       = request.remote_addr or ''

    if not username or not email or not password:
        return jsonify({'success': False, 'error': 'Заполните все поля'})
    if len(username) < 3:
        return jsonify({'success': False, 'error': 'Логин минимум 3 символа'})
    if '@' not in email or '.' not in email.split('@')[-1]:
        return jsonify({'success': False, 'error': 'Некорректный email'})
    if len(password) < 6:
        return jsonify({'success': False, 'error': 'Пароль минимум 6 символов'})

    creds = load_creds()
    for u in creds.get('users', []):
        if u.get('username', '').lower() == username.lower():
            return jsonify({'success': False, 'error': 'Этот логин уже зарегистрирован.'})
        if u.get('email', '').lower() == email.lower():
            return jsonify({'success': False, 'error': 'Эта почта уже зарегистрирована.'})

    new_user = {
        'username':         username,
        'email':            email,
        'password':         password,
        'role':             'user',
        'plan':             'free',
        'plan_expires':     None,
        'commission':       9,
        'user_server':      2,
        'reg_date':         datetime.now().isoformat(),
        'reg_ip':           ip,
        'last_ip':          ip,
        'server_changed_at': None,
        'activated':        True,
        'blocked':          False,
        'api_key':          generate_api_key(),
    }
    creds.setdefault('users', []).append(new_user)
    try:
        save_creds(creds)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

    write_log(username, 'register', f'email={email} IP={ip}')
    return jsonify({'success': True, 'email': email})


# ─── Email helper (SMTP) ───────────────────────────────────────────────────────
def _smtp_config():
    """Return (host, port, user, password, from_email, from_name) or None if not configured."""
    host = os.environ.get('SMTP_HOST', '').strip()
    user = os.environ.get('SMTP_USER', '').strip()
    pwd  = os.environ.get('SMTP_PASSWORD', '').strip()
    if not host or not user or not pwd:
        return None
    try:
        port = int(os.environ.get('SMTP_PORT', '587'))
    except ValueError:
        port = 587
    from_email = os.environ.get('SMTP_FROM', user).strip() or user
    from_name  = os.environ.get('SMTP_FROM_NAME', 'Road66').strip() or 'Road66'
    return host, port, user, pwd, from_email, from_name


def send_email(to_email: str, subject: str, body_text: str, body_html: str | None = None) -> bool:
    """Send an email via configured SMTP. Returns True on success, False otherwise."""
    cfg = _smtp_config()
    if not cfg:
        print("[EMAIL] SMTP not configured (set SMTP_HOST / SMTP_USER / SMTP_PASSWORD)")
        return False
    host, port, user, pwd, from_email, from_name = cfg

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From']    = formataddr((from_name, from_email))
    msg['To']      = to_email
    msg.set_content(body_text)
    if body_html:
        msg.add_alternative(body_html, subtype='html')

    try:
        if port == 465:
            ctx = ssl.create_default_context()
            with smtplib.SMTP_SSL(host, port, context=ctx, timeout=20) as s:
                s.login(user, pwd)
                s.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=20) as s:
                s.ehlo()
                try:
                    s.starttls(context=ssl.create_default_context())
                    s.ehlo()
                except Exception:
                    pass
                s.login(user, pwd)
                s.send_message(msg)
        return True
    except Exception as e:
        print(f"[EMAIL] send to {to_email} failed: {e}")
        return False


def _generate_password(length: int = 12) -> str:
    """Generate a secure random Latin password (letters + digits)."""
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


# ─── Forgot password ───────────────────────────────────────────────────────────
@app.route("/api/forgot_password", methods=["POST"])
def api_forgot_password():
    data  = request.json or {}
    email = (data.get('email') or '').strip().lower()
    ip    = request.remote_addr or ''

    if not email or '@' not in email:
        return jsonify({'success': False, 'error': 'Укажите корректный email'})

    creds = load_creds()
    user  = None
    for u in creds.get('users', []):
        if (u.get('email') or '').strip().lower() == email:
            user = u
            break

    # Always pretend success so we don't leak which emails exist.
    if not user:
        write_log('-', 'forgot_password', f'unknown email={email} IP={ip}')
        return jsonify({'success': True})

    if not _smtp_config():
        write_log(user.get('username', '-'), 'forgot_password',
                  f'SMTP not configured, cannot send to {email} IP={ip}')
        return jsonify({'success': False,
                        'error': 'Сервис почты не настроен. Обратитесь к администратору.'})

    new_pw = _generate_password(12)

    subject = 'Road66 — новый пароль для входа'
    text = (
        f"Здравствуйте, {user.get('username', '')}!\n\n"
        f"По вашему запросу мы сбросили пароль от аккаунта Road66.\n\n"
        f"Ваш новый пароль: {new_pw}\n\n"
        f"Рекомендуем сразу после входа сменить его в личном кабинете "
        f"в разделе «Безопасность».\n\n"
        f"Если вы не запрашивали смену пароля — немедленно сообщите нам.\n\n"
        f"— Road66"
    )
    html = f"""<!doctype html>
<html><body style="font-family:Inter,Arial,sans-serif;background:#0B0F1A;color:#E6E8F2;padding:24px;">
  <div style="max-width:520px;margin:0 auto;background:#1A1535;border:1px solid rgba(200,77,255,0.18);border-radius:16px;padding:28px;">
    <h2 style="margin:0 0 12px;font-weight:600;color:#fff;">Новый пароль для Road66</h2>
    <p style="color:#B7BCD8;line-height:1.55;">Здравствуйте, <b style="color:#fff;">{user.get('username', '')}</b>!</p>
    <p style="color:#B7BCD8;line-height:1.55;">По вашему запросу мы сбросили пароль от аккаунта.</p>
    <div style="margin:20px 0;padding:16px 20px;background:#0B0F1A;border:1px solid rgba(200,77,255,0.35);border-radius:12px;font-family:'JetBrains Mono',monospace;font-size:18px;letter-spacing:2px;color:#fff;text-align:center;">{new_pw}</div>
    <p style="color:#8A90B2;font-size:13px;line-height:1.55;">Рекомендуем сразу после входа сменить его в личном кабинете в разделе «Безопасность».</p>
    <p style="color:#8A90B2;font-size:12px;margin-top:24px;">Если вы не запрашивали смену пароля — немедленно сообщите нам.</p>
  </div>
</body></html>"""

    sent = send_email(email, subject, text, html)
    if not sent:
        return jsonify({'success': False,
                        'error': 'Не удалось отправить письмо. Попробуйте позже.'})

    user['password'] = new_pw
    try:
        save_creds(creds)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

    write_log(user.get('username', '-'), 'forgot_password', f'reset OK email={email} IP={ip}')
    return jsonify({'success': True})


# ─── Change password (logged-in user) ──────────────────────────────────────────
@app.route("/api/change_password", methods=["POST"])
def api_change_password():
    if 'username' not in session:
        return jsonify({'success': False, 'error': 'Не авторизован'}), 401

    data    = request.json or {}
    old_pw  = (data.get('old_password') or '')
    new_pw  = (data.get('new_password') or '')
    new_pw2 = (data.get('new_password2') or '')
    ip      = request.remote_addr or ''
    me      = session['username']

    if not old_pw or not new_pw or not new_pw2:
        return jsonify({'success': False, 'error': 'Заполните все поля'})
    if new_pw != new_pw2:
        return jsonify({'success': False, 'error': 'Новые пароли не совпадают'})
    if len(new_pw) < 6:
        return jsonify({'success': False, 'error': 'Пароль минимум 6 символов'})
    if any(ord(c) > 127 for c in new_pw):
        return jsonify({'success': False, 'error': 'Пароль должен содержать только латинские символы'})
    if new_pw == old_pw:
        return jsonify({'success': False, 'error': 'Новый пароль совпадает со старым'})

    creds = load_creds()
    user  = None
    for u in creds.get('users', []):
        if (u.get('username') or '').lower() == me.lower():
            user = u
            break
    if not user:
        return jsonify({'success': False, 'error': 'Пользователь не найден'}), 404

    if (user.get('password') or '') != old_pw:
        write_log(me, 'change_password', f'wrong old password IP={ip}')
        return jsonify({'success': False, 'error': 'Текущий пароль введён неверно'})

    user['password'] = new_pw
    try:
        save_creds(creds)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

    write_log(me, 'change_password', f'OK IP={ip}')
    return jsonify({'success': True})


@app.route("/api/currency_rates")
def api_currency_rates():
    return jsonify({'success': True, 'rates': list(CURRENCY_RATES.values())})


@app.route("/api/scanner")
@login_required
def api_scanner():
    with scanner_lock:
        if scanner_data:
            return jsonify({'success': True, 'data': scanner_data})
        return jsonify({'success': False, 'error': 'Нет данных'})


@app.route("/api/arbitrage")
@login_required
def api_arbitrage():
    user = get_user_from_session()
    plan = get_effective_plan(user)

    # Default the BUY side to the user's selected server (user_server) when
    # the client doesn't pass explicit buy/sell args. SELL falls back to a
    # different server so we never end up with buy_id == sell_id.
    try:
        user_srv = int((user or {}).get('user_server') or 2)
    except (TypeError, ValueError):
        user_srv = 2
    user_srv = max(0, min(32, user_srv))
    default_sell = 0 if user_srv != 0 else 2

    try:
        buy_id  = int(request.args.get('buy',  user_srv))
        sell_id = int(request.args.get('sell', default_sell))
    except ValueError:
        buy_id, sell_id = user_srv, default_sell

    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))
    if buy_id == sell_id:
        sell_id = 0 if buy_id != 0 else 2

    try:
        commission_pct = float(request.args.get('commission', 9))
        commission_pct = max(0.0, min(100.0, commission_pct))
    except (ValueError, TypeError):
        commission_pct = 9.0
    commission = (100.0 - commission_pct) / 100.0

    state     = get_arb_state(buy_id, sell_id)
    buy_info  = CURRENCY_RATES.get(buy_id,  {})
    sell_info = CURRENCY_RATES.get(sell_id, {})
    sell_rate = sell_info.get('sell_rate', 1)

    deals = state.get('deals', [])
    if deals and abs(commission - 0.91) > 0.001:
        recalced = []
        for d in deals:
            try:
                profit, profit_pct, buy_cur, sell_cur = _calc_profit(
                    d['price_buy'], d['price_sell'],
                    buy_id, sell_id, buy_info, sell_info,
                    commission=commission
                )
                if profit > 0:
                    nd = dict(d)
                    nd['profit']        = int(profit)
                    nd['profit_pct']    = profit_pct
                    nd['total_profit']  = int(profit * d.get('count_buy', 1))
                    nd['buy_currency']  = buy_cur
                    nd['sell_currency'] = sell_cur
                    recalced.append(nd)
            except Exception:
                continue
        state = dict(state)
        state['deals'] = sorted(recalced, key=lambda x: x['total_profit'], reverse=True)

    # Apply plan profit limit
    profit_limit = None
    if plan == 'free':
        profit_limit = 150000
    elif plan == 'basic':
        profit_limit = 500000

    if profit_limit is not None and state.get('deals'):
        state = dict(state)
        state['deals'] = [d for d in state['deals'] if d.get('total_profit', 0) <= profit_limit]

    return jsonify({
        'success':      True,
        'buy_id':       buy_id,
        'sell_id':      sell_id,
        'buy_name':     buy_info.get('name',  f'Сервер {buy_id}'),
        'sell_name':    sell_info.get('name', f'Сервер {sell_id}'),
        'sell_rate':    sell_rate,
        'data':         state,
        'plan':         plan,
    })


@app.route("/api/market")
@login_required
def api_market():
    query     = request.args.get('q', '').strip().lower()
    server_id = int(request.args.get('server', 0))

    if not query:
        return jsonify({'success': False, 'error': 'Введите название товара'})

    lavki    = fetch_lavki()
    items_db = fetch_items_db()

    if not lavki:
        return jsonify({'success': False, 'error': 'Нет данных от маркета'})

    name_to_ids = {}
    for iid, name in items_db.items():
        if query in name.lower():
            name_to_ids[iid] = name

    if not name_to_ids:
        return jsonify({'success': True, 'buy_shops': [], 'sell_shops': [], 'matched_items': []})

    matched_item_names = sorted(set(name_to_ids.values()))
    server_lavki = [l for l in lavki if l.get('serverId') == server_id]
    buy_shops  = []
    sell_shops = []

    for l in server_lavki:
        lavka_uid = l.get('LavkaUid')
        if l.get('items_buy') and l.get('price_buy'):
            for idx, item_id in enumerate(l['items_buy']):
                iid = item_id if isinstance(item_id, int) else None
                if iid is None:
                    try:
                        iid = int(str(item_id).split('(')[0])
                    except Exception:
                        continue
                if iid in name_to_ids:
                    try:
                        price_raw = float(l['price_buy'][idx])
                        count     = int(l['count_buy'][idx]) if l.get('count_buy') else 0
                        buy_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     int(price_raw),
                            'count':     count,
                        })
                    except Exception:
                        continue

        if l.get('items_sell') and l.get('price_sell'):
            for idx, item_id in enumerate(l['items_sell']):
                iid = item_id if isinstance(item_id, int) else None
                if iid is None:
                    try:
                        iid = int(str(item_id).split('(')[0])
                    except Exception:
                        continue
                if iid in name_to_ids:
                    try:
                        price_raw = float(l['price_sell'][idx])
                        count     = int(l['count_sell'][idx]) if l.get('count_sell') else 0
                        sell_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     price_raw,
                            'count':     count,
                        })
                    except Exception:
                        continue

    return jsonify({
        'success':       True,
        'buy_shops':     buy_shops,
        'sell_shops':    sell_shops,
        'matched_items': matched_item_names,
        'server_id':     server_id,
        'query':         query,
    })


@app.route("/api/average-prices")
@login_required
def api_average_prices():
    username = session.get('username', '')
    creds = load_creds()
    current_user = next((u for u in creds.get('users', []) if u.get('username') == username), None)
    default_server = current_user.get('user_server', 2) if current_user else 2
    try:
        server_id = int(request.args.get('server', default_server))
    except Exception:
        server_id = default_server
    query = request.args.get('q', '').strip().lower()
    today = date.today().isoformat()
    init_average_prices_db()

    with get_price_db() as conn:
        last_row = conn.execute(
            "SELECT MAX(captured_at) AS last_update FROM price_snapshots WHERE server_id = ?",
            (server_id,)
        ).fetchone()
        scan_count = conn.execute("SELECT COUNT(*) AS c FROM price_snapshots").fetchone()['c']
        server_scan_count = conn.execute(
            "SELECT COUNT(*) AS c FROM price_snapshots WHERE server_id = ?",
            (server_id,)
        ).fetchone()['c']
        where = "WHERE lower(pi.name) LIKE ? OR CAST(pi.item_id AS TEXT) LIKE ?" if query else ""
        params = [f"%{query}%", f"%{query}%"] if query else []
        rows = conn.execute(f"""
            WITH latest AS (
                SELECT ps.*
                FROM price_snapshots ps
                JOIN (
                    SELECT item_id, MAX(captured_at) AS captured_at
                    FROM price_snapshots
                    WHERE server_id = ?
                    GROUP BY item_id
                ) mx ON mx.item_id = ps.item_id AND mx.captured_at = ps.captured_at
                WHERE ps.server_id = ?
            ),
            daily AS (
                SELECT item_id,
                       AVG(max_buy_price) AS day_avg_buy,
                       AVG(min_sell_price) AS day_avg_sell
                FROM price_snapshots
                WHERE server_id = ? AND day = ?
                GROUP BY item_id
            )
            SELECT pi.item_id, pi.name,
                   latest.max_buy_price, latest.min_sell_price, latest.captured_at,
                   daily.day_avg_buy, daily.day_avg_sell
            FROM price_items pi
            LEFT JOIN latest ON latest.item_id = pi.item_id
            LEFT JOIN daily ON daily.item_id = pi.item_id
            {where}
            ORDER BY
                CASE WHEN latest.max_buy_price IS NULL AND latest.min_sell_price IS NULL THEN 1 ELSE 0 END,
                pi.name COLLATE NOCASE
            LIMIT 500
        """, [server_id, server_id, server_id, today] + params).fetchall()

    items = []
    for row in rows:
        avg_values = [v for v in (row['day_avg_buy'], row['day_avg_sell']) if v is not None]
        day_avg_price = int(sum(avg_values) / len(avg_values)) if avg_values else None
        items.append({
            'item_id': row['item_id'],
            'name': row['name'],
            'max_buy_price': row['max_buy_price'],
            'min_sell_price': row['min_sell_price'],
            'day_avg_buy': int(row['day_avg_buy']) if row['day_avg_buy'] is not None else None,
            'day_avg_sell': int(row['day_avg_sell']) if row['day_avg_sell'] is not None else None,
            'day_avg_price': day_avg_price,
            'captured_at': row['captured_at'],
        })

    return jsonify({
        'success': True,
        'server_id': server_id,
        'last_update': last_row['last_update'] if last_row else None,
        'has_data': server_scan_count > 0,
        'has_any_data': scan_count > 0,
        'items': items,
    })


@app.route("/api/average-prices/scan", methods=["POST"])
@login_required
def api_average_prices_scan():
    return jsonify(collect_average_price_snapshot())


@app.route("/api/inventory")
@login_required
def api_inventory():
    return jsonify({'success': True, 'data': load_inventory()})


@app.route("/api/inventory-summary")
@login_required
def api_inventory_summary():
    resp = make_response(jsonify({'success': True, 'data': get_inventory_summary()}))
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma']        = 'no-cache'
    resp.headers['Expires']       = '0'
    return resp


@app.route("/api/search-items")
@login_required
def api_search_items():
    query = request.args.get('q', '').lower()
    try:
        items    = fetch_with_retry(ITEMS_URL, retries=2)
        filtered = [i for i in items if query in i.get('name', '').lower()]
        return jsonify({'success': True, 'items': filtered[:30]})
    except Exception:
        return jsonify({'success': False, 'items': []})


@app.route("/api/add-item", methods=["POST"])
@login_required
def api_add_item():
    try:
        data           = request.json
        item_name      = data.get('name', '')
        qty            = int(data.get('qty', 0))
        price_per_unit = int(data.get('price_per_unit', 0))
        if not item_name or qty <= 0:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name not in inventory:
            inventory[item_name] = {'qty': 0, 'entries': []}
        inventory[item_name]['qty'] += qty
        inventory[item_name]['entries'].append({
            'qty': qty, 'price_per_unit': price_per_unit,
            'seller': 'Admin', 'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        })
        with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(inventory, f, ensure_ascii=False, indent=2)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/delete-item", methods=["POST"])
@login_required
def api_delete_item():
    try:
        data      = request.json
        item_name = data.get('name', '')
        if not item_name:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name in inventory:
            del inventory[item_name]
            with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(inventory, f, ensure_ascii=False, indent=2)
            return jsonify({'success': True})
        return jsonify({'success': False, 'error': 'Item not found'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Авторынок ────────────────────────────────────────────────────────────────

def load_avtomarket():
    try:
        if os.path.exists(AVTOMARKET_FILE):
            with open(AVTOMARKET_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return []

def save_avtomarket(listings):
    with open(AVTOMARKET_FILE, 'w', encoding='utf-8') as f:
        json.dump(listings, f, ensure_ascii=False, indent=2)

@app.route("/api/avtomarket")
@login_required
def api_avtomarket_list():
    listings = load_avtomarket()
    resp = make_response(jsonify({'success': True, 'listings': listings}))
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma']        = 'no-cache'
    resp.headers['Expires']       = '0'
    return resp

@app.route("/api/avtomarket/add", methods=["POST"])
@login_required
def api_avtomarket_add():
    try:
        data = request.json
        model     = data.get('model', '').strip()
        price     = int(data.get('price', 0))
        server_id = int(data.get('server_id', 1))
        condition = int(data.get('condition', 100))
        contact   = data.get('contact', '').strip()
        ad_type   = data.get('ad_type', 'sell')
        note      = data.get('note', '').strip()
        if not model or price < 0:
            return jsonify({'success': False, 'error': 'Некорректные данные'})
        listings = load_avtomarket()
        listing = {
            'id':        str(uuid.uuid4())[:8],
            'model':     model,
            'price':     price,
            'server_id': server_id,
            'condition': max(0, min(100, condition)),
            'contact':   contact,
            'ad_type':   ad_type,
            'note':      note,
            'added_by':  session.get('username', ''),
            'added_at':  datetime.now().strftime('%Y-%m-%d %H:%M'),
        }
        listings.insert(0, listing)
        save_avtomarket(listings)
        return jsonify({'success': True, 'listing': listing})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route("/api/avtomarket/delete", methods=["POST"])
@login_required
def api_avtomarket_delete():
    try:
        listing_id = request.json.get('id', '')
        listings   = load_avtomarket()
        username   = session.get('username', '')
        creds      = load_creds()
        is_admin   = creds.get(username, {}).get('role', '') == 'admin'
        new_list   = [l for l in listings if l.get('id') != listing_id or (not is_admin and l.get('added_by') != username)]
        if len(new_list) == len(listings) and not is_admin:
            return jsonify({'success': False, 'error': 'Нет доступа'})
        save_avtomarket(new_list)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/auto_status")
@login_required
def api_auto_status():
    return jsonify({
        'scanner_running':   auto_scanner_running,
        'arbitrage_running': auto_arbitrage_running,
        'bd_running':        auto_bd_running,
        'arb_buy':           auto_arb_buy,
        'arb_sell':          auto_arb_sell,
    })


# ─── Balance ──────────────────────────────────────────────────────────────────

@app.route("/api/balance/add", methods=["POST"])
@login_required
def api_balance_add():
    try:
        data    = request.json
        amount  = data.get('amount')
        note    = data.get('note', '')
        if amount is None:
            return jsonify({'success': False, 'error': 'amount required'})
        amount  = int(amount)
        records = load_balance()
        record  = {'amount': amount, 'note': note,
                   'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                   'date': date.today().isoformat()}
        records.append(record)
        save_balance(records)
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/delete", methods=["POST"])
@login_required
def api_balance_delete():
    try:
        data    = request.json
        index   = data.get('index')
        records = load_balance()
        if index is None or index < 0 or index >= len(records):
            return jsonify({'success': False, 'error': 'Invalid index'})
        records.pop(index)
        save_balance(records)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/history")
@login_required
def api_balance_history():
    try:
        records     = load_balance()
        today       = date.today().isoformat()
        income_today, income_all = 0, 0
        if records:
            income_all  = records[-1]['amount'] - records[0]['amount']
            today_recs  = [r for r in records if r.get('date') == today]
            if len(today_recs) >= 2:
                income_today = today_recs[-1]['amount'] - today_recs[0]['amount']
            elif len(today_recs) == 1:
                prev = [r for r in records if r.get('date', '') < today]
                if prev:
                    income_today = today_recs[-1]['amount'] - prev[-1]['amount']
        return jsonify({'success': True, 'records': records,
                        'income_today': income_today, 'income_all': income_all})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Scan / toggle routes ─────────────────────────────────────────────────────

@app.route("/scan_scanner", methods=["POST"])
@login_required
def scan_scanner_route():
    username = session.get('username', '')
    user     = get_user_from_session()
    plan     = get_effective_plan(user)
    ok, remaining = check_scan_cooldown(username, plan, 'scanner')
    if not ok:
        m, s = divmod(remaining, 60)
        return jsonify({'status': 'cooldown', 'remaining': remaining,
                        'message': f'Следующий скан через {m}м {s}с'})
    mark_scan_done(username, 'scanner')
    threading.Thread(target=scan_scanner, daemon=True).start()
    write_log(username, 'scan_scanner')
    return jsonify({'status': 'started'})


@app.route("/scan_arbitrage", methods=["POST"])
@login_required
def scan_arbitrage_route():
    global auto_arb_buy, auto_arb_sell
    username = session.get('username', '')
    user     = get_user_from_session()
    plan     = get_effective_plan(user)
    ok, remaining = check_scan_cooldown(username, plan, 'arbitrage')
    if not ok:
        m, s = divmod(remaining, 60)
        return jsonify({'status': 'cooldown', 'remaining': remaining,
                        'message': f'Следующий скан через {m}м {s}с'})
    try:
        user_srv = int((user or {}).get('user_server') or 2)
    except (TypeError, ValueError):
        user_srv = 2
    user_srv = max(0, min(32, user_srv))
    default_sell = 0 if user_srv != 0 else 2
    try:
        buy_id  = int(request.args.get('buy',  user_srv))
        sell_id = int(request.args.get('sell', default_sell))
    except ValueError:
        buy_id, sell_id = user_srv, default_sell
    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))
    if buy_id == sell_id:
        sell_id = 0 if buy_id != 0 else 2
    mark_scan_done(username, 'arbitrage')
    auto_arb_buy  = buy_id
    auto_arb_sell = sell_id
    threading.Thread(target=do_scan_arbitrage, args=(buy_id, sell_id), daemon=True).start()
    write_log(username, 'scan_arbitrage', f'buy={buy_id} sell={sell_id}')
    return jsonify({'status': 'started', 'buy': buy_id, 'sell': sell_id})


@app.route("/toggle_auto_scanner", methods=["POST"])
@login_required
def toggle_auto_scanner():
    global auto_scanner_running
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan != 'pro':
        return jsonify({'success': False, 'error': 'Автосканирование доступно только в тарифе Профи'})
    if auto_scanner_running:
        auto_scanner_running = False
        return jsonify({'status': 'stopped', 'scanner_running': False})
    else:
        auto_scanner_running = True
        threading.Thread(target=auto_scanner_loop, daemon=True).start()
        return jsonify({'status': 'started', 'scanner_running': True})


@app.route("/toggle_auto_arbitrage", methods=["POST"])
@login_required
def toggle_auto_arbitrage():
    global auto_arbitrage_running, auto_arb_buy, auto_arb_sell
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan != 'pro':
        return jsonify({'success': False, 'error': 'Автоарбитраж доступен только в тарифе Профи'})
    try:
        body    = request.get_json(silent=True) or {}
        buy_id  = int(body.get('buy',  auto_arb_buy))
        sell_id = int(body.get('sell', auto_arb_sell))
    except Exception:
        buy_id, sell_id = auto_arb_buy, auto_arb_sell
    auto_arb_buy  = buy_id
    auto_arb_sell = sell_id
    if auto_arbitrage_running:
        auto_arbitrage_running = False
        return jsonify({'status': 'stopped', 'arbitrage_running': False})
    else:
        auto_arbitrage_running = True
        threading.Thread(target=auto_arbitrage_loop, daemon=True).start()
        return jsonify({'status': 'started', 'arbitrage_running': True})


@app.route("/toggle_auto_bestdeals", methods=["POST"])
@login_required
def toggle_auto_bestdeals():
    global auto_bd_running
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan != 'pro':
        return jsonify({'success': False, 'error': 'Автосканирование топ-сделок доступно только в тарифе Профи'})
    if auto_bd_running:
        auto_bd_running = False
        return jsonify({'status': 'stopped', 'bd_running': False})
    else:
        auto_bd_running = True
        threading.Thread(target=auto_bd_loop, daemon=True).start()
        return jsonify({'status': 'started', 'bd_running': True})


@app.route("/api/best_deals")
@login_required
def api_best_deals():
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan not in ('pro',):
        return jsonify({'success': False, 'error': 'plan_required',
                        'message': 'Топ сделки доступны только в тарифе Профи'})
    return jsonify(get_bd_state())


@app.route("/scan_best_deals", methods=["POST"])
@login_required
def scan_best_deals_route():
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan not in ('pro',):
        return jsonify({'success': False, 'error': 'Доступно только в тарифе Профи'})
    username = session.get('username', '')
    write_log(username, 'scan_best_deals')
    threading.Thread(target=do_scan_best_deals, daemon=True).start()
    return jsonify({'status': 'started'})


# ─── Admin routes ─────────────────────────────────────────────────────────────

@app.route("/api/admin/users")
@admin_required
def api_admin_users():
    creds = load_creds()
    users = []
    for u in creds.get('users', []):
        plan     = get_effective_plan(u)
        expires  = u.get('plan_expires')
        days_left = None
        if expires:
            try:
                exp_dt = datetime.fromisoformat(expires)
                days_left = max(0, (exp_dt - datetime.now()).days)
            except Exception:
                pass
        users.append({
            'username':     u.get('username'),
            'email':        u.get('email'),
            'role':         u.get('role', 'user'),
            'plan':         plan,
            'plan_raw':     u.get('plan', 'free'),
            'plan_expires': expires,
            'days_left':    days_left,
            'reg_date':     u.get('reg_date', '—'),
            'reg_ip':       u.get('reg_ip', '—'),
            'last_ip':      u.get('last_ip', '—'),
            'activated':    u.get('activated', True),
            'blocked':      u.get('blocked', False),
            'commission':   u.get('commission', 9),
            'user_server':  u.get('user_server', 2),
        })
    return jsonify({'success': True, 'users': users})


@app.route("/api/admin/grant_plan", methods=["POST"])
@admin_required
def api_admin_grant_plan():
    data     = request.json or {}
    username = data.get('username', '')
    plan     = data.get('plan', 'free')
    days     = int(data.get('days', 30))

    if plan not in ('free', 'basic', 'pro'):
        return jsonify({'success': False, 'error': 'Неверный тариф'})

    creds   = load_creds()
    updated = False
    for u in creds.get('users', []):
        if u.get('username') == username:
            u['plan'] = plan
            if plan == 'free':
                u['plan_expires'] = None
            else:
                u['plan_expires'] = (datetime.now() + timedelta(days=days)).isoformat()
            updated = True
            break

    if not updated:
        return jsonify({'success': False, 'error': 'Пользователь не найден'})

    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_grant_plan', f'user={username} plan={plan} days={days}')
    return jsonify({'success': True})


@app.route("/api/admin/codes")
@admin_required
def api_admin_codes():
    creds = load_creds()
    codes = []
    for c in creds.get('activation_codes', []):
        if isinstance(c, dict):
            codes.append(c)
        else:
            codes.append({'code': c, 'plan': 'basic', 'duration_days': 30})
    return jsonify({'success': True, 'codes': codes})


@app.route("/api/admin/codes/generate", methods=["POST"])
@admin_required
def api_admin_generate_code():
    data  = request.json or {}
    plan  = data.get('plan', 'basic')
    days  = int(data.get('duration_days', 30))
    code  = generate_code()
    creds = load_creds()
    creds.setdefault('activation_codes', []).append({
        'code': code, 'plan': plan, 'duration_days': days
    })
    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_generate_code', f'code={code} plan={plan} days={days}')
    return jsonify({'success': True, 'code': code, 'plan': plan, 'duration_days': days})


@app.route("/api/admin/codes/delete", methods=["POST"])
@admin_required
def api_admin_delete_code():
    data     = request.json or {}
    code_val = data.get('code', '').upper()
    creds    = load_creds()
    creds['activation_codes'] = [
        c for c in creds.get('activation_codes', [])
        if (c.get('code', '').upper() if isinstance(c, dict) else c.upper()) != code_val
    ]
    save_creds(creds)
    return jsonify({'success': True})


@app.route("/api/admin/log")
@admin_required
def api_admin_log():
    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                log = json.load(f)
        else:
            log = []
        return jsonify({'success': True, 'log': list(reversed(log[-500:]))})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/admin/users/edit", methods=["POST"])
@admin_required
def api_admin_edit_user():
    data       = request.json or {}
    username   = data.get('username', '')
    creds      = load_creds()
    updated    = False
    for u in creds.get('users', []):
        if u.get('username') == username:
            if 'email' in data and data['email']:
                u['email'] = data['email'].strip()
            if 'plan' in data and data['plan'] in ('free', 'basic', 'pro'):
                u['plan'] = data['plan']
                if data['plan'] == 'free':
                    u['plan_expires'] = None
                elif 'days' in data and int(data['days']) > 0:
                    u['plan_expires'] = (datetime.now() + timedelta(days=int(data['days']))).isoformat()
            if 'role' in data and data['role'] in ('user', 'admin'):
                u['role'] = data['role']
            if 'commission' in data:
                try:
                    u['commission'] = float(data['commission'])
                except Exception:
                    pass
            if 'user_server' in data:
                try:
                    u['user_server'] = int(data['user_server'])
                except Exception:
                    pass
            if 'password' in data and data['password']:
                u['password'] = data['password'].strip()
            updated = True
            break
    if not updated:
        return jsonify({'success': False, 'error': 'Пользователь не найден'})
    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_edit_user', f'user={username}')
    return jsonify({'success': True})


@app.route("/api/admin/users/activate", methods=["POST"])
@admin_required
def api_admin_activate_user():
    data     = request.json or {}
    username = data.get('username', '')
    creds    = load_creds()
    for u in creds.get('users', []):
        if u.get('username') == username:
            u['activated'] = not u.get('activated', True)
            save_creds(creds)
            admin = session.get('username', 'admin')
            write_log(admin, 'admin_activate_user', f'user={username} activated={u["activated"]}')
            return jsonify({'success': True, 'activated': u['activated']})
    return jsonify({'success': False, 'error': 'Пользователь не найден'})


@app.route("/api/sections")
@login_required
def api_sections():
    return jsonify({'success': True, 'sections': load_sections()})


@app.route("/api/admin/sections", methods=["GET", "POST"])
@admin_required
def api_admin_sections():
    if request.method == 'POST':
        data = request.json or {}
        sections = data.get('sections', {})
        saved = save_sections(sections)
        admin = session.get('username', 'admin')
        write_log(admin, 'admin_sections_update', f'sections={saved}')
        return jsonify({'success': True, 'sections': saved})
    return jsonify({'success': True, 'sections': load_sections()})


@app.route("/api/admin/users/block", methods=["POST"])
@admin_required
def api_admin_block_user():
    data     = request.json or {}
    username = data.get('username', '')
    creds    = load_creds()
    for u in creds.get('users', []):
        if u.get('username') == username:
            if u.get('role') == 'admin':
                return jsonify({'success': False, 'error': 'Нельзя заблокировать администратора'})
            u['blocked'] = not u.get('blocked', False)
            save_creds(creds)
            admin = session.get('username', 'admin')
            write_log(admin, 'admin_block_user', f'user={username} blocked={u["blocked"]}')
            return jsonify({'success': True, 'blocked': u['blocked']})
    return jsonify({'success': False, 'error': 'Пользователь не найден'})


@app.route("/api/admin/users/delete", methods=["POST"])
@admin_required
def api_admin_delete_user():
    data     = request.json or {}
    username = data.get('username', '')
    creds    = load_creds()
    before   = len(creds.get('users', []))
    creds['users'] = [u for u in creds.get('users', []) if u.get('username') != username or u.get('role') == 'admin']
    if len(creds['users']) == before:
        return jsonify({'success': False, 'error': 'Пользователь не найден или является администратором'})
    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_delete_user', f'user={username}')
    return jsonify({'success': True})


@app.route('/api/arizona_map/<int:server_id>')
def arizona_map_api(server_id):
    if server_id < 1 or server_id > 32:
        return jsonify({'error': 'Server must be between 1 and 32'}), 400
    cache = {}
    if os.path.exists(MAP_CACHE_FILE):
        try:
            with open(MAP_CACHE_FILE, 'r', encoding='utf-8') as f:
                cache = json.load(f)
        except Exception:
            cache = {}
    try:
        resp = requests.get(
            f'https://n-api.arizona-rp.com/api/map/{server_id}',
            headers={
                'User-Agent': 'Mozilla/5.0 Route66Market/1.0',
                'Accept': 'application/json,text/plain,*/*',
            },
            timeout=35
        )
        resp.raise_for_status()
        data = resp.json()
        cache[str(server_id)] = {'saved_at': datetime.now().isoformat(), 'data': data}
        try:
            with open(MAP_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(cache, f, ensure_ascii=False)
        except Exception:
            pass
        return jsonify(data)
    except Exception as e:
        cached = cache.get(str(server_id), {}).get('data')
        if cached:
            return jsonify(cached)
        return jsonify({'error': str(e)}), 502


# ── Map object photos ──────────────────────────────────────────────────────
MAP_PHOTOS_DIR  = os.path.join(FRONTEND_DIR, 'static', 'uploads', 'map_photos')
MAP_PHOTOS_JSON = os.path.join(MAP_PHOTOS_DIR, 'index.json')
os.makedirs(MAP_PHOTOS_DIR, exist_ok=True)

ALLOWED_PHOTO_EXT = {'jpg', 'jpeg', 'png', 'webp', 'gif'}

def _load_photo_index():
    try:
        with open(MAP_PHOTOS_JSON, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _save_photo_index(idx):
    with open(MAP_PHOTOS_JSON, 'w', encoding='utf-8') as f:
        json.dump(idx, f, ensure_ascii=False)

@app.route('/api/map_photo/<key>')
def api_get_map_photo(key):
    idx = _load_photo_index()
    fn  = idx.get(key)
    if not fn:
        return jsonify({'error': 'not found'}), 404
    return jsonify({'url': f'/static/uploads/map_photos/{fn}', 'key': key})

@app.route('/api/admin/map_photo', methods=['POST'])
@admin_required
def api_upload_map_photo():
    key  = request.form.get('key', '').strip()
    file = request.files.get('file')
    if not key or not file:
        return jsonify({'error': 'missing key or file'}), 400
    ext = (file.filename.rsplit('.', 1)[-1] if '.' in file.filename else '').lower()
    if ext not in ALLOWED_PHOTO_EXT:
        return jsonify({'error': 'unsupported file type'}), 400
    idx = _load_photo_index()
    # Remove old file if exists
    old_fn = idx.get(key)
    if old_fn:
        old_path = os.path.join(MAP_PHOTOS_DIR, old_fn)
        if os.path.exists(old_path):
            os.remove(old_path)
    fn   = f'{key}.{ext}'
    path = os.path.join(MAP_PHOTOS_DIR, fn)
    file.save(path)
    idx[key] = fn
    _save_photo_index(idx)
    return jsonify({'url': f'/static/uploads/map_photos/{fn}', 'key': key})

@app.route('/api/admin/map_photo/<key>', methods=['DELETE'])
@admin_required
def api_delete_map_photo(key):
    idx = _load_photo_index()
    fn  = idx.pop(key, None)
    if fn:
        path = os.path.join(MAP_PHOTOS_DIR, fn)
        if os.path.exists(path):
            os.remove(path)
        _save_photo_index(idx)
    return jsonify({'ok': True})


# ── Trash map ──────────────────────────────────────────────────────────────

def _load_trash_map():
    try:
        with open(TRASH_MAP_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
        return data.get('locations', [])
    except Exception:
        return []

def _save_trash_map(locations):
    with open(TRASH_MAP_FILE, 'w', encoding='utf-8') as f:
        json.dump({'locations': locations}, f, ensure_ascii=False, indent=2)

@app.route('/api/trash_map')
@login_required
def api_get_trash_map():
    locations = _load_trash_map()
    return jsonify({'ok': True, 'locations': locations, 'count': len(locations)})

@app.route('/api/trash_map/upload', methods=['POST'])
@admin_required
def api_upload_trash_map():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Файл не передан'}), 400
        f = request.files['file']
        if not f.filename.lower().endswith('.json'):
            return jsonify({'error': 'Разрешены только .json файлы'}), 400
        raw = json.load(f)

        # Normalise to flat list of {x, y, name} entries
        # Supported formats:
        #   1. Dict of groups: {"ModelName": [{model, name, pos:[x,y,z]}, ...], ...}
        #   2. Flat list:      [{x, y, name}, ...]
        #   3. Wrapped list:   {"locations": [...]} / {"points": [...]}
        flat = []
        if isinstance(raw, dict):
            # Check if it looks like grouped format (values are lists of objects with "pos")
            first_val = next(iter(raw.values()), None) if raw else None
            if isinstance(first_val, list):
                # Grouped format: {"ModelName": [{name, pos:[x,y,z]}, ...]}
                for group_name, entries in raw.items():
                    if not isinstance(entries, list):
                        continue
                    for entry in entries:
                        if not isinstance(entry, dict):
                            continue
                        pos = entry.get('pos')
                        if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                            flat.append({
                                'x':    pos[0],
                                'y':    pos[1],
                                'name': entry.get('name', group_name),
                            })
            else:
                # Wrapped list format
                inner = raw.get('locations', raw.get('points', raw.get('data', [])))
                if isinstance(inner, list):
                    flat = inner
        elif isinstance(raw, list):
            flat = raw
        else:
            return jsonify({'error': 'Неверный формат JSON'}), 400

        existing = _load_trash_map()
        existing_keys = set()
        for loc in existing:
            x = loc.get('x', loc.get('lx'))
            y = loc.get('y', loc.get('ly'))
            if x is not None and y is not None:
                existing_keys.add((round(float(x), 2), round(float(y), 2)))

        added = 0
        for item in flat:
            if not isinstance(item, dict):
                continue
            # Support both pos-array format and flat x/y format
            pos = item.get('pos')
            if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                x, y = pos[0], pos[1]
            else:
                x = item.get('x', item.get('lx', item.get('posX', item.get('pos_x'))))
                y = item.get('y', item.get('ly', item.get('posY', item.get('pos_y'))))
            if x is None or y is None:
                continue
            try:
                x, y = float(x), float(y)
            except (ValueError, TypeError):
                continue
            key = (round(x, 2), round(y, 2))
            if key in existing_keys:
                continue
            existing_keys.add(key)
            entry = {
                'id':   item.get('id', str(uuid.uuid4())[:8]),
                'x':    x,
                'y':    y,
                'name': item.get('name', item.get('label', item.get('title', 'Мусорка'))),
            }
            existing.append(entry)
            added += 1

        _save_trash_map(existing)
        write_log(session.get('username', '?'), 'trash_map_upload',
                  f'Добавлено {added} точек, всего {len(existing)}')
        return jsonify({'ok': True, 'added': added, 'total': len(existing)})
    except json.JSONDecodeError:
        return jsonify({'error': 'Ошибка разбора JSON'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trash_map/clear', methods=['POST'])
@admin_required
def api_clear_trash_map():
    _save_trash_map([])
    write_log(session.get('username', '?'), 'trash_map_clear', 'База мусорок очищена')
    return jsonify({'ok': True})


@app.route("/api/sync/ping", methods=["POST"])
def api_sync_ping():
    api_key = request.headers.get('X-API-Key') or (request.json or {}).get('api_key', '')
    user    = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403
    return jsonify({'success': True, 'username': user['username']})


# ─── Remote command queue (Lua script polls, website pushes) ──────────────────

@app.route("/api/sync/commands/pop", methods=["GET"])
def api_sync_commands_pop():
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key', '')
    user = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403
    cmd = pop_command_for_user(user['username'])
    return jsonify({'success': True, 'command': (cmd['command'] if cmd else ''), 'ts': (cmd['ts'] if cmd else '')})


@app.route("/api/sync/commands/push", methods=["POST"])
@login_required
def api_sync_commands_push():
    username = session.get('username', '')
    data = request.json or {}
    command = (data.get('command') or '').strip()
    if not command:
        return jsonify({'success': False, 'error': 'Пустая команда'}), 400
    if not command.startswith('/'):
        command = '/' + command
    if len(command) > 200:
        return jsonify({'success': False, 'error': 'Слишком длинная команда'}), 400
    ok = push_command_for_user(username, command)
    return jsonify({'success': bool(ok)})


@app.route("/api/sync/arbitrage", methods=["GET"])
def api_sync_arbitrage():
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key', '')
    user = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403

    # Default the BUY side to the user's selected server (user_server) when
    # the Lua client doesn't pass explicit buy/sell args.
    try:
        user_srv = int((user or {}).get('user_server') or 2)
    except (TypeError, ValueError):
        user_srv = 2
    user_srv = max(0, min(32, user_srv))
    default_sell = 0 if user_srv != 0 else 2

    try:
        buy_id  = int(request.args.get('buy',  user_srv))
        sell_id = int(request.args.get('sell', default_sell))
    except ValueError:
        buy_id, sell_id = user_srv, default_sell
    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))
    if buy_id == sell_id:
        sell_id = 0 if buy_id != 0 else 2

    try:
        commission_pct = float(request.args.get('commission', 9))
        commission_pct = max(0.0, min(100.0, commission_pct))
    except (ValueError, TypeError):
        commission_pct = 9.0
    commission = (100.0 - commission_pct) / 100.0

    plan = get_effective_plan(user)
    state     = get_arb_state(buy_id, sell_id)
    buy_info  = CURRENCY_RATES.get(buy_id,  {})
    sell_info = CURRENCY_RATES.get(sell_id, {})

    deals = state.get('deals', [])
    if deals and abs(commission - 0.91) > 0.001:
        recalced = []
        for d in deals:
            try:
                profit, profit_pct, buy_cur, sell_cur = _calc_profit(
                    d['price_buy'], d['price_sell'],
                    buy_id, sell_id, buy_info, sell_info,
                    commission=commission
                )
                if profit > 0:
                    nd = dict(d)
                    nd['profit']        = int(profit)
                    nd['profit_pct']    = profit_pct
                    nd['total_profit']  = int(profit * d.get('count_buy', 1))
                    nd['buy_currency']  = buy_cur
                    nd['sell_currency'] = sell_cur
                    recalced.append(nd)
            except Exception:
                continue
        state = dict(state)
        state['deals'] = sorted(recalced, key=lambda x: x['total_profit'], reverse=True)

    profit_limit = None
    if plan == 'free':
        profit_limit = 150000
    elif plan == 'basic':
        profit_limit = 500000
    if profit_limit is not None and state.get('deals'):
        state = dict(state)
        state['deals'] = [d for d in state['deals'] if d.get('total_profit', 0) <= profit_limit]

    deals_out = []
    for d in (state.get('deals') or [])[:50]:
        deals_out.append({
            'lavka_buy':     d.get('lavka_buy'),
            'lavka_sell':    d.get('lavka_sell'),
            'item_name':     d.get('item_name', ''),
            'price_buy':     int(d.get('price_buy', 0)),
            'price_sell':    int(d.get('price_sell', 0)),
            'count_buy':     int(d.get('count_buy', 0)),
            'profit':        int(d.get('profit', 0)),
            'profit_pct':    float(d.get('profit_pct', 0)),
            'total_profit':  int(d.get('total_profit', 0)),
            'buy_currency':  d.get('buy_currency', 'SA$'),
            'sell_currency': d.get('sell_currency', 'VC$'),
        })

    return jsonify({
        'success':   True,
        'buy_id':    buy_id,
        'sell_id':   sell_id,
        'buy_name':  buy_info.get('name',  f'Сервер {buy_id}'),
        'sell_name': sell_info.get('name', f'Сервер {sell_id}'),
        'plan':      plan,
        'deals':     deals_out,
        'updated':   state.get('updated', ''),
    })


@app.route("/api/sync/servers", methods=["GET"])
def api_sync_servers():
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key', '')
    user = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403
    servers = []
    for sid, info in CURRENCY_RATES.items():
        servers.append({
            'id':   int(sid),
            'name': info.get('name', f'Сервер {sid}'),
        })
    servers.sort(key=lambda s: s['id'])
    return jsonify({'success': True, 'servers': servers})


@app.route("/api/sync/market", methods=["GET"])
def api_sync_market():
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key', '')
    user = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403

    query = (request.args.get('q', '') or '').strip().lower()
    try:
        server_id = int(request.args.get('server', 0))
    except (ValueError, TypeError):
        server_id = 0
    server_id = max(0, min(32, server_id))

    if not query:
        return jsonify({'success': False, 'error': 'Введите название товара'})

    lavki    = fetch_lavki()
    items_db = fetch_items_db()
    if not lavki:
        return jsonify({'success': False, 'error': 'Нет данных от маркета'})

    name_to_ids = {iid: name for iid, name in items_db.items() if query in name.lower()}
    if not name_to_ids:
        return jsonify({
            'success': True, 'buy_shops': [], 'sell_shops': [],
            'matched_items': [], 'server_id': server_id, 'query': query,
        })

    server_lavki = [l for l in lavki if l.get('serverId') == server_id]
    buy_shops, sell_shops = [], []
    for l in server_lavki:
        lavka_uid = l.get('LavkaUid')
        if l.get('items_buy') and l.get('price_buy'):
            for idx, item_id in enumerate(l['items_buy']):
                try:
                    iid = item_id if isinstance(item_id, int) else int(str(item_id).split('(')[0])
                except Exception:
                    continue
                if iid in name_to_ids:
                    try:
                        buy_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     int(float(l['price_buy'][idx])),
                            'count':     int(l['count_buy'][idx]) if l.get('count_buy') else 0,
                        })
                    except Exception:
                        continue
        if l.get('items_sell') and l.get('price_sell'):
            for idx, item_id in enumerate(l['items_sell']):
                try:
                    iid = item_id if isinstance(item_id, int) else int(str(item_id).split('(')[0])
                except Exception:
                    continue
                if iid in name_to_ids:
                    try:
                        sell_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     int(float(l['price_sell'][idx])),
                            'count':     int(l['count_sell'][idx]) if l.get('count_sell') else 0,
                        })
                    except Exception:
                        continue

    buy_shops.sort(key=lambda x: -x['price'])
    sell_shops.sort(key=lambda x: x['price'])

    return jsonify({
        'success':       True,
        'buy_shops':     buy_shops[:200],
        'sell_shops':    sell_shops[:200],
        'matched_items': sorted(set(name_to_ids.values())),
        'server_id':     server_id,
        'query':         query,
    })


@app.route("/api/sync/top", methods=["GET"])
def api_sync_top():
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key', '')
    user = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403

    plan  = get_effective_plan(user)
    state = get_bd_state()
    deals = list(state.get('deals') or [])

    # Mirror website plan limits
    profit_limit = None
    if plan == 'free':
        profit_limit = 150000
    elif plan == 'basic':
        profit_limit = 500000
    if profit_limit is not None:
        deals = [d for d in deals if (d.get('total_profit_vc') or 0) <= profit_limit]

    out = []
    for d in deals[:100]:
        out.append({
            'item_name':     d.get('item', ''),
            'item_id':       d.get('item_id'),
            'lavka_buy':     d.get('lavka_buy'),
            'lavka_sell':    d.get('lavka_sell'),
            'buy_server':    d.get('buy_server'),
            'sell_server':   d.get('sell_server'),
            'buy_name':      CURRENCY_RATES.get(d.get('buy_server'),  {}).get('name', ''),
            'sell_name':     CURRENCY_RATES.get(d.get('sell_server'), {}).get('name', ''),
            'price_buy':     int(d.get('price_buy', 0)),
            'price_sell':    int(d.get('price_sell', 0)),
            'buy_currency':  d.get('buy_currency',  'SA$'),
            'sell_currency': d.get('sell_currency', 'SA$'),
            'count_buy':     int(d.get('count_buy', 0)),
            'profit_vc':     float(d.get('profit_vc', 0)),
            'profit_pct':    float(d.get('profit_pct', 0)),
            'total_profit':  int(round(d.get('total_profit_vc', 0))),
        })
    return jsonify({
        'success':     True,
        'deals':       out,
        'plan':        plan,
        'status':      state.get('status', ''),
        'last_update': state.get('last_update'),
        'timestamp':   state.get('timestamp'),
    })


@app.route("/api/sync/top/scan", methods=["POST"])
def api_sync_top_scan():
    api_key = request.headers.get('X-API-Key') or (request.json or {}).get('api_key', '')
    user = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403
    threading.Thread(target=do_scan_best_deals, daemon=True).start()
    return jsonify({'success': True, 'status': 'started'})


@app.route("/download/road66.lua")
def download_road66_lua():
    return send_from_directory(LUA_DIR, "road66.lua", as_attachment=True)


# ─── API Key ──────────────────────────────────────────────────────────────────

@app.route("/api/generate_api_key", methods=["POST"])
@login_required
def api_generate_api_key():
    username = session.get('username', '')
    creds    = load_creds()
    updated  = False
    for user in creds.get('users', []):
        if user.get('username') == username:
            user['api_key'] = generate_api_key()
            updated = True
            break
    if not updated:
        return jsonify({'success': False, 'error': 'Пользователь не найден'})
    try:
        save_creds(creds)
        new_key = next(u['api_key'] for u in creds['users'] if u['username'] == username)
        write_log(username, 'api_key_regenerate', '')
        return jsonify({'success': True, 'api_key': new_key})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Sync routes (called from Lua via HTTP) ───────────────────────────────────

@app.route("/api/sync/balance", methods=["POST"])
def api_sync_balance():
    api_key = request.headers.get('X-API-Key') or (request.json or {}).get('api_key', '')
    user    = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403

    data    = request.json or {}
    balance = data.get('balance')
    if balance is None:
        return jsonify({'success': False, 'error': 'Нет баланса'})
    try:
        balance = int(balance)
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Некорректный баланс'})

    username = user['username']
    ts       = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with get_sync_db() as conn:
        conn.execute(
            "INSERT INTO balance_history (username, balance, ts) VALUES (?, ?, ?)",
            (username, balance, ts)
        )
    return jsonify({'success': True, 'ts': ts})


@app.route("/api/sync/trades", methods=["POST"])
def api_sync_trades():
    api_key = request.headers.get('X-API-Key') or (request.json or {}).get('api_key', '')
    user    = get_user_by_api_key(api_key)
    if not user:
        return jsonify({'success': False, 'error': 'Неверный API ключ'}), 403

    data  = request.json or {}
    trades = data.get('trades', [])
    if not isinstance(trades, list):
        trades = [trades]

    username = user['username']
    ts       = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    inserted = 0
    with get_sync_db() as conn:
        for t in trades:
            try:
                conn.execute(
                    "INSERT INTO trade_log (username, action, item, quantity, price, total, ts) VALUES (?,?,?,?,?,?,?)",
                    (
                        username,
                        str(t.get('action') or t.get('type') or ''),
                        str(t.get('item', '')),
                        int(t.get('quantity') or t.get('count') or 0),
                        int(t.get('price', 0)),
                        int(t.get('total', 0)),
                        t.get('ts', ts),
                    )
                )
                inserted += 1
            except Exception:
                pass
    return jsonify({'success': True, 'inserted': inserted})


@app.route("/api/sync/stats")
@login_required
def api_sync_stats():
    username = session.get('username', '')
    stats    = get_sync_stats(username)
    return jsonify({'success': True, **stats})


@app.route("/api/sync/trades/log")
@login_required
def api_sync_trades_log():
    username = session.get('username', '')
    limit    = min(int(request.args.get('limit', 100)), 500)
    try:
        with get_sync_db() as conn:
            rows = conn.execute(
                "SELECT action, item, quantity, price, total, ts FROM trade_log WHERE username=? ORDER BY ts DESC LIMIT ?",
                (username, limit)
            ).fetchall()
        return jsonify({'success': True, 'trades': [dict(r) for r in rows]})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e), 'trades': []})


start_average_price_scanner()
init_sync_db()
ensure_api_keys()


# ─── Subscription / Stripe ─────────────────────────────────────────────────

STRIPE_SECRET_KEY    = os.environ.get('STRIPE_SECRET_KEY', '')
STRIPE_WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET', '')
STRIPE_CURRENCY      = os.environ.get('STRIPE_CURRENCY', 'rub')

SUBSCRIPTION_PLANS = {
    'basic': {
        'name': 'Базовый',
        'durations': {
            30:  {'price': 299,  'label': '30 дней'},
            90:  {'price': 699,  'label': '90 дней',  'save': '-17%'},
            180: {'price': 1199, 'label': '180 дней', 'save': '-33%'},
        }
    },
    'pro': {
        'name': 'Профи',
        'durations': {
            30:  {'price': 599,  'label': '30 дней'},
            90:  {'price': 1399, 'label': '90 дней',  'save': '-17%'},
            180: {'price': 2499, 'label': '180 дней', 'save': '-33%'},
        }
    }
}


def grant_plan_to_user(username, plan, days):
    creds = load_creds()
    for user in creds.get('users', []):
        if user.get('username') == username:
            current_plan   = get_effective_plan(user)
            expires_str    = user.get('plan_expires')
            if current_plan == plan and expires_str:
                try:
                    base = datetime.fromisoformat(expires_str)
                    base = base if base > datetime.now() else datetime.now()
                except Exception:
                    base = datetime.now()
            else:
                base = datetime.now()
            user['plan']         = plan
            user['plan_expires'] = (base + timedelta(days=days)).isoformat()
            save_creds(creds)
            write_log(username, 'plan_payment', f'plan={plan} days={days}')
            return True
    return False


@app.route("/api/subscription/plans")
@login_required
def api_subscription_plans():
    return jsonify({
        'success': True,
        'stripe_enabled': bool(STRIPE_SECRET_KEY),
        'currency': STRIPE_CURRENCY,
        'plans': SUBSCRIPTION_PLANS
    })


@app.route("/api/subscription/checkout", methods=["POST"])
@login_required
def api_subscription_checkout():
    if not STRIPE_SECRET_KEY:
        return jsonify({'success': False, 'error': 'stripe_not_configured'})
    data = request.json or {}
    plan = data.get('plan', '')
    try:
        days = int(data.get('days', 30))
    except Exception:
        days = 30
    if plan not in SUBSCRIPTION_PLANS:
        return jsonify({'success': False, 'error': 'Неверный тариф'})
    if days not in SUBSCRIPTION_PLANS[plan]['durations']:
        return jsonify({'success': False, 'error': 'Неверный срок'})
    username  = session.get('username', '')
    price_val = SUBSCRIPTION_PLANS[plan]['durations'][days]['price']
    plan_name = SUBSCRIPTION_PLANS[plan]['name']
    try:
        stripe_lib.api_key = STRIPE_SECRET_KEY
        base_url   = request.host_url.rstrip('/')
        stripe_session = stripe_lib.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': STRIPE_CURRENCY,
                    'product_data': {'name': f'Route66 Market — «{plan_name}» на {days} дней'},
                    'unit_amount': price_val * 100,
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=base_url + f'/subscription/success?session_id={{CHECKOUT_SESSION_ID}}',
            cancel_url=base_url + '/',
            metadata={'username': username, 'plan': plan, 'days': str(days)},
        )
        return jsonify({'success': True, 'url': stripe_session.url})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/subscription/success")
def subscription_success():
    session_id = request.args.get('session_id', '')
    activated  = False
    if session_id and STRIPE_SECRET_KEY:
        try:
            stripe_lib.api_key = STRIPE_SECRET_KEY
            s = stripe_lib.checkout.Session.retrieve(session_id)
            if s.payment_status == 'paid':
                uname = s.metadata.get('username', '')
                plan  = s.metadata.get('plan', '')
                days  = int(s.metadata.get('days', 30))
                if uname and plan:
                    grant_plan_to_user(uname, plan, days)
                    activated = True
        except Exception:
            pass
    return redirect('/?sub_success=1' if activated else '/?sub_success=0')


@app.route("/api/subscription/webhook", methods=["POST"])
def api_subscription_webhook():
    if not STRIPE_SECRET_KEY:
        return jsonify({'error': 'not configured'}), 400
    payload    = request.get_data()
    sig_header = request.headers.get('Stripe-Signature', '')
    try:
        if STRIPE_WEBHOOK_SECRET:
            event = stripe_lib.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
        else:
            event = stripe_lib.Event.construct_from(json.loads(payload), stripe_lib.api_key)
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    if event['type'] == 'checkout.session.completed':
        obj   = event['data']['object']
        if obj.get('payment_status') == 'paid':
            meta  = obj.get('metadata', {})
            uname = meta.get('username', '')
            plan  = meta.get('plan', '')
            days  = int(meta.get('days', 30))
            if uname and plan:
                grant_plan_to_user(uname, plan, days)
    return jsonify({'success': True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
