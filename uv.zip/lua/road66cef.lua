-- ════════════════════════════════════════════════════════════════════════════
--  Road66 CEF Panel — браузерная версия торговой аналитики (HTML/CSS/JS)
--
--  Зависимости:
--    1. moonloader/asi/mod_cef.asi          — CEF runtime
--    2. moonloader/lib/cef.lua              — Lua-обёртка над mod_cef
--    3. ресурсы:
--         moonloader/resource/road66_cef/index.html
--         moonloader/resource/road66_cef/style.css
--         moonloader/resource/road66_cef/app.js
--
--  Переключение: CTRL+N или команда /r66cef
-- ════════════════════════════════════════════════════════════════════════════

script_name('Road66 CEF Panel')
script_author('Road66 Market')
script_version('1.0')

-- ─── JSON (пробуем несколько имён, потом встроенный мини-кодер) ────────────
local json
do
    local names = { 'json', 'cjson', 'dkjson', 'jsonx' }
    for _, name in ipairs(names) do
        local ok, mod = pcall(require, name)
        if ok and type(mod) == 'table' and mod.encode and mod.decode then
            json = mod; break
        end
    end
    if not json then
        -- Минимальная реализация JSON (только простые таблицы / числа / строки)
        local enc, dec
        local esc_map = {
            ['"']  = '\\"', ['\\'] = '\\\\', ['\n'] = '\\n',
            ['\r'] = '\\r', ['\t'] = '\\t',
        }
        local function esc(s)
            return (s:gsub('["\\\n\r\t]', esc_map))
        end
        enc = function(v)
            local t = type(v)
            if t == 'nil'     then return 'null'
            elseif t == 'boolean' then return tostring(v)
            elseif t == 'number'  then return tostring(v)
            elseif t == 'string'  then return '"' .. esc(v) .. '"'
            elseif t == 'table' then
                -- array?
                local is_arr = true
                local n = 0
                for k in pairs(v) do
                    n = n + 1
                    if type(k) ~= 'number' or k ~= math.floor(k) or k < 1 then
                        is_arr = false; break
                    end
                end
                if is_arr and n == #v then
                    local parts = {}
                    for i, x in ipairs(v) do parts[i] = enc(x) end
                    return '[' .. table.concat(parts, ',') .. ']'
                else
                    local parts = {}
                    for k, x in pairs(v) do
                        parts[#parts+1] = '"' .. esc(tostring(k)) .. '":' .. enc(x)
                    end
                    return '{' .. table.concat(parts, ',') .. '}'
                end
            end
            return 'null'
        end
        -- Минимальный декодер (рекурсивный спуск)
        local function skip(s, i)
            while i <= #s and s:sub(i,i):match('%s') do i = i+1 end
            return i
        end
        local decode_val
        local function decode_str(s, i)
            -- i points at opening "
            local res, j = {}, i+1
            while j <= #s do
                local c = s:sub(j,j)
                if c == '"' then return table.concat(res), j+1 end
                if c == '\\' then
                    j = j+1; c = s:sub(j,j)
                    local unesc = {n='\n',r='\r',t='\t',['\\']='\\', ['"']='"'}
                    res[#res+1] = unesc[c] or c
                else
                    res[#res+1] = c
                end
                j = j+1
            end
            return table.concat(res), j
        end
        local function decode_arr(s, i)
            local arr, j = {}, skip(s, i+1)
            if s:sub(j,j) == ']' then return arr, j+1 end
            while true do
                local v; v, j = decode_val(s, j); arr[#arr+1] = v
                j = skip(s, j)
                local c = s:sub(j,j); j = j+1
                if c == ']' then break end
            end
            return arr, j
        end
        local function decode_obj(s, i)
            local obj, j = {}, skip(s, i+1)
            if s:sub(j,j) == '}' then return obj, j+1 end
            while true do
                j = skip(s, j)
                local k; k, j = decode_str(s, j)
                j = skip(s, j) + 1  -- skip ':'
                local v; v, j = decode_val(s, skip(s, j))
                obj[k] = v
                j = skip(s, j)
                local c = s:sub(j,j); j = j+1
                if c == '}' then break end
            end
            return obj, j
        end
        decode_val = function(s, i)
            i = skip(s, i)
            local c = s:sub(i,i)
            if c == '"' then return decode_str(s, i)
            elseif c == '[' then return decode_arr(s, i)
            elseif c == '{' then return decode_obj(s, i)
            elseif c == 't' then return true,  i+4
            elseif c == 'f' then return false, i+5
            elseif c == 'n' then return nil,   i+4
            else
                local num = s:match('^-?%d+%.?%d*[eE]?[+-]?%d*', i)
                return tonumber(num), i + #(num or '0')
            end
        end
        json = {
            encode = enc,
            decode = function(s)
                local ok2, res = pcall(decode_val, s, 1)
                return ok2 and res or nil
            end
        }
        print('[Road66 CEF] Используем встроенный JSON (внешний модуль не найден)')
    end
end

-- ─── HTTP (luasocket — есть в большинстве MoonLoader сборок) ──────────────
local http_ok, http   = pcall(require, 'socket.http')
local ltn_ok,  ltn12 = pcall(require, 'ltn12')
if not http_ok or not ltn_ok then
    print('[Road66 CEF] ОШИБКА: не найден luasocket (socket.http / ltn12). Установите MoonLoader с luasocket.')
    return
end

-- ─── CEF wrapper shim ──────────────────────────────────────────────────────
local cef_ok, cef = pcall(require, 'cef')
if not cef_ok then
    print('[Road66 CEF] ОШИБКА: не найден lib/cef.lua — положите его в moonloader/lib/')
    return
end

local Browser = {}
Browser.__index = Browser

function Browser.new(url)
    local self = setmetatable({}, Browser)
    local create = cef.create or cef.new or cef.CreateBrowser or cef.createBrowser
    if not create then
        print('[Road66 CEF] ОШИБКА: cef.create / cef.new не найдены в обёртке')
        return nil
    end
    self._b = create(url, true)
    return self
end

function Browser:show(v)
    local fn = self._b.setVisible or self._b.SetVisible or self._b.show
    if fn then fn(self._b, v ~= false) end
end

function Browser:focus(v)
    local fn = self._b.setFocus or self._b.SetFocus or self._b.focus
    if fn then fn(self._b, v ~= false) end
end

function Browser:set_geometry(x, y, w, h)
    local sp = self._b.setPosition or self._b.SetPosition
    local sz = self._b.setSize     or self._b.SetSize
    if sp then sp(self._b, x, y) end
    if sz then sz(self._b, w, h) end
end

function Browser:execute(js)
    local fn = self._b.execute or self._b.Execute or self._b.executeJavaScript
    if fn then fn(self._b, js) end
end

function Browser:on_event(handler)
    local sub = self._b.onEvent or self._b.OnEvent
    if cef.addEventHandler then
        cef.addEventHandler(function(name, data) handler(name, data) end)
    elseif sub then
        sub(self._b, function(name, data) handler(name, data) end)
    end
end

-- ─── Config ────────────────────────────────────────────────────────────────
local CONFIG_PATH = getWorkingDirectory() .. '/config/road66cef_config.json'
local cfg = {
    api_key    = '',
    server_url = 'http://localhost:5000',
    auto_sync  = true,
    panel_w    = 1200,
    panel_h    = 800,
}

local function ensure_dir(path)
    local f = io.open(path, 'rb')
    if f then f:close(); return end
    os.execute('mkdir "' .. path:gsub('/', '\\') .. '"')
end

local function load_config()
    local f = io.open(CONFIG_PATH, 'r')
    if not f then return end
    local data = f:read('*a'); f:close()
    local t = json.decode(data)
    if type(t) == 'table' then
        for k, v in pairs(t) do cfg[k] = v end
    end
end

local function save_config()
    ensure_dir(getWorkingDirectory() .. '/config')
    local f = io.open(CONFIG_PATH, 'w')
    if not f then return end
    f:write(json.encode(cfg)); f:close()
end

-- ─── Синхронный HTTP (вызывается внутри lua_thread — не блокирует игру) ───
local function http_request(method, url, headers, body, timeout)
    http.TIMEOUT = timeout or 8
    local sink_t = {}
    local req = {
        method  = method,
        url     = url,
        headers = headers or {},
        sink    = ltn12.sink.table(sink_t),
    }
    if body then
        req.source = ltn12.source.string(body)
        req.headers['Content-Length'] = tostring(#body)
    end
    local r_ok, code = http.request(req)
    return r_ok and true or false, tonumber(code) or 0, table.concat(sink_t)
end

local function api_post(path, body_table)
    local ok, _, text = http_request('POST', cfg.server_url .. path, {
        ['Content-Type'] = 'application/json',
        ['X-API-Key']    = cfg.api_key,
    }, json.encode(body_table or {}), 8)
    if not ok then return nil end
    return json.decode(text or '')
end

local function api_get(path)
    local ok, _, text = http_request('GET', cfg.server_url .. path, {
        ['X-API-Key'] = cfg.api_key,
    }, nil, 8)
    if not ok then return nil end
    return json.decode(text or '')
end

-- ─── Browser instance & state ──────────────────────────────────────────────
local browser
local panel_visible = false
local sync_status = { online = false, msg = 'Не подключено' }

local function panel_url()
    local p = getWorkingDirectory():gsub('\\', '/')
    return 'file:///' .. p .. '/resource/road66_cef/index.html'
end

local function center_panel()
    local sw, sh = getScreenResolution()
    local x = math.floor((sw - cfg.panel_w) / 2)
    local y = math.floor((sh - cfg.panel_h) / 2)
    browser:set_geometry(x, y, cfg.panel_w, cfg.panel_h)
end

-- ─── Lua → JS пуш данных ───────────────────────────────────────────────────
local function js_push(channel, payload)
    if not browser then return end
    local s = json.encode({ channel = channel, payload = payload or {} })
    s = s:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n')
    browser:execute('window.r66 && window.r66.dispatch("' .. s .. '")')
end

local function push_status()
    js_push('status', {
        online  = sync_status.online,
        message = sync_status.msg,
        api_key = cfg.api_key ~= '' and '••••••••' or '',
        server  = cfg.server_url,
        version = '1.0 CEF',
    })
end

-- ─── Backend actions ───────────────────────────────────────────────────────
local function do_ping()
    if cfg.api_key == '' then
        sync_status = { online = false, msg = 'Введите API ключ' }
        push_status(); return
    end
    local d = api_post('/api/sync/ping', { api_key = cfg.api_key })
    if d and d.success then
        sync_status = { online = true, msg = 'Подключено' }
    else
        sync_status = { online = false, msg = (d and d.error) or 'Нет ответа от сервера' }
    end
    push_status()
end

local function do_load_servers()
    local d = api_get('/api/sync/servers')
    if d and d.servers then
        js_push('servers', d.servers)
    end
end

local function do_load_arbitrage()
    js_push('arbitrage:loading', { loading = true })
    local d = api_get('/api/sync/arbitrage')
    js_push('arbitrage', { rows = (d and d.rows) or {}, error = d and d.error })
end

local function do_load_market(query, server_id)
    js_push('market:loading', { loading = true })
    local path = string.format('/api/sync/market?q=%s&server=%d',
        (query or ''), tonumber(server_id) or 0)
    local d = api_get(path)
    js_push('market', { rows = (d and d.rows) or {}, error = d and d.error })
end

local function do_load_top(scan)
    if scan then api_post('/api/sync/top/scan', { api_key = cfg.api_key }) end
    js_push('top:loading', { loading = true })
    local d = api_get('/api/sync/top')
    js_push('top', { rows = (d and d.rows) or {}, error = d and d.error })
end

-- ─── JS → Lua обработчик событий ───────────────────────────────────────────
local function on_js_event(name, data)
    if name == 'close' then
        panel_visible = false
        if browser then browser:show(false); browser:focus(false) end

    elseif name == 'save_config' then
        if data and type(data) == 'table' then
            if data.api_key    then cfg.api_key    = tostring(data.api_key) end
            if data.server_url then cfg.server_url = tostring(data.server_url):gsub('/+$', '') end
            if data.auto_sync ~= nil then cfg.auto_sync = not not data.auto_sync end
            save_config()
        end
        lua_thread.create(do_ping)

    elseif name == 'request_status'    then push_status()
    elseif name == 'request_servers'   then lua_thread.create(do_load_servers)
    elseif name == 'request_arbitrage' then lua_thread.create(do_load_arbitrage)
    elseif name == 'request_market' then
        lua_thread.create(function()
            do_load_market(data and data.query or '', data and data.server or 0)
        end)
    elseif name == 'request_top' then
        lua_thread.create(function() do_load_top(data and data.scan) end)
    elseif name == 'open_link' then
        if data and data.url then os.execute('start ' .. data.url) end
    end
end

-- ─── Toggle panel ──────────────────────────────────────────────────────────
local function toggle_panel()
    if not browser then
        browser = Browser.new(panel_url())
        if not browser then return end
        center_panel()
        browser:on_event(on_js_event)
        lua_thread.create(function()
            wait(800)
            push_status()
            if cfg.auto_sync then do_ping() end
            do_load_servers()
        end)
    end
    panel_visible = not panel_visible
    browser:show(panel_visible)
    browser:focus(panel_visible)
    showCursor(panel_visible, panel_visible)
end

-- ─── Hotkeys & chat command ────────────────────────────────────────────────
local function hotkey_loop()
    local VK_CTRL, VK_N = 0x11, 0x4E
    local pressed_last = false
    while true do
        wait(0)
        if not isSampLoaded() or not isSampfuncsLoaded() then
            wait(500)
        else
            local ok_c, ctrl = pcall(isKeyDown, VK_CTRL)
            local ok_n, n    = pcall(isKeyDown, VK_N)
            local pressed = (ok_c and ctrl) and (ok_n and n)
            if pressed and not pressed_last then toggle_panel() end
            pressed_last = pressed
        end
    end
end

-- ─── Entry point ───────────────────────────────────────────────────────────
function main()
    while not isSampAvailable() do wait(100) end
    load_config()
    sampRegisterChatCommand('r66cef', toggle_panel)
    sampAddChatMessage('{a855f7}[Road66 CEF]{ffffff} Загружено. CTRL+N или /r66cef', -1)
    lua_thread.create(hotkey_loop)
    while true do wait(500) end
end
