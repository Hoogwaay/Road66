// Route66 Market — Landing Page JS

// ─── Auto-open modal via URL hash (deep links) ────────────────
window.addEventListener('DOMContentLoaded', () => {
    const h = (location.hash || '').toLowerCase();
    if (h === '#login') openLoginModal();
    else if (h === '#register') openRegisterModal();
});

// ─── Background Canvas ───────────────────────────────────────
(function initCanvas() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    function resize() {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const COUNT  = 60;
    const colors = ['91,95,239', '34,211,238', '74,222,128'];
    const dots   = Array.from({ length: COUNT }, () => ({
        x:  Math.random() * canvas.width,
        y:  Math.random() * canvas.height,
        r:  Math.random() * 1.4 + 0.3,
        vx: (Math.random() - 0.5) * 0.12,
        vy: (Math.random() - 0.5) * 0.12,
        o:  Math.random() * 0.25 + 0.05,
        c:  colors[Math.floor(Math.random() * colors.length)],
    }));

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        dots.forEach(d => {
            d.x += d.vx; d.y += d.vy;
            if (d.x < 0 || d.x > canvas.width)  d.vx *= -1;
            if (d.y < 0 || d.y > canvas.height)  d.vy *= -1;
            ctx.beginPath();
            ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${d.c},${d.o})`;
            ctx.fill();
        });
        for (let i = 0; i < dots.length; i++) {
            for (let j = i + 1; j < dots.length; j++) {
                const dx = dots[i].x - dots[j].x;
                const dy = dots[i].y - dots[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(dots[i].x, dots[i].y);
                    ctx.lineTo(dots[j].x, dots[j].y);
                    ctx.strokeStyle = `rgba(91,95,239,${0.07 * (1 - dist / 120)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
})();

// ─── Auth Modal helpers ───────────────────────────────────────
function _resetViews() {
    _viewSwitching = false;
    for (const id of ['login-view', 'register-view', 'verify-view']) {
        const el = document.getElementById(id);
        if (el) { el.style.display = 'none'; el.classList.remove('view-enter', 'view-exit'); }
    }
}

function openLoginModal() {
    _resetViews();
    document.getElementById('loginModal').classList.add('open');
    showLoginView();
}

function openRegisterModal() {
    _resetViews();
    document.getElementById('loginModal').classList.add('open');
    showRegisterView();
}

function closeLoginModal() {
    document.getElementById('loginModal').classList.remove('open');
}


// ─── View switching (animated) ────────────────────────────────
let _viewSwitching = false;

function _currentView() {
    for (const id of ['login-view', 'register-view', 'verify-view', 'forgot-view']) {
        const el = document.getElementById(id);
        if (el && el.style.display !== 'none') return id;
    }
    return null;
}

function _animateToView(toId, tabLoginActive, afterShow) {
    const fromId = _currentView();
    const toEl   = document.getElementById(toId);
    if (!toEl) return;

    // Legacy tab hooks — keep them updated for any external code, but never render them.
    const _tabsEl = document.getElementById('auth-tabs');
    if (_tabsEl) _tabsEl.style.display = 'none';
    if (tabLoginActive !== null) {
        document.getElementById('tab-login')?.classList.toggle('active', tabLoginActive === true);
        document.getElementById('tab-register')?.classList.toggle('active', tabLoginActive === false);
    }

    if (!fromId || fromId === toId) {
        toEl.style.display = '';
        void toEl.offsetWidth;
        toEl.classList.remove('view-exit');
        toEl.classList.add('view-enter');
        if (afterShow) afterShow();
        return;
    }

    if (_viewSwitching) return;
    _viewSwitching = true;

    const fromEl = document.getElementById(fromId);
    fromEl.classList.remove('view-enter');
    fromEl.classList.add('view-exit');

    setTimeout(() => {
        fromEl.style.display = 'none';
        fromEl.classList.remove('view-exit');

        toEl.style.display = '';
        void toEl.offsetWidth;
        toEl.classList.remove('view-exit');
        toEl.classList.add('view-enter');

        _viewSwitching = false;
        if (afterShow) afterShow();
    }, 180);
}

function _setCornerLink(text, handler) {
    const link = document.getElementById('auth-corner-link');
    if (!link) return;
    if (text === null) { link.style.display = 'none'; return; }
    link.style.display = '';
    link.textContent = text;
    link.onclick = (e) => { e.preventDefault(); handler && handler(); return false; };
}

function showLoginView() {
    _setCornerLink('Создать аккаунт', showRegisterView);
    _animateToView('login-view', true, () => {
        document.getElementById('login-error').textContent = '';
        document.getElementById('login-username')?.focus();
    });
}

function showRegisterView() {
    _setCornerLink('У меня есть аккаунт', showLoginView);
    _animateToView('register-view', false, () => {
        document.getElementById('reg-error').textContent = '';
        document.getElementById('reg-username')?.focus();
    });
}

function showVerifyView(email) {
    _setCornerLink('← Назад ко входу', showLoginView);
    _animateToView('verify-view', null, () => {
        document.getElementById('verify-email-masked').textContent = maskEmail(email);
        document.getElementById('verify-code-input').value = '';
        document.getElementById('verify-error').textContent = '';
        document.getElementById('verify-code-input')?.focus();
    });
}

function showForgotView() {
    _setCornerLink('← Назад ко входу', showLoginView);
    _animateToView('forgot-view', null, () => {
        const errEl = document.getElementById('forgot-error');
        const okEl  = document.getElementById('forgot-success');
        if (errEl) errEl.textContent = '';
        if (okEl)  okEl.textContent  = '';
        const inp   = document.getElementById('forgot-email');
        if (inp) { inp.value = ''; inp.focus(); }
        // Pre-fill from login form's username if it looks like an email
        const loginU = document.getElementById('login-username')?.value || '';
        if (inp && loginU.includes('@')) inp.value = loginU.trim();
    });
}

// ─── Email masking ────────────────────────────────────────────
function maskEmail(email) {
    const [localPart, domain] = email.split('@');
    const domainParts = domain.split('.');
    const domainZone  = domainParts.pop();
    const domainName  = domainParts.join('.');
    const maskedLocal = localPart.slice(0, 2) + '***';
    const maskedDomain = '***' + domainName.slice(-2 < domainName.length ? -2 : 0);
    return `${maskedLocal}@${maskedDomain}.${domainZone}`;
}

// ─── Password toggle (animated) ──────────────────────────────
const _EYE_OPEN   = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5"/>`;
const _EYE_CLOSED = `<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>`;

function togglePw(inputId, btn) {
    const inp = document.getElementById(inputId);
    if (!inp) return;
    const willShow = inp.type === 'password';
    inp.type = willShow ? 'text' : 'password';

    const svg = btn.querySelector('svg');
    if (!svg) return;

    svg.classList.remove('pw-eye-pop');
    void svg.offsetWidth;
    svg.classList.add('pw-eye-pop');

    setTimeout(() => {
        svg.innerHTML = willShow ? _EYE_CLOSED : _EYE_OPEN;
    }, 80);

    svg.addEventListener('animationend', () => {
        svg.classList.remove('pw-eye-pop');
    }, { once: true });
}

// ─── Password match check ─────────────────────────────────────
function checkPwMatch() {
    const p1  = document.getElementById('reg-password')?.value;
    const p2  = document.getElementById('reg-password2')?.value;
    const el  = document.getElementById('pw-match-hint');
    if (!el || !p2) return;
    if (p1 === p2) {
        el.textContent = '✓ Пароли совпадают';
        el.className   = 'pw-match-hint match';
    } else {
        el.textContent = '✗ Пароли не совпадают';
        el.className   = 'pw-match-hint nomatch';
    }
}

// ─── Latin-only validation ────────────────────────────────────
function hasNonLatin(str) {
    return /[^\x00-\x7F]/.test(str);
}

// ─── Login ────────────────────────────────────────────────────
async function handleLogin(e) {
    e.preventDefault();
    const username  = document.getElementById('login-username').value.trim();
    const password  = document.getElementById('login-password').value;
    const errorEl   = document.getElementById('login-error');
    const submitBtn = document.getElementById('login-submit');

    if (!username || !password) { errorEl.textContent = 'Введите логин и пароль'; return; }
    if (hasNonLatin(username)) { errorEl.textContent = 'Логин должен содержать только латинские символы'; return; }
    if (hasNonLatin(password)) { errorEl.textContent = 'Пароль должен содержать только латинские символы'; return; }

    submitBtn.disabled = true;
    errorEl.textContent = '';
    try {
        const res  = await fetch('/api/login', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username, password }),
        });
        const data = await res.json();
        if (data.success) {
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed;inset:0;background:#080A14;z-index:99999;opacity:0;transition:opacity 0.45s ease;pointer-events:all;';
            document.body.appendChild(overlay);
            requestAnimationFrame(() => {
                requestAnimationFrame(() => { overlay.style.opacity = '1'; });
            });
            setTimeout(() => { window.location.href = '/panel'; }, 480);
        } else {
            errorEl.textContent = data.error || 'Неверный логин или пароль';
            submitBtn.disabled  = false;
        }
    } catch {
        errorEl.textContent = 'Ошибка соединения';
        submitBtn.disabled  = false;
    }
}

// ─── Forgot password ──────────────────────────────────────────
async function handleForgotPassword(e) {
    e.preventDefault();
    const email     = document.getElementById('forgot-email').value.trim();
    const errorEl   = document.getElementById('forgot-error');
    const okEl      = document.getElementById('forgot-success');
    const submitBtn = document.getElementById('forgot-submit');

    errorEl.textContent = '';
    okEl.textContent    = '';

    if (!email || !email.includes('@')) {
        errorEl.textContent = 'Укажите корректный email';
        return;
    }

    submitBtn.disabled = true;
    try {
        const res  = await fetch('/api/forgot_password', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ email }),
        });
        const data = await res.json();
        if (data.success) {
            okEl.innerHTML =
                'Если такой email зарегистрирован — мы отправили на него новый пароль.<br>' +
                'Не забудьте сменить его в личном кабинете в разделе «Безопасность».';
            // small delay then send user back to login
            setTimeout(() => { showLoginView(); }, 4500);
        } else {
            errorEl.textContent = data.error || 'Не удалось отправить письмо. Попробуйте позже.';
            submitBtn.disabled  = false;
        }
    } catch {
        errorEl.textContent = 'Ошибка соединения';
        submitBtn.disabled  = false;
    }
}

// ─── Register ─────────────────────────────────────────────────
async function handleRegister(e) {
    e.preventDefault();
    const username  = document.getElementById('reg-username').value.trim();
    const email     = document.getElementById('reg-email').value.trim();
    const password  = document.getElementById('reg-password').value;
    const password2 = document.getElementById('reg-password2').value;
    const errorEl   = document.getElementById('reg-error');
    const submitBtn = document.getElementById('reg-submit');

    if (!username || !email || !password || !password2) {
        errorEl.textContent = 'Заполните все поля'; return;
    }
    if (hasNonLatin(username)) {
        errorEl.textContent = 'Логин должен содержать только латинские символы'; return;
    }
    if (hasNonLatin(password) || hasNonLatin(password2)) {
        errorEl.textContent = 'Пароль должен содержать только латинские символы'; return;
    }
    if (password !== password2) {
        errorEl.textContent = 'Пароли не совпадают'; return;
    }
    if (password.length < 6) {
        errorEl.textContent = 'Пароль минимум 6 символов'; return;
    }

    submitBtn.disabled  = true;
    submitBtn.textContent = 'Регистрируем...';
    errorEl.textContent = '';

    try {
        const res  = await fetch('/api/register', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username, email, password }),
        });
        const data = await res.json();
        if (data.success) {
            showVerifyView(data.email || email);
        } else {
            errorEl.textContent = data.error || 'Ошибка регистрации';
            submitBtn.disabled  = false;
            submitBtn.innerHTML = 'Зарегистрироваться <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M5 10h10M10 5l5 5-5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        }
    } catch {
        errorEl.textContent = 'Ошибка соединения';
        submitBtn.disabled  = false;
        submitBtn.innerHTML = 'Зарегистрироваться <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M5 10h10M10 5l5 5-5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
}

// ─── Email Verify ─────────────────────────────────────────────
async function handleVerifyCode() {
    const code    = document.getElementById('verify-code-input').value.trim();
    const errorEl = document.getElementById('verify-error');
    if (!code || code.length !== 6) {
        errorEl.textContent = 'Введите 6-значный код'; return;
    }
    // Placeholder — actual email verification to be implemented
    errorEl.textContent = 'Функция подтверждения почты будет доступна в ближайшее время.';
    errorEl.style.color = '#FBBF24';
}

// ─── Mobile Menu ─────────────────────────────────────────────
function toggleMobileMenu() {
    const menu = document.getElementById('nav-mobile');
    menu.classList.toggle('open');
}

// ─── Stats Counter Animation ─────────────────────────────────
function animateCounters() {
    const els = document.querySelectorAll('.stat-number[data-target]');
    els.forEach(el => {
        const target   = parseInt(el.dataset.target);
        const duration = 2000;
        const step     = 16;
        const steps    = Math.ceil(duration / step);
        let current    = 0;
        const increment = target / steps;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                el.textContent = target;
                clearInterval(timer);
            } else {
                el.textContent = Math.floor(current);
            }
        }, step);
    });
}

// Trigger counter animation when stats section is visible
const statsObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            animateCounters();
            statsObs.disconnect();
        }
    });
}, { threshold: 0.4 });

const statsSection = document.getElementById('stats');
if (statsSection) statsObs.observe(statsSection);

// ─── Smooth scroll for nav links ─────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        const id = a.getAttribute('href').slice(1);
        const el = document.getElementById(id);
        if (el) {
            e.preventDefault();
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// ─── Trust bar toggle ─────────────────────────────────────────
function toggleAllServers() {
    const container = document.getElementById('trust-all-servers');
    const btn = document.getElementById('trust-more-btn');
    if (!container || !btn) return;
    if (container.style.display === 'none') {
        container.style.display = 'flex';
        btn.textContent = 'скрыть';
    } else {
        container.style.display = 'none';
        btn.textContent = 'и ещё 28...';
    }
}

// ─── Navbar scroll effect ─────────────────────────────────────
window.addEventListener('scroll', () => {
    const nav = document.querySelector('.navbar');
    if (!nav) return;
    if (window.scrollY > 40) {
        nav.style.borderBottomColor = 'rgba(91,95,239,0.2)';
    } else {
        nav.style.borderBottomColor = 'rgba(255,255,255,0.06)';
    }
});

// ─── Mobile Drawer (left side popup) ────────────────────────
function openMobileDrawer() {
    document.getElementById('mobile-drawer').classList.add('open');
    document.getElementById('mobile-drawer-backdrop').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeMobileDrawer() {
    document.getElementById('mobile-drawer').classList.remove('open');
    document.getElementById('mobile-drawer-backdrop').classList.remove('open');
    document.body.style.overflow = '';
}
function scrollToHero() {
    const target = document.getElementById('hero') || document.body;
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
