# Road66 — Arizona Scanner v3.0

## Overview
A web-based dashboard for monitoring arbitrage opportunities, inventory tracking, and activity logs related to the Arizona (SAMP) online game marketplace.

## Tech Stack
- **Backend:** Python (Flask)
- **Frontend:** HTML/CSS/JavaScript (Jinja2 templates)
- **Database:** SQLite (`average_prices.db`, `sync_data.db`)
- **Data Storage:** JSON files (inventory, balance, config, logs)
- **Automation:** Lua scripts for in-game data collection

## Project Structure
- `Road66/app.py` — Main Flask application
- `Road66/run.py` — Development server launcher
- `Road66/arbitrage_engine.py` — Core arbitrage logic
- `Road66/arbitrage_servers/` — Per-server arbitrage scripts
- `Road66/templates/` — HTML templates (`index.html`, `landing.html`)
- `Road66/static/` — CSS, JS, and map marker assets
- `Road66/requirements.txt` — Python dependencies

## Running the App
- Development: `cd Road66 && python run.py` (port 5000)
- Production: `cd Road66 && gunicorn --bind=0.0.0.0:5000 --reuse-port --workers=1 --timeout=120 app:app`

## Key Features
- Arbitrage scanner across multiple game servers
- Real-time price scanning and average price tracking
- Inventory management with buy/sell tracking
- Balance history and trade log (via Lua sync)
- User authentication with admin/basic/pro/free plans
- Arizona in-game map integration (GPU-accelerated via `will-change: transform`)
- Admin section toggle panel (enable/disable sections for all users)
- Blocked-account session polling: frontend checks `/api/me` every 60s, redirects to landing if blocked/401

## Recent Changes (v6 static assets)
- "Начать бесплатно" pricing button now correctly opens registration modal
- Removed Автоскан and Авто-арби toggle buttons from scanner/arbitrage action bars
- Topbar logo replaced with cleaner SVG matching loader/footer design
- Standalone `server-select` elements styled with `server-select-standalone` class (border/bg)
- Scanner item-row min-width reduced for better display on narrow screens
- Blocked account immediately kicks user (session polling every 60s)

## Deployment
- Target: VM (always-running, uses background threads and SQLite state)
- Port: 5000
