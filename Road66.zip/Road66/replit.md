# Road66 — Arizona Scanner v3.0

## Overview
A web-based dashboard for monitoring arbitrage opportunities, inventory tracking, and activity logs related to the Arizona (SAMP) online game marketplace.

## Tech Stack
- **Backend:** Python 3.11 (Flask)
- **Frontend:** HTML/CSS/JavaScript (Jinja2 templates)
- **Database:** SQLite (`average_prices.db`, `sync_data.db`)
- **Data Storage:** JSON files (inventory, balance, config, logs)
- **Automation:** Lua script for in-game data collection

## Project Structure
```
.
├── backend/                  # Python Flask server
│   ├── app.py                # Main Flask application
│   ├── run.py                # Development server launcher
│   ├── arbitrage_engine.py   # Core arbitrage logic
│   ├── chatlog_scanner.py    # In-game chatlog → inventory parser
│   ├── arbitrage_servers/    # Per-server arbitrage scripts (32 servers)
│   ├── data/                 # Runtime state (JSON + SQLite databases)
│   └── requirements.txt
├── frontend/                 # Static web assets served by Flask
│   ├── templates/            # Jinja2 templates (index.html, landing.html)
│   └── static/               # CSS, JS, images, uploads
├── lua/                      # In-game Lua automation script
│   └── road66.lua
├── pyproject.toml            # Python project metadata
└── replit.md
```

The Flask app in `backend/app.py` is configured with `template_folder` and `static_folder` pointing to the sibling `frontend/` directory, and `/download/road66.lua` serves the script from the `lua/` directory.

## Running the App
- Development: `python backend/run.py` (port 5000, host 0.0.0.0) — managed by the `Start application` workflow.
- Production: `cd backend && gunicorn --bind=0.0.0.0:5000 --reuse-port --workers=1 --timeout=120 app:app`

## Replit Environment Setup (April 28, 2026)
- Imported from a Github archive. The project was nested under a `Road66/` folder; contents were lifted to the repo root.
- Python 3.11 runtime configured via `pyproject.toml`; dependencies (`flask`, `gunicorn`, `requests`) installed into the workspace virtualenv.
- Workflow `Start application` runs `python backend/run.py`, listens on port 5000, output type `webview`.
- Flask binds `0.0.0.0:5000` (proxy-friendly) — works with the Replit iframe preview as-is.
- Deployment target: VM (always-running, uses background threads + SQLite state).

## Key Features
- Arbitrage scanner across multiple game servers
- Real-time price scanning and average price tracking
- Inventory management with buy/sell tracking
- Balance history and trade log (via Lua sync)
- User authentication with admin/basic/pro/free plans
- Arizona in-game map integration (GPU-accelerated via `will-change: transform`)
- Admin section toggle panel (enable/disable sections for all users)
- Blocked-account session polling: frontend checks `/api/me` every 60s, redirects to landing if blocked/401
