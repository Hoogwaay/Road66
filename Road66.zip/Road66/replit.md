# Arizona Scanner v3.0 (Road66)

## Overview
Web-based Flask tool for Arizona RP market/arbitrage scanning. The imported app lives in the `Road66/` directory and uses JSON files plus a local SQLite database for persistence.

## Tech Stack
- Python 3.11
- Flask 3.0.3
- Jinja templates with static CSS/JS
- SQLite for average price snapshots
- Gunicorn for production

## Runtime Notes
- Development workflow command: `cd Road66 && python run.py`
- Web preview port: `5000`
- Production run command: `bash -c 'cd Road66 && gunicorn --bind=0.0.0.0:5000 --reuse-port app:app'`
- App data is stored inside `Road66/`; run commands should keep `Road66` as the working directory.
- Average prices are stored in `Road66/average_prices.db` and refreshed by a background scanner every 30 minutes.

## Average Prices Feature
- Item catalog source: `https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items`
- Marketplace source: `https://api.arz.market/api/getSelectedMarketplace/-1`
- Backend endpoints:
  - `GET /api/average-prices?server=<id>&q=<search>` returns items, max buy price, min sell price, and daily average for the selected server.
  - `POST /api/average-prices/scan` manually collects a fresh snapshot across all marketplace servers.
- UI tab: `Средние цены` with server selector, search, current max buy/min sell values, and daily average price.
