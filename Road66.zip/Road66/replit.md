# Road66 — Arizona Scanner v3.0

## Overview
A web-based dashboard for monitoring arbitrage opportunities, inventory tracking, and activity logs related to the Arizona (SAMP) online game marketplace.

## Tech Stack
- **Backend:** Python 3.11 (Flask)
- **Frontend:** HTML/CSS/JavaScript (Jinja2 templates)
- **Database:** SQLite (`average_prices.db`, `sync_data.db`)
- **Data Storage:** JSON files (inventory, balance, config, logs)
- **Automation:** Lua script for in-game data collection

## Project Structure
```
.
├── backend/                  # Python Flask server
│   ├── app.py                # Main Flask application
│   ├── run.py                # Development server launcher
│   ├── arbitrage_engine.py   # Core arbitrage logic
│   ├── chatlog_scanner.py    # In-game chatlog → inventory parser
│   ├── arbitrage_servers/    # Per-server arbitrage scripts (32 servers)
│   ├── data/                 # Runtime state (JSON + SQLite databases)
│   └── requirements.txt
├── frontend/                 # Static web assets served by Flask
│   ├── templates/            # Jinja2 templates (index.html, landing.html)
│   └── static/               # CSS, JS, images, uploads
├── lua/                      # In-game Lua automation script
│   └── road66.lua
├── pyproject.toml            # Python project metadata
└── replit.md
```

The Flask app in `backend/app.py` is configured with `template_folder` and `static_folder` pointing to the sibling `frontend/` directory, and `/download/road66.lua` serves the script from the `lua/` directory.

## Running the App
- Development: `cd backend && python3 run.py` (port 5000, host 0.0.0.0)
- Production: `cd backend && gunicorn --bind=0.0.0.0:5000 --reuse-port --workers=1 --timeout=120 app:app`

## Key Features
- Arbitrage scanner across multiple game servers
- Real-time price scanning and average price tracking
- Inventory management with buy/sell tracking
- Balance history and trade log (via Lua sync)
- User authentication with admin/basic/pro/free plans
- Arizona in-game map integration (GPU-accelerated via `will-change: transform`)
- Admin section toggle panel (enable/disable sections for all users)
- Blocked-account session polling: frontend checks `/api/me` every 60s, redirects to landing if blocked/401

## Recent Changes
- Restructured project into `backend/`, `frontend/`, and `lua/` folders for clarity
- Runtime data files (JSON + SQLite) consolidated into `backend/data/`
- Flask app updated to reference templates/static and the lua download from the new locations
- Redesigned login/registration modal in Golden Suisse split-layout style:
  black brand panel (left) + dark form panel (right) with underline inputs
  and large white circular submit button at bottom-right.
  GOTCHA: the `view-enter` keyframe animation on `.auth-view` must NOT use
  `transform` — `animation-fill-mode: forwards` would leave a transform on
  the element, making it the containing block for the absolutely-positioned
  `.auth-submit` and breaking the `bottom: 56px` anchoring. Animate opacity only.

- Mobile UX (≤640px landing, ≤768px dashboard):
  - Landing carousels (features/steps/pricing) use `padding: 4px 8vw 16px` +
    `flex: 0 0 84vw` + `scroll-snap-align: center` so the FIRST and LAST
    cards center properly (snap point lands at scrollLeft=0 / max).
  - Landing top login button hidden on mobile (`.nav-actions { display:none }`).
  - Landing bottom bar = Меню | Вход | Регистрация (mbb-cta = bordered gradient
    pill for the registration call-to-action).
  - Dashboard sidebar becomes a slide-in drawer on ≤768px via `.sidebar.open`
    + `#sidebar-backdrop` (controlled by `openSidebarDrawer/closeSidebarDrawer`
    in main.js; auto-closes when any sidebar nav-item is tapped).
  - Dashboard bottom-nav simplified on mobile to Меню | Рынок | Арбитраж — all
    other `.bnav-item`s carry `bnav-hide-mobile` (`display:none` at ≤768px).

## Deployment
- Target: VM (always-running, uses background threads and SQLite state)
- Port: 5000
