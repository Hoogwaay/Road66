# Road66

## Overview
This project is a Flask web app for Arizona RP market/arbitrage scanning. The imported application code lives in `Road66/Road66/`; the top-level project is configured to run that nested app in Replit.

## Tech Stack
- Python 3.11
- Flask 3.0.3
- Gunicorn for production
- Jinja templates with static CSS/JS
- Local JSON files and SQLite databases for app data

## Runtime
- Development workflow: `bash -c 'cd Road66/Road66 && python run.py'`
- Web preview port: 5000
- Production command: `bash -c 'cd Road66/Road66 && gunicorn --bind=0.0.0.0:5000 --reuse-port app:app'`

## Project Layout
- `road66.lua` — Lua script to copy into MoonLoader; this is the canonical downloadable sync script
- `Road66/Road66/app.py` — main Flask application
- `Road66/Road66/run.py` — development launcher bound to `0.0.0.0:5000`
- `Road66/Road66/templates/` — HTML templates
- `Road66/Road66/static/` — CSS, JavaScript, and image assets
- `Road66/Road66/*.json` and `Road66/Road66/*.db` — local app data

## Lua Sync Notes
- The in-game script creates `moonloader/ArzMarket/UsersInfo/trade_log.json` on startup.
- Recognized trades are written locally to that JSON file and sent to `/api/sync/trades`.
- `road66.lua` uses `lib.samp.events` and includes `/r66trades` plus `/r66` diagnostics for captured chat messages, captured trades, pending queue, and sent trades.
