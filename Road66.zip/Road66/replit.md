# Road66 / ARZscaner

## Overview
A Flask web application for Arizona RP arbitrage scanning. The imported source is contained in the `Road66/` directory.

## Architecture
- Backend: Python Flask 3.0.3
- Frontend: server-rendered HTML templates with static CSS/JavaScript
- Data storage: JSON files in `Road66/` (`balance.json`, `inventory.json`, `currencyrate.json`, etc.)
- No external database is configured or required

## Key Files
- `Road66/app.py` - main Flask app and routes
- `Road66/run.py` - development launcher, binds to `0.0.0.0:5000`
- `Road66/templates/` - Jinja templates
- `Road66/static/` - frontend assets
- `Road66/requirements.txt` and `Road66/pyproject.toml` - Python dependencies

## Replit Setup
- Workflow: `Start application`
- Development command: `cd Road66 && python3 run.py`
- Preview port: `5000`
- Deployment target: VM
- Production command: `cd Road66 && gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`
