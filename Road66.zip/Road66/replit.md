# Arizona Scanner v3.0 (Road66)

## Overview
Web-based Flask tool for Arizona RP market/arbitrage scanning. The app lives in the `Road66/` directory and uses JSON files plus a local SQLite database for persistence.

## Tech Stack
- Python 3.11
- Flask 3.0.3
- Jinja templates with static CSS/JS
- SQLite for average price snapshots
- Gunicorn for production

## Project Structure
- `Road66/app.py` — Main Flask application
- `Road66/run.py` — Development launcher
- `Road66/arbitrage_engine.py` — Core arbitrage scanning logic
- `Road66/arbitrage_servers/` — Per-server arbitrage modules
- `Road66/templates/` — Jinja2 HTML templates
- `Road66/static/` — CSS, JS, and image assets
- `Road66/average_prices.db` — SQLite DB for price history
- `Road66/*.json` — Data files (inventory, balance, credentials, cache)

## Runtime Notes
- Development workflow command: `cd Road66 && python run.py`
- Web preview port: `5000`
- Production run command: `bash -c 'cd Road66 && gunicorn --bind=0.0.0.0:5000 --reuse-port app:app'`
- App data is stored inside `Road66/`; run commands keep `Road66` as the working directory.

## Game Sync Feature (v1.1)
- Each user has a unique 24-character API key in Settings → "API ключ синхронизации"
- Keys are auto-generated for all users on startup; can be regenerated in settings
- Lua script: `Road66/luascripts/road66.lua` — place in MoonLoader `scripts/` folder
- In-game command: `/r66` opens the sync panel; enter API key + server URL
- Balance sync: sent every 30 seconds via `POST /api/sync/balance`
- Trade sync: captured from SAMP chat messages, sent via `POST /api/sync/trades`
- Dashboard stats (current balance, today's income, all-time income) update from sync data
- Trade journal in Dashboard shows all trades captured from the game client
- Sync DB: `Road66/sync_data.db` (tables: `balance_history`, `trade_log`)
- Auth for Lua: `X-API-Key` header or `api_key` field in JSON body

## Average Prices Feature
- Item catalog source: `https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items`
- Marketplace source: `https://api.arz.market/api/getSelectedMarketplace/-1`
- Backend endpoints:
  - `GET /api/average-prices?server=<id>&q=<search>` returns items, max buy price, min sell price, and daily average for the selected server.
  - `POST /api/average-prices/scan` manually collects a fresh snapshot across all marketplace servers.
- UI tab: `Средние цены` with server selector, search, current max buy/min sell values, and daily average price.
