# Arizona Scanner v3.0 (ARZscaner)

## Overview
A web-based arbitrage scanning and management tool for the Arizona RP (GTA SA-MP) game server. Tracks currency rates, inventory, and market data across 32 game servers to identify profitable arbitrage opportunities.

## Tech Stack
- **Backend:** Python 3.11, Flask 3.0.3
- **Templates:** Jinja2 (HTML5 + CSS3 + JS)
- **Data Storage:** Flat JSON files (no SQL database)
- **Concurrency:** Python threading for background scan tasks
- **WSGI Server (prod):** Gunicorn

## Project Structure
- `app.py` — Main Flask application (routes, API endpoints, background workers)
- `run.py` — Development launcher
- `arbitrage_engine.py` — Core arbitrage calculation logic
- `chatlog_scanner.py` — Game chat log parser
- `arbitrage_servers/` — Per-server monitoring scripts (32 servers)
- `static/` — CSS, JS, map marker images
- `templates/` — HTML templates (index.html, landing.html)
- `Data_Cred.json` — User credentials and roles
- `balance.json` — Account balance data
- `inventory.json` — Inventory tracking
- `currencyrate.json` — Currency rates per server
- `activity_log.json` — Activity log
- `arizona_map_cache.json` — Map data cache
- `trash_map.json` — Trash location map data

## Running the App
- **Development:** `python3 run.py` (runs on 0.0.0.0:5000)
- **Production:** `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`

## Key Features
- Arbitrage scanning across 32 Arizona RP servers
- Inventory management per character/server
- Currency rate tracking
- Interactive game-world map with Leaflet
- Tiered user access (Free, Basic, Pro plans)
- Market search ("lavki" — player shops)

## Dependencies
- flask==3.0.3
- gunicorn
- requests==2.32.3
