import zipfile
import sys
z = zipfile.ZipFile("Road66.zip")
z.printdir()