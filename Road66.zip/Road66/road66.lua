script_name('Road66 Sync v1.0')
script_author('Road66 Market')
script_version('1.0')

-- ============================================================
-- Road66 Sync — объединённый скрипт
-- Баланс + Журнал сделок + CEF интерфейс (/r66)
-- ============================================================

require 'lib.moonloader'
local sampev   = require 'lib.samp.events'
local json     = require 'dkjson'
local imgui    = require 'mimgui'
local encoding = require 'encoding'
local requests = require 'requests'
local ffi      = require 'ffi'

encoding.default = 'CP1251'
u8 = encoding.UTF8

-- ── Конфигурация ─────────────────────────────────────────────
local CFG_FILE    = getWorkingDirectory() .. '/road66_config.json'
local BAL_FILE    = getWorkingDirectory() .. '/road66_balance.json'
local TRADE_DIR   = 'moonloader/ArzMarket/UsersInfo'
local TRADE_FILE  = TRADE_DIR .. '/trade_log.json'
local SYNC_INTERVAL = 30  -- секунд между отправками баланса

-- ── Состояние ────────────────────────────────────────────────
local cfg = {
    api_key    = '',
    server_url = 'http://localhost:5000',
    debug_chat = false,
}
local current_balance     = 0
local balance_known       = false
local last_sync_time      = 0
local sync_ok             = false
local sync_status_msg     = ''
local pending_trades      = {}
local trades_sent         = 0
local chat_seen           = 0
local trades_captured     = 0
local last_chat_message   = ''
local last_trade_error    = ''

-- ── imgui окно ───────────────────────────────────────────────
local wnd_open     = imgui.new.bool(false)
local inp_api_key  = imgui.new.char[128]('')
local inp_srv_url  = imgui.new.char[256]('')
local status_msg   = imgui.new.char[256]('')
local chk_debug    = imgui.new.bool(false)

-- ── Утилиты ──────────────────────────────────────────────────
local function chat(msg)
    if isSampAvailable() then
        sampAddChatMessage('{66CCFF}[Road66]{FFFFFF} ' .. msg, -1)
    end
end

local function fmt_money(n)
    n = math.floor(tonumber(n) or 0)
    local s = tostring(n):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^%s+','')
    return '$' .. s
end

local function get_player_nick()
    local nick = 'Unknown'
    pcall(function()
        if sampGetPlayerNickname then
            nick = sampGetPlayerNickname() or 'Unknown'
        end
    end)
    return nick
end

-- ── Конфиг IO ────────────────────────────────────────────────
local function load_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'r')
        if f then
            local ok, t = pcall(json.decode, f:read('*a'))
            f:close()
            if ok and type(t) == 'table' then
                cfg.api_key    = t.api_key    or ''
                cfg.server_url = t.server_url or 'http://localhost:5000'
                cfg.debug_chat = t.debug_chat or false
            end
        end
    end)
end

local function save_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'w')
        if f then
            f:write(json.encode({ api_key = cfg.api_key, server_url = cfg.server_url, debug_chat = cfg.debug_chat }))
            f:close()
        end
    end)
end

-- ── Баланс IO ────────────────────────────────────────────────
local function save_balance()
    pcall(function()
        local f = io.open(BAL_FILE, 'w')
        if f then
            f:write(json.encode({ balance = current_balance, ts = os.time() }))
            f:close()
        end
    end)
end

-- ── Сделки IO ────────────────────────────────────────────────
local function ensure_trade_dir()
    pcall(function()
        if doesDirectoryExist and createDirectory then
            if not doesDirectoryExist('moonloader/ArzMarket') then createDirectory('moonloader/ArzMarket') end
            if not doesDirectoryExist(TRADE_DIR) then createDirectory(TRADE_DIR) end
        end
    end)
    pcall(function()
        os.execute('mkdir "' .. TRADE_DIR .. '" >nul 2>nul')
    end)
end

local function default_trade_log()
    return {
        stats = { total_sell = 0, total_buy = 0, total_sum_sell = 0, total_sum_buy = 0 },
        trades = {}
    }
end

local function read_trade_log()
    ensure_trade_dir()
    local data = default_trade_log()
    local f = io.open(TRADE_FILE, 'r')
    if not f then return data end
    local raw = f:read('*a')
    f:close()
    if not raw or raw == '' then return data end
    local ok, decoded = pcall(json.decode, raw)
    if ok and type(decoded) == 'table' then
        if type(decoded.stats) == 'table' and type(decoded.trades) == 'table' then
            return decoded
        end
        if #decoded > 0 then
            data.trades = decoded
        end
    end
    return data
end

local function write_trade_log(data)
    ensure_trade_dir()
    local f = io.open(TRADE_FILE, 'w')
    if f then
        f:write(json.encode(data, { indent = true }))
        f:close()
    end
end

local function init_trade_log()
    local f = io.open(TRADE_FILE, 'r')
    if f then
        f:close()
        return
    end
    write_trade_log(default_trade_log())
end

local function append_trade(trade)
    table.insert(pending_trades, trade)
    trades_captured = trades_captured + 1
    last_sync_time = 0
    pcall(function()
        local data = read_trade_log()
        local entry = {
            type = trade.action,
            item = trade.item,
            count = trade.quantity,
            price = trade.price,
            total = trade.total,
            currency = trade.currency or '',
            nick = trade.nick or get_player_nick(),
            date = os.date('%d.%m.%Y'),
            time = os.date('%H:%M:%S')
        }
        table.insert(data.trades, 1, entry)
        if trade.action == 'sell' or trade.action == 'player_buy' then
            data.stats.total_sell = (data.stats.total_sell or 0) + 1
            data.stats.total_sum_sell = (data.stats.total_sum_sell or 0) + (tonumber(trade.total) or 0)
        else
            data.stats.total_buy = (data.stats.total_buy or 0) + 1
            data.stats.total_sum_buy = (data.stats.total_sum_buy or 0) + (tonumber(trade.total) or 0)
        end
        if #data.trades > 1000 then
            for i = #data.trades, 1001, -1 do
                table.remove(data.trades, i)
            end
        end
        write_trade_log(data)
    end)
end

-- ── HTTP helper ──────────────────────────────────────────────
local function post_json(url, body_table)
    local ok, res = pcall(function()
        return requests.post(url, {
            headers = {
                ['Content-Type'] = 'application/json',
                ['X-API-Key']    = cfg.api_key,
            },
            data = json.encode(body_table),
            timeout = 8,
        })
    end)
    if ok and res then
        local status = res.status_code or 0
        local ok2, data = pcall(json.decode, res.text or '')
        return ok2 and data or { success = status >= 200 and status < 300 }
    end
    return nil
end

-- ── Проверка подключения (пинг API ключа) ────────────────────
local function test_connection()
    if cfg.api_key == '' then
        sync_ok         = false
        sync_status_msg = u8:decode('✗ Введите API ключ')
        return
    end
    local url  = cfg.server_url .. '/api/sync/ping'
    local data = post_json(url, { api_key = cfg.api_key })
    if data and data.success then
        sync_ok         = true
        sync_status_msg = u8:decode('✓ Подключено! Пользователь: ' .. (data.username or ''))
    elseif data and data.error then
        sync_ok         = false
        sync_status_msg = u8:decode('✗ ' .. tostring(data.error))
    else
        sync_ok         = false
        sync_status_msg = u8:decode('✗ Нет ответа от сервера. Проверь URL.')
    end
end

-- ── Синхронизация баланса ─────────────────────────────────────
local function sync_balance()
    if cfg.api_key == '' then return end
    if not balance_known then
        -- Баланс ещё неизвестен — пропускаем, но не меняем статус
        return
    end
    local url  = cfg.server_url .. '/api/sync/balance'
    local data = post_json(url, { api_key = cfg.api_key, balance = current_balance })
    if data and data.success then
        sync_ok         = true
        sync_status_msg = u8:decode('✓ Баланс отправлен: ' .. fmt_money(current_balance))
    else
        sync_ok         = false
        sync_status_msg = u8:decode('✗ Ошибка отправки баланса')
    end
end

-- ── Синхронизация сделок ──────────────────────────────────────
local function sync_pending_trades()
    if cfg.api_key == '' then return end
    if #pending_trades == 0 then return end
    local url    = cfg.server_url .. '/api/sync/trades'
    local to_send = {}
    for _, t in ipairs(pending_trades) do table.insert(to_send, t) end
    pending_trades = {}
    local data = post_json(url, { api_key = cfg.api_key, trades = to_send })
    if data and data.success then
        trades_sent = trades_sent + (data.inserted or #to_send)
    else
        for _, t in ipairs(to_send) do table.insert(pending_trades, t) end
    end
end

-- ── Парсинг баланса ──────────────────────────────────────────

local function parse_part_value(value, scale)
    value = tostring(value or '')
    local whole, frac = value:match('^(%d+)%.(%d+)$')
    if whole then
        local base = tonumber(whole) or 0
        local decimals = tonumber(frac) or 0
        local factor = 10 ^ #frac
        return base * scale + math.floor(decimals * scale / factor)
    end
    return (tonumber(value) or 0) * scale
end

local function is_balance_text(text)
    if type(text) ~= 'string' then return false end
    local low = text:lower()
    return low:find('наличн') and (low:find('sa%$') or low:find('stats') or low:find('статистик'))
end

local function extract_balance(text)
    if not is_balance_text(text) then return nil end
    local total, found = 0, false
    for p in text:gmatch(':M:%s*([%d%.]+)')  do total = total + parse_part_value(p, 1000000000); found = true end
    for p in text:gmatch(':KK:%s*([%d%.]+)') do total = total + parse_part_value(p, 1000000);    found = true end
    for p in text:gmatch(':K:%s*([%d%.]+)')  do total = total + parse_part_value(p, 1000);       found = true end
    return found and total or nil
end

local function set_balance(num)
    num = tonumber(num) or 0
    if num < 0 then num = 0 end
    current_balance = math.floor(num)
    balance_known   = true
    save_balance()
end

-- ── Парсинг чата (сделки) ────────────────────────────────────
-- Вспомогательная: убирает пробелы из числа "1 000" -> 1000
local function parse_num(s)
    if not s then return 0 end
    return tonumber(tostring(s):gsub('[%s%. ]', '')) or 0
end

local CP_BUY_WORD  = string.char(0xEA, 0xF3, 0xEF, 0xE8, 0xEB, 0xE8)
local CP_SELL_WORD = string.char(0xEF, 0xF0, 0xEE, 0xE4, 0xE0, 0xEB, 0xE8)
local CP_SHT_WORD  = string.char(0xF8, 0xF2)

local function strip_chat_markup(s)
    return tostring(s or ''):gsub('{%x%x%x%x%x%x}', ''):gsub('\194\160', ' ')
end

local function trim(s)
    return tostring(s or ''):match('^%s*(.-)%s*$')
end

local function append_parsed_trade(action, item, qty, price, total, currency)
    qty = tonumber(qty) or 1
    price = parse_num(price)
    total = parse_num(total)
    if total == 0 then total = qty * price end
    local clean_item = trim(item)
    if clean_item == '' then clean_item = 'Unknown' end
    append_trade({
        action = action,
        item = clean_item,
        quantity = qty,
        count = qty,
        price = price,
        total = total,
        currency = currency or '',
        nick = get_player_nick(),
        type = action,
        ts = os.date('%Y-%m-%d %H:%M:%S')
    })
    if cfg.debug_chat then
        local label = action == 'sell' and 'Продажа' or 'Покупка'
        chat(u8('Сделка: ') .. u8(label) .. ' ' .. clean_item .. ' x' .. tostring(qty) .. ' = ' .. tostring(total) .. ' ' .. tostring(currency or ''))
    end
end

local function try_parse_trade_raw(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    msg = strip_chat_markup(msg)

    local item, qty, price = msg:match('%[sell%] (.+) x(%d+) | (%d+) VC%$')
    if item then
        append_parsed_trade('sell', tostring(u8(item)), qty, price, tonumber(qty) * parse_num(price), 'VC$')
        return true
    end

    item, qty, price = msg:match('%[buy%] (.+) x(%d+) | (%d+) VC%$')
    if item then
        append_parsed_trade('buy', tostring(u8(item)), qty, price, tonumber(qty) * parse_num(price), 'VC$')
        return true
    end

    local price_raw = msg:match(':K:%s*([%d%.]+)') or msg:match(':K:%s*([%d%s%.]+)')
    if not price_raw then return false end

    local action
    if msg:find(CP_BUY_WORD, 1, true) then
        action = 'buy'
    elseif msg:find(CP_SELL_WORD, 1, true) then
        action = 'sell'
    else
        return false
    end

    qty = msg:match('%((%d+)%s+' .. CP_SHT_WORD .. '%.?%)') or msg:match('%((%d+)') or msg:match('[xXхХ](%d+)') or '1'

    local item_raw
    if action == 'buy' then
        item_raw = msg:match(CP_BUY_WORD .. '%s+(.-)%s+%(%d') or msg:match(CP_BUY_WORD .. '%s+(.+)%s+:K:')
    else
        item_raw = msg:match(CP_SELL_WORD .. '%s+(.-)%s+%(%d') or msg:match(CP_SELL_WORD .. '%s+(.+)%s+:K:')
    end

    local item_utf8 = item_raw and tostring(u8(item_raw)) or 'Unknown'
    append_parsed_trade(action, item_utf8, qty, price_raw, tonumber(qty) * parse_num(price_raw), 'K')
    return true
end

local function try_parse_trade_from_chat(msg)
    if type(msg) ~= 'string' or msg == '' then return end

    local item, qty, price, total

    -- ── Покупка ───────────────────────────────────────────────
    -- "Вы купили Арбуз x10 по $5 000 (итого: $50 000)"
    item, qty, price = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber(qty) * parse_num(price) end
        append_parsed_trade('buy', item, qty, price, total, '$')
        return
    end
    -- "Вы купили Арбуз x10 за $50 000"
    item, qty, total = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q>0 and math.floor(t/q) or 0), t, '$')
        return
    end
    -- "Вы приобрели Арбуз (10 шт.) за $50 000"
    item, qty, total = msg:match('[Вв]ы приобрели%s+(.-)%s+%((%d+)%s*[шШ][тТ]%.?%)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q>0 and math.floor(t/q) or 0), t, '$')
        return
    end

    -- ── Продажа ───────────────────────────────────────────────
    -- "Вы продали Арбуз x10 по $6 000 (итого: $60 000)"
    item, qty, price = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber(qty) * parse_num(price) end
        append_parsed_trade('sell', item, qty, price, total, '$')
        return
    end
    -- "Вы продали Арбуз x10 за $60 000"
    item, qty, total = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_parsed_trade('sell', item, q, (q>0 and math.floor(t/q) or 0), t, '$')
        return
    end

    -- ── Продажа игроку / покупка у тебя ──────────────────────
    -- "Игрок купил у вас Арбуз x10 за $60 000"
    item, qty, total = msg:match('[Ии]грок купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q>0 and math.floor(t/q) or 0), t, '$')
        return
    end
    -- "купил у вас Арбуз x10 за $60 000"  (без "Игрок")
    item, qty, total = msg:match('купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q>0 and math.floor(t/q) or 0), t, '$')
    end
end

-- ── CEF пакет 220 (updateMoney) ──────────────────────────────
local function safe_raknet_read(bs, fn)
    local ok, v = pcall(fn, bs)
    return ok and v or nil
end

local add_handler = addEventHandler or registerHandler
if add_handler then
    add_handler('onReceivePacket', function(id, bs)
        if id ~= 220 then return end
        pcall(function()
            raknetBitStreamIgnoreBits(bs, 8)

            local packet_id = safe_raknet_read(bs, function() return raknetBitStreamReadInt8(bs) end)
            if packet_id ~= 17 then return end

            safe_raknet_read(bs, function() return raknetBitStreamReadInt32(bs) end)

            local text = safe_raknet_read(bs, function()
                local len = safe_raknet_read(bs, function() return raknetBitStreamReadInt16(bs) end)
                local enc = safe_raknet_read(bs, function() return raknetBitStreamReadInt8(bs) end)
                if len and len > 0 then
                    if enc == 0 then return raknetBitStreamReadString(bs, len)
                    else return raknetBitStreamDecodeString(bs, len + 1) end
                end
                return ''
            end)

            if text and text:find('event.player.updateMoney') then
                local jp = text:match('`(.*)`')
                if jp then
                    local ok2, decoded = pcall(json.decode, jp)
                    if ok2 and type(decoded) == 'table' then
                        local money = tonumber(decoded[1])
                        if money and money >= 0 then set_balance(money) end
                    end
                end
            end
        end)
    end)
end

-- ── SAMP события ─────────────────────────────────────────────
function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
    pcall(function()
        for _, s in ipairs({ title, text }) do
            if is_balance_text(s or '') then
                local cash = extract_balance(s)
                if cash then set_balance(cash) end
            end
        end
    end)
end

function sampev.onServerMessage(color, msg)
    local ok, err = pcall(function()
        chat_seen = chat_seen + 1
        last_chat_message = tostring(msg or '')
        if try_parse_trade_raw(msg or '') then return end
        local decoded = u8:decode(strip_chat_markup(msg or ''))
        last_chat_message = decoded
        if cfg.debug_chat and decoded ~= '' then
            sampAddChatMessage('{888888}[R66 msg] ' .. decoded, -1)
        end
        try_parse_trade_from_chat(decoded)
    end)
    if not ok then
        last_trade_error = tostring(err or '')
        if cfg.debug_chat then
            sampAddChatMessage('{FF5555}[R66 error] ' .. last_trade_error, -1)
        end
    end
end

function sampev.onResetPlayerMoney() return false end
function sampev.onGivePlayerMoney(money) return false end

-- ── imgui рендер ─────────────────────────────────────────────
local new = imgui.new

local function imgui_window()
    imgui.SetNextWindowSize(imgui.ImVec2(480, 340), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(200, 200), imgui.Cond.FirstUseEver)

    imgui.Begin(u8('Road66 Sync  v1.0'), wnd_open, imgui.WindowFlags.NoCollapse)

    imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.4, 0.75, 1.0, 1.0))
    imgui.Text(u8('═══  Road66 Market — Синхронизация  ═══'))
    imgui.PopStyleColor()
    imgui.Separator()
    imgui.Spacing()

    -- Баланс
    imgui.Text(u8('Текущий баланс:'))
    imgui.SameLine()
    if balance_known then
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(1.0, 0.85, 0.0, 1.0))
        imgui.Text(fmt_money(current_balance))
        imgui.PopStyleColor()
    else
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.5, 0.5, 0.5, 1.0))
        imgui.Text(u8('— (откройте /stats в игре)'))
        imgui.PopStyleColor()
    end

    -- Статус синхронизации
    imgui.Spacing()
    if sync_ok then
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.2, 0.85, 0.4, 1.0))
    else
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.7, 0.7, 0.7, 1.0))
    end
    imgui.Text(sync_status_msg ~= '' and sync_status_msg or u8('Ожидание синхронизации...'))
    imgui.PopStyleColor()
    imgui.Text(u8('Сделок отправлено: ') .. tostring(trades_sent))
    imgui.Text(u8('Сделок поймано: ') .. tostring(trades_captured))
    imgui.Text(u8('В очереди: ') .. tostring(#pending_trades))
    imgui.Text(u8('Сообщений чата поймано: ') .. tostring(chat_seen))
    if last_trade_error ~= '' then
        imgui.TextWrapped(u8('Ошибка парсинга: ') .. last_trade_error)
    end

    imgui.Spacing()
    imgui.Separator()
    imgui.Spacing()

    -- API ключ
    imgui.Text(u8('API ключ (из личного кабинета):'))
    imgui.PushItemWidth(-1)
    if imgui.InputText('##apikey', inp_api_key, ffi.sizeof(inp_api_key) - 1) then end
    imgui.PopItemWidth()
    imgui.Spacing()

    -- URL сервера
    imgui.Text(u8('URL сервера Road66:'))
    imgui.PushItemWidth(-1)
    if imgui.InputText('##srvurl', inp_srv_url, ffi.sizeof(inp_srv_url) - 1) then end
    imgui.PopItemWidth()
    imgui.Spacing()

    -- Отладка сообщений
    imgui.Separator()
    imgui.Spacing()
    if imgui.Checkbox(u8('Показывать сообщения сервера в чат (отладка сделок)'), chk_debug) then
        cfg.debug_chat = chk_debug[0]
        save_cfg()
    end
    imgui.Spacing()

    -- Кнопки
    if imgui.Button(u8('  Сохранить и проверить подключение  '), imgui.ImVec2(-1, 30)) then
        cfg.api_key    = ffi.string(inp_api_key)
        cfg.server_url = ffi.string(inp_srv_url)
        if cfg.server_url == '' then cfg.server_url = 'http://localhost:5000' end
        cfg.server_url = cfg.server_url:gsub('/+$', '')
        save_cfg()
        sync_status_msg = u8:decode('⏳ Проверка подключения...')
        sync_ok = false
        lua_thread.create(function()
            test_connection()
        end)
    end

    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.5, 0.5, 0.5, 1.0))
    imgui.TextWrapped(u8('Получите API ключ в разделе "Настройки" личного кабинета Route66 Market. Синхронизация баланса происходит каждые 30 сек.'))
    imgui.PopStyleColor()

    imgui.End()
end

imgui.OnFrame(
    function() return wnd_open[0] end,
    function() imgui_window() end
)

-- ── Команда /r66 ─────────────────────────────────────────────
local function cmd_r66()
    ffi.copy(inp_api_key, cfg.api_key)
    ffi.copy(inp_srv_url, cfg.server_url ~= '' and cfg.server_url or 'http://localhost:5000')
    chk_debug[0] = cfg.debug_chat
    wnd_open[0] = not wnd_open[0]
end

-- ── Команда /balance (показ в чате) ──────────────────────────
local function cmd_balance()
    if balance_known then
        chat(u8('💰 Баланс: ') .. fmt_money(current_balance))
        if sync_ok then
            chat(u8('✓ Синхронизация активна'))
        else
            chat(u8('✗ Синхронизация не настроена — введи /r66'))
        end
    else
        chat(u8('⏳ Баланс неизвестен. Откройте /stats в игре.'))
    end
end

local function cmd_r66trades()
    chat(u8('R66: чат пойман: ') .. tostring(chat_seen) .. u8(', сделок поймано: ') .. tostring(trades_captured) .. u8(', в очереди: ') .. tostring(#pending_trades) .. u8(', отправлено: ') .. tostring(trades_sent))
    if last_chat_message ~= '' then
        chat(u8('R66 последнее сообщение: ') .. tostring(last_chat_message):sub(1, 120))
    end
    if last_trade_error ~= '' then
        chat(u8('R66 ошибка: ') .. last_trade_error)
    end
end

-- ── Основной цикл ────────────────────────────────────────────
function main()
    repeat wait(250) until isSampAvailable()

    load_cfg()
    init_trade_log()

    -- Регистрируем команды
    sampRegisterChatCommand('r66',     cmd_r66)
    sampRegisterChatCommand('balance', cmd_balance)
    sampRegisterChatCommand('bal',     cmd_balance)
    sampRegisterChatCommand('r66trades', cmd_r66trades)

    chat(u8('🚀 Road66 Sync загружен! Команды: /r66 — настройки, /balance — баланс, /r66trades — сделки'))
    if cfg.api_key == '' then
        chat(u8('⚙ Введите /r66 и укажите API ключ из личного кабинета.'))
    else
        chat(u8('✓ API ключ загружен. Синхронизация активна.'))
    end

    while true do
        wait(1000)

        -- Синхронизация баланса каждые SYNC_INTERVAL секунд
        local now = os.time()
        if now - last_sync_time >= SYNC_INTERVAL and cfg.api_key ~= '' then
            last_sync_time = now
            lua_thread.create(function()
                sync_balance()
                sync_pending_trades()
            end)
        end

        -- Отправляем накопившиеся сделки сразу если ключ есть
        if #pending_trades > 0 and cfg.api_key ~= '' then
            lua_thread.create(function()
                sync_pending_trades()
            end)
        end
    end
end
