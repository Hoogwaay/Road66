script_name('Road66 Sync v1.0')
script_author('Road66 Market')
script_version('1.0')

-- ============================================================
-- Road66 Sync — объединённый скрипт
-- Баланс + Журнал сделок + CEF интерфейс (/r66)
-- ============================================================

require 'lib.moonloader'
local sampev   = require 'samp.events'
local json     = require 'dkjson'
local imgui    = require 'mimgui'
local encoding = require 'encoding'
local requests = require 'requests'
local ffi      = require 'ffi'

encoding.default = 'CP1251'
u8 = encoding.UTF8

-- ── Конфигурация ─────────────────────────────────────────────
local CFG_FILE    = getWorkingDirectory() .. '/road66_config.json'
local BAL_FILE    = getWorkingDirectory() .. '/road66_balance.json'
local TRADE_FILE  = getWorkingDirectory() .. '/road66_trades.json'
local SYNC_INTERVAL = 30  -- секунд между отправками баланса

-- ── Состояние ────────────────────────────────────────────────
local cfg = {
    api_key    = '',
    server_url = 'http://localhost:5000',
    debug_chat = false,
}
local current_balance     = 0
local balance_known       = false
local last_sync_time      = 0
local sync_ok             = false
local sync_status_msg     = ''
local pending_trades      = {}
local trades_sent         = 0

-- ── imgui окно ───────────────────────────────────────────────
local wnd_open     = imgui.new.bool(false)
local inp_api_key  = imgui.new.char[128]('')
local inp_srv_url  = imgui.new.char[256]('')
local status_msg   = imgui.new.char[256]('')
local chk_debug    = imgui.new.bool(false)

-- ── Утилиты ──────────────────────────────────────────────────
local function chat(msg)
    if isSampAvailable() then
        sampAddChatMessage('{66CCFF}[Road66]{FFFFFF} ' .. msg, -1)
    end
end

local function fmt_money(n)
    n = math.floor(tonumber(n) or 0)
    local s = tostring(n):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^%s+','')
    return '$' .. s
end

-- ── Конфиг IO ────────────────────────────────────────────────
local function load_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'r')
        if f then
            local ok, t = pcall(json.decode, f:read('*a'))
            f:close()
            if ok and type(t) == 'table' then
                cfg.api_key    = t.api_key    or ''
                cfg.server_url = t.server_url or 'http://localhost:5000'
                cfg.debug_chat = t.debug_chat or false
            end
        end
    end)
end

local function save_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'w')
        if f then
            f:write(json.encode({ api_key = cfg.api_key, server_url = cfg.server_url, debug_chat = cfg.debug_chat }))
            f:close()
        end
    end)
end

-- ── Баланс IO ────────────────────────────────────────────────
local function save_balance()
    pcall(function()
        local f = io.open(BAL_FILE, 'w')
        if f then
            f:write(json.encode({ balance = current_balance, ts = os.time() }))
            f:close()
        end
    end)
end

-- ── Сделки IO ────────────────────────────────────────────────
local function append_trade(trade)
    table.insert(pending_trades, trade)
    pcall(function()
        local existing = {}
        local f = io.open(TRADE_FILE, 'r')
        if f then
            local ok, t = pcall(json.decode, f:read('*a'))
            f:close()
            if ok and type(t) == 'table' then existing = t end
        end
        table.insert(existing, trade)
        if #existing > 1000 then
            table.remove(existing, 1)
        end
        local fw = io.open(TRADE_FILE, 'w')
        if fw then
            fw:write(json.encode(existing))
            fw:close()
        end
    end)
end

-- ── HTTP helper ──────────────────────────────────────────────
local function post_json(url, body_table)
    local ok, res = pcall(function()
        return requests.post(url, {
            headers = {
                ['Content-Type'] = 'application/json',
                ['X-API-Key']    = cfg.api_key,
            },
            data = json.encode(body_table),
            timeout = 8,
        })
    end)
    if ok and res then
        local status = res.status_code or 0
        local ok2, data = pcall(json.decode, res.text or '')
        return ok2 and data or { success = status >= 200 and status < 300 }
    end
    return nil
end

-- ── Проверка подключения (пинг API ключа) ────────────────────
local function test_connection()
    if cfg.api_key == '' then
        sync_ok         = false
        sync_status_msg = u8:decode('✗ Введите API ключ')
        return
    end
    local url  = cfg.server_url .. '/api/sync/ping'
    local data = post_json(url, { api_key = cfg.api_key })
    if data and data.success then
        sync_ok         = true
        sync_status_msg = u8:decode('✓ Подключено! Пользователь: ' .. (data.username or ''))
    elseif data and data.error then
        sync_ok         = false
        sync_status_msg = u8:decode('✗ ' .. tostring(data.error))
    else
        sync_ok         = false
        sync_status_msg = u8:decode('✗ Нет ответа от сервера. Проверь URL.')
    end
end

-- ── Синхронизация баланса ─────────────────────────────────────
local function sync_balance()
    if cfg.api_key == '' then return end
    if not balance_known then
        -- Баланс ещё неизвестен — пропускаем, но не меняем статус
        return
    end
    local url  = cfg.server_url .. '/api/sync/balance'
    local data = post_json(url, { api_key = cfg.api_key, balance = current_balance })
    if data and data.success then
        sync_ok         = true
        sync_status_msg = u8:decode('✓ Баланс отправлен: ' .. fmt_money(current_balance))
    else
        sync_ok         = false
        sync_status_msg = u8:decode('✗ Ошибка отправки баланса')
    end
end

-- ── Синхронизация сделок ──────────────────────────────────────
local function sync_pending_trades()
    if cfg.api_key == '' then return end
    if #pending_trades == 0 then return end
    local url    = cfg.server_url .. '/api/sync/trades'
    local to_send = {}
    for _, t in ipairs(pending_trades) do table.insert(to_send, t) end
    pending_trades = {}
    local data = post_json(url, { api_key = cfg.api_key, trades = to_send })
    if data and data.success then
        trades_sent = trades_sent + (data.inserted or #to_send)
    else
        for _, t in ipairs(to_send) do table.insert(pending_trades, t) end
    end
end

-- ── Парсинг баланса ──────────────────────────────────────────

local function parse_part_value(value, scale)
    value = tostring(value or '')
    local whole, frac = value:match('^(%d+)%.(%d+)$')
    if whole then
        local base = tonumber(whole) or 0
        local decimals = tonumber(frac) or 0
        local factor = 10 ^ #frac
        return base * scale + math.floor(decimals * scale / factor)
    end
    return (tonumber(value) or 0) * scale
end

local function is_balance_text(text)
    if type(text) ~= 'string' then return false end
    local low = text:lower()
    return low:find('наличн') and (low:find('sa%$') or low:find('stats') or low:find('статистик'))
end

local function extract_balance(text)
    if not is_balance_text(text) then return nil end
    local total, found = 0, false
    for p in text:gmatch(':M:%s*([%d%.]+)')  do total = total + parse_part_value(p, 1000000000); found = true end
    for p in text:gmatch(':KK:%s*([%d%.]+)') do total = total + parse_part_value(p, 1000000);    found = true end
    for p in text:gmatch(':K:%s*([%d%.]+)')  do total = total + parse_part_value(p, 1000);       found = true end
    return found and total or nil
end

local function set_balance(num)
    num = tonumber(num) or 0
    if num < 0 then num = 0 end
    current_balance = math.floor(num)
    balance_known   = true
    save_balance()
end

-- ── Парсинг чата (сделки) ────────────────────────────────────
-- Вспомогательная: убирает пробелы из числа "1 000" -> 1000
local function parse_num(s)
    if not s then return 0 end
    return tonumber(s:gsub('[%s ]', '')) or 0
end

local function try_parse_trade_from_chat(msg)
    if type(msg) ~= 'string' or msg == '' then return end

    local item, qty, price, total

    -- ── Покупка ───────────────────────────────────────────────
    -- "Вы купили Арбуз x10 по $5 000 (итого: $50 000)"
    item, qty, price = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber(qty) * parse_num(price) end
        append_trade({ action='buy', item=item:match('^%s*(.-)%s*$'),
            quantity=tonumber(qty), price=parse_num(price), total=total,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Покупка ') .. item .. ' x' .. qty) end
        return
    end
    -- "Вы купили Арбуз x10 за $50 000"
    item, qty, total = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_trade({ action='buy', item=item:match('^%s*(.-)%s*$'),
            quantity=q, price=(q>0 and math.floor(t/q) or 0), total=t,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Покупка ') .. item .. ' x' .. qty) end
        return
    end
    -- "Вы приобрели Арбуз (10 шт.) за $50 000"
    item, qty, total = msg:match('[Вв]ы приобрели%s+(.-)%s+%((%d+)%s*[шШ][тТ]%.?%)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_trade({ action='buy', item=item:match('^%s*(.-)%s*$'),
            quantity=q, price=(q>0 and math.floor(t/q) or 0), total=t,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Покупка ') .. item .. ' x' .. qty) end
        return
    end

    -- ── Продажа ───────────────────────────────────────────────
    -- "Вы продали Арбуз x10 по $6 000 (итого: $60 000)"
    item, qty, price = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber(qty) * parse_num(price) end
        append_trade({ action='sell', item=item:match('^%s*(.-)%s*$'),
            quantity=tonumber(qty), price=parse_num(price), total=total,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Продажа ') .. item .. ' x' .. qty) end
        return
    end
    -- "Вы продали Арбуз x10 за $60 000"
    item, qty, total = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_trade({ action='sell', item=item:match('^%s*(.-)%s*$'),
            quantity=q, price=(q>0 and math.floor(t/q) or 0), total=t,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Продажа ') .. item .. ' x' .. qty) end
        return
    end

    -- ── Продажа игроку / покупка у тебя ──────────────────────
    -- "Игрок купил у вас Арбуз x10 за $60 000"
    item, qty, total = msg:match('[Ии]грок купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_trade({ action='player_buy', item=item:match('^%s*(.-)%s*$'),
            quantity=q, price=(q>0 and math.floor(t/q) or 0), total=t,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Продал игроку ') .. item .. ' x' .. qty) end
        return
    end
    -- "купил у вас Арбуз x10 за $60 000"  (без "Игрок")
    item, qty, total = msg:match('купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber(qty); local t = parse_num(total)
        append_trade({ action='player_buy', item=item:match('^%s*(.-)%s*$'),
            quantity=q, price=(q>0 and math.floor(t/q) or 0), total=t,
            ts=os.date('%Y-%m-%d %H:%M:%S') })
        if cfg.debug_chat then chat(u8('Сделка: Продал игроку ') .. item .. ' x' .. qty) end
    end
end

-- ── CEF пакет 220 (updateMoney) ──────────────────────────────
local function safe_raknet_read(bs, fn)
    local ok, v = pcall(fn, bs)
    return ok and v or nil
end

local add_handler = addEventHandler or registerHandler
if add_handler then
    add_handler('onReceivePacket', function(id, bs)
        if id ~= 220 then return end
        pcall(function()
            raknetBitStreamIgnoreBits(bs, 8)

            local packet_id = safe_raknet_read(bs, function() return raknetBitStreamReadInt8(bs) end)
            if packet_id ~= 17 then return end

            safe_raknet_read(bs, function() return raknetBitStreamReadInt32(bs) end)

            local text = safe_raknet_read(bs, function()
                local len = safe_raknet_read(bs, function() return raknetBitStreamReadInt16(bs) end)
                local enc = safe_raknet_read(bs, function() return raknetBitStreamReadInt8(bs) end)
                if len and len > 0 then
                    if enc == 0 then return raknetBitStreamReadString(bs, len)
                    else return raknetBitStreamDecodeString(bs, len + 1) end
                end
                return ''
            end)

            if text and text:find('event.player.updateMoney') then
                local jp = text:match('`(.*)`')
                if jp then
                    local ok2, decoded = pcall(json.decode, jp)
                    if ok2 and type(decoded) == 'table' then
                        local money = tonumber(decoded[1])
                        if money and money >= 0 then set_balance(money) end
                    end
                end
            end
        end)
    end)
end

-- ── SAMP события ─────────────────────────────────────────────
function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
    pcall(function()
        for _, s in ipairs({ title, text }) do
            if is_balance_text(s or '') then
                local cash = extract_balance(s)
                if cash then set_balance(cash) end
            end
        end
    end)
end

function sampev.onServerMessage(color, msg)
    pcall(function()
        local decoded = u8:decode(msg or '')
        if cfg.debug_chat and decoded ~= '' then
            sampAddChatMessage('{888888}[R66 msg] ' .. decoded, -1)
        end
        try_parse_trade_from_chat(decoded)
    end)
end

function sampev.onResetPlayerMoney() return false end
function sampev.onGivePlayerMoney(money) return false end

-- ── imgui рендер ─────────────────────────────────────────────
local new = imgui.new

local function imgui_window()
    imgui.SetNextWindowSize(imgui.ImVec2(480, 340), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(200, 200), imgui.Cond.FirstUseEver)

    imgui.Begin(u8('Road66 Sync  v1.0'), wnd_open, imgui.WindowFlags.NoCollapse)

    imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.4, 0.75, 1.0, 1.0))
    imgui.Text(u8('═══  Road66 Market — Синхронизация  ═══'))
    imgui.PopStyleColor()
    imgui.Separator()
    imgui.Spacing()

    -- Баланс
    imgui.Text(u8('Текущий баланс:'))
    imgui.SameLine()
    if balance_known then
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(1.0, 0.85, 0.0, 1.0))
        imgui.Text(fmt_money(current_balance))
        imgui.PopStyleColor()
    else
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.5, 0.5, 0.5, 1.0))
        imgui.Text(u8('— (откройте /stats в игре)'))
        imgui.PopStyleColor()
    end

    -- Статус синхронизации
    imgui.Spacing()
    if sync_ok then
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.2, 0.85, 0.4, 1.0))
    else
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.7, 0.7, 0.7, 1.0))
    end
    imgui.Text(sync_status_msg ~= '' and sync_status_msg or u8('Ожидание синхронизации...'))
    imgui.PopStyleColor()
    imgui.Text(u8('Сделок отправлено: ') .. tostring(trades_sent))

    imgui.Spacing()
    imgui.Separator()
    imgui.Spacing()

    -- API ключ
    imgui.Text(u8('API ключ (из личного кабинета):'))
    imgui.PushItemWidth(-1)
    if imgui.InputText('##apikey', inp_api_key, ffi.sizeof(inp_api_key) - 1) then end
    imgui.PopItemWidth()
    imgui.Spacing()

    -- URL сервера
    imgui.Text(u8('URL сервера Road66:'))
    imgui.PushItemWidth(-1)
    if imgui.InputText('##srvurl', inp_srv_url, ffi.sizeof(inp_srv_url) - 1) then end
    imgui.PopItemWidth()
    imgui.Spacing()

    -- Отладка сообщений
    imgui.Separator()
    imgui.Spacing()
    if imgui.Checkbox(u8('Показывать сообщения сервера в чат (отладка сделок)'), chk_debug) then
        cfg.debug_chat = chk_debug[0]
        save_cfg()
    end
    imgui.Spacing()

    -- Кнопки
    if imgui.Button(u8('  Сохранить и проверить подключение  '), imgui.ImVec2(-1, 30)) then
        cfg.api_key    = ffi.string(inp_api_key)
        cfg.server_url = ffi.string(inp_srv_url)
        if cfg.server_url == '' then cfg.server_url = 'http://localhost:5000' end
        cfg.server_url = cfg.server_url:gsub('/+$', '')
        save_cfg()
        sync_status_msg = u8:decode('⏳ Проверка подключения...')
        sync_ok = false
        lua_thread.create(function()
            test_connection()
        end)
    end

    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.5, 0.5, 0.5, 1.0))
    imgui.TextWrapped(u8('Получите API ключ в разделе "Настройки" личного кабинета Route66 Market. Синхронизация баланса происходит каждые 30 сек.'))
    imgui.PopStyleColor()

    imgui.End()
end

imgui.OnFrame(
    function() return wnd_open[0] end,
    function() imgui_window() end
)

-- ── Команда /r66 ─────────────────────────────────────────────
local function cmd_r66()
    ffi.copy(inp_api_key, cfg.api_key)
    ffi.copy(inp_srv_url, cfg.server_url ~= '' and cfg.server_url or 'http://localhost:5000')
    chk_debug[0] = cfg.debug_chat
    wnd_open[0] = not wnd_open[0]
end

-- ── Команда /balance (показ в чате) ──────────────────────────
local function cmd_balance()
    if balance_known then
        chat(u8('💰 Баланс: ') .. fmt_money(current_balance))
        if sync_ok then
            chat(u8('✓ Синхронизация активна'))
        else
            chat(u8('✗ Синхронизация не настроена — введи /r66'))
        end
    else
        chat(u8('⏳ Баланс неизвестен. Откройте /stats в игре.'))
    end
end

-- ── Основной цикл ────────────────────────────────────────────
function main()
    repeat wait(250) until isSampAvailable()

    load_cfg()

    -- Регистрируем команды
    sampRegisterChatCommand('r66',     cmd_r66)
    sampRegisterChatCommand('balance', cmd_balance)
    sampRegisterChatCommand('bal',     cmd_balance)

    chat(u8('🚀 Road66 Sync загружен! Команды: /r66 — настройки, /balance — баланс'))
    if cfg.api_key == '' then
        chat(u8('⚙ Введите /r66 и укажите API ключ из личного кабинета.'))
    else
        chat(u8('✓ API ключ загружен. Синхронизация активна.'))
    end

    while true do
        wait(1000)

        -- Синхронизация баланса каждые SYNC_INTERVAL секунд
        local now = os.time()
        if now - last_sync_time >= SYNC_INTERVAL and cfg.api_key ~= '' then
            last_sync_time = now
            lua_thread.create(function()
                sync_balance()
                sync_pending_trades()
            end)
        end

        -- Отправляем накопившиеся сделки сразу если ключ есть
        if #pending_trades > 0 and cfg.api_key ~= '' then
            lua_thread.create(function()
                sync_pending_trades()
            end)
        end
    end
end
