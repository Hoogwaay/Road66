// Route66 Market — v3.0

let scannerLoading   = false;
let arbitrageLoading = false;

// Arbitrage filters
let arbFilters        = { minProfit: 0, minLavkas: 0, excludedItems: [] };
let lastArbitrageData = null;

// Currency rates loaded from server
let currencyRates      = [];
let selectedBuyServer  = 0;
let selectedSellServer = 0;

// User's personal server (for header rate display)
let userServer = 0;

// Per-user commission (%)
let userCommission = 9;

// ─── Loader ──────────────────────────────────────────────────
function initLoader() {
    const loader = document.getElementById('loader');
    if (!loader) return;
    const minTime = 1900;
    const start   = Date.now();
    function hide() {
        const elapsed = Date.now() - start;
        const delay   = Math.max(0, minTime - elapsed);
        setTimeout(() => {
            loader.classList.add('hidden');
            document.body.classList.add('app-loaded');
        }, delay);
    }
    if (document.readyState === 'complete') {
        hide();
    } else {
        window.addEventListener('load', hide);
    }
}

// ─── User server preference ───────────────────────────────────
function loadUserServer() {
    // Server is loaded from API in loadUserInfo, just init to 2 as default
    userServer = 2;
}

async function saveUserServer() {
    const sel = document.getElementById('user-server-select');
    const statusEl = document.getElementById('server-save-status');
    if (!sel) return;
    const serverId = parseInt(sel.value);
    if (isNaN(serverId)) return;
    try {
        const res = await fetch('/api/save_server', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ server_id: serverId })
        });
        const data = await res.json();
        if (data.success) {
            userServer = serverId;
            updateHeaderRate();
            updateUserServerHint();
            if (statusEl) {
                const info = getServerInfo(serverId);
                statusEl.textContent = `Сервер сохранён: ${info?.name || serverId}`;
                statusEl.className = 'activation-status success';
                setTimeout(() => { statusEl.textContent = ''; statusEl.className = 'activation-status'; }, 4000);
            }
        } else {
            if (statusEl) {
                statusEl.textContent = data.error || 'Ошибка сохранения';
                statusEl.className = 'activation-status error';
            }
        }
    } catch(e) {
        if (statusEl) { statusEl.textContent = 'Ошибка соединения'; statusEl.className = 'activation-status error'; }
    }
}

function updateUserServerHint() {
    const hint = document.getElementById('user-server-hint');
    if (!hint) return;
    const info = getServerInfo(userServer);
    if (!info) { hint.textContent = 'Можно менять раз в 6 часов'; return; }
    hint.textContent = `${info.name} · 1 VC$ = ${info.id === 0 ? '1 VC$' : info.sell_rate + ' SA$'}`;
}

function buildUserServerSelect() {
    const sel = document.getElementById('user-server-select');
    if (!sel) return;
    sel.innerHTML = '';
    currencyRates.filter(s => s.id !== 0).forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = `${s.id}. ${s.name}`;
        if (s.id === userServer) opt.selected = true;
        sel.appendChild(opt);
    });
    updateUserServerHint();
}

// ─── Currency rates init ─────────────────────────────────────
async function loadCurrencyRates() {
    try {
        const res  = await fetch('/api/currency_rates');
        const data = await res.json();
        if (data.success) {
            currencyRates = data.rates;
            buildServerSelects();
            buildUserServerSelect();
            updateHeaderRate();
        }
    } catch(e) {}
}

function buildServerSelects() {
    const buyEl  = document.getElementById('buy-server-select');
    const sellEl = document.getElementById('sell-server-select');
    if (!buyEl || !sellEl) return;
    buyEl.innerHTML  = '';
    sellEl.innerHTML = '';
    currencyRates.forEach(s => {
        const label = s.id === 0 ? `0. ${s.name}` : `${s.id}. ${s.name}`;

        const optBuy = document.createElement('option');
        optBuy.value = s.id;
        optBuy.textContent = label;
        if (s.id === selectedBuyServer) optBuy.selected = true;
        buyEl.appendChild(optBuy);

        const optSell = document.createElement('option');
        optSell.value = s.id;
        optSell.textContent = label;
        if (s.id === selectedSellServer) optSell.selected = true;
        sellEl.appendChild(optSell);
    });
}

function getServerInfo(serverId) {
    return currencyRates.find(s => s.id === serverId) || null;
}

function updateHeaderRate() {
    const info    = getServerInfo(userServer);
    const rateEl  = document.getElementById('header-rate-value');
    const nameEl  = document.getElementById('user-server-name');
    if (!rateEl) return;
    if (info) {
        if (nameEl) nameEl.textContent = info.id === 0 ? 'Vice City' : info.name;
        rateEl.textContent = info.id === 0
            ? `1 VC$ = 1 VC$`
            : `1 VC$ = ${info.sell_rate} SA$`;
    } else {
        if (nameEl) nameEl.textContent = 'Сервер';
        rateEl.textContent = '1 VC$ = — SA$';
    }
}

function onServerChange() {
    const buyEl  = document.getElementById('buy-server-select');
    const sellEl = document.getElementById('sell-server-select');
    const buyParsed  = parseInt(buyEl.value);
    const sellParsed = parseInt(sellEl.value);
    selectedBuyServer  = isNaN(buyParsed)  ? 0 : buyParsed;
    selectedSellServer = isNaN(sellParsed) ? 0 : sellParsed;
    updateArbSubtitle();
    loadArbitrage();
}

function updateArbSubtitle() {
    const buyInfo  = getServerInfo(selectedBuyServer);
    const sellInfo = getServerInfo(selectedSellServer);
    if (!buyInfo || !sellInfo) return;
    document.getElementById('page-subtitle').textContent =
        `${buyInfo.name} → ${sellInfo.name}`;
}

// ─── Commission ──────────────────────────────────────────────
function loadCommission() {
    try {
        const saved = localStorage.getItem('userCommission');
        if (saved !== null) {
            const v = parseFloat(saved);
            if (!isNaN(v) && v >= 0 && v <= 100) userCommission = v;
        }
    } catch(e) {}
    updateHeaderCommission();
    const inp = document.getElementById('commission-input');
    if (inp) inp.value = userCommission;
}

function updateHeaderCommission() {
    const el = document.getElementById('header-commission');
    if (el) el.textContent = userCommission + '%';
}

async function saveCommission() {
    const inp = document.getElementById('commission-input');
    const statusEl = document.getElementById('commission-status');
    const val = parseFloat(inp?.value);
    if (isNaN(val) || val < 0 || val > 100) {
        if (statusEl) { statusEl.textContent = 'Введите корректное значение (0–100)'; statusEl.className = 'activation-status error'; }
        return;
    }
    userCommission = val;
    try { localStorage.setItem('userCommission', val); } catch(e) {}
    updateHeaderCommission();
    try {
        await fetch('/api/save_settings', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ commission: val }),
        });
    } catch(e) {}
    if (statusEl) {
        statusEl.textContent = `Комиссия ${val}% сохранена`;
        statusEl.className = 'activation-status success';
        setTimeout(() => { statusEl.textContent = ''; statusEl.className = 'activation-status'; }, 3000);
    }
}

// ─── User info ───────────────────────────────────────────────
let userPlan   = 'free';
let userIsAdmin = false;

const PLAN_NAMES = { free: 'Бесплатный', basic: 'Базовый', pro: 'Профи' };

async function loadUserInfo() {
    try {
        const res  = await fetch('/api/me');
        const data = await res.json();
        if (data.success) {
            userPlan    = data.plan || 'free';
            userIsAdmin = data.is_admin || false;
            window._currentUser = data.username || '';
            window._isAdmin     = userIsAdmin;

            const nameEl = document.getElementById('header-username');
            const daysEl = document.getElementById('header-days');
            if (nameEl) nameEl.textContent = data.username;
            if (daysEl) {
                if (userIsAdmin) {
                    daysEl.textContent = '∞ · Admin';
                } else {
                    const planLabel = PLAN_NAMES[userPlan] || userPlan;
                    const daysLeft  = data.days_left !== null ? ` · ${data.days_left}д` : '';
                    daysEl.textContent = planLabel + daysLeft;
                }
            }

            if (data.commission !== undefined) {
                userCommission = parseFloat(data.commission) || 9;
                try { localStorage.setItem('userCommission', userCommission); } catch(e) {}
                updateHeaderCommission();
                const inp = document.getElementById('commission-input');
                if (inp) inp.value = userCommission;
            }

            if (data.user_server) {
                userServer = data.user_server;
            }

            // Show/hide admin section
            const adminSec = document.getElementById('admin-section');
            if (adminSec) adminSec.style.display = userIsAdmin ? 'block' : 'none';
            // Show/hide admin "Users" sidebar nav item
            const adminUsersNav = document.getElementById('nav-admin-users');
            if (adminUsersNav) adminUsersNav.style.display = userIsAdmin ? 'flex' : 'none';

            // Update plan badge in header pill
            const serverPill = document.getElementById('user-server-pill');
            if (serverPill) {
                const info = getServerInfo(userServer);
                if (info) serverPill.textContent = info.name;
            }

            updateHeaderRate();
        }
    } catch(e) {}
}

// ─── Logout ──────────────────────────────────────────────────
function handleLogout() {
    document.getElementById('logoutModal').classList.add('open');
}

function closeLogoutModal() {
    document.getElementById('logoutModal').classList.remove('open');
}

function confirmLogout() {
    const modal = document.getElementById('logoutModal');
    const loader = document.getElementById('loader');
    const dash = loader?.querySelector('.loader-dash');
    const inner = loader?.querySelector('.loader-inner');
    const loaderSub = loader?.querySelector('.loader-sub');
    if (modal) modal.classList.remove('open');
    if (loaderSub) loaderSub.textContent = 'ВЫХОД';
    if (loader) {
        loader.classList.remove('hidden');
        loader.style.display = 'flex';
        loader.style.opacity = '1';
        loader.style.visibility = 'visible';
        loader.style.pointerEvents = 'auto';
    }
    if (inner) {
        inner.style.animation = 'none';
        inner.offsetHeight;
        inner.style.animation = '';
    }
    if (dash) {
        dash.style.animation = 'none';
        dash.offsetHeight;
        dash.style.animation = '';
    }
    setTimeout(() => {
        window.location.href = '/logout';
    }, 350);
}

// ─── Arbitrage Filters ───────────────────────────────────────
function loadArbFilters() {
    try {
        const saved = localStorage.getItem('arbFilters');
        if (saved) arbFilters = JSON.parse(saved);
    } catch(e) {}
    const profitInp = document.getElementById('filter-min-profit');
    if (profitInp) profitInp.value = arbFilters.minProfit > 0 ? arbFilters.minProfit : '';
    const lavkasInp = document.getElementById('filter-min-lavkas');
    if (lavkasInp) lavkasInp.value = arbFilters.minLavkas > 0 ? arbFilters.minLavkas : '';
    renderExcludedTags();
    updateFilterBadge();
}

function saveArbFilters() {
    localStorage.setItem('arbFilters', JSON.stringify(arbFilters));
    updateFilterBadge();
}

function onFilterChange() {
    arbFilters.minProfit = parseInt(document.getElementById('filter-min-profit').value) || 0;
    arbFilters.minLavkas = parseInt(document.getElementById('filter-min-lavkas').value) || 0;
    saveArbFilters();
    if (lastArbitrageData) {
        const filtered = applyArbFilters(lastArbitrageData);
        const buyInfo  = getServerInfo(selectedBuyServer);
        const sellInfo = getServerInfo(selectedSellServer);
        updateArbitrageContent(lastArbitrageData, '✅', null,
            selectedBuyServer, selectedSellServer,
            buyInfo?.name, sellInfo?.name, sellInfo?.sell_rate);
    }
}

function toggleFilterPanel() {
    const panel = document.getElementById('arb-filter-panel');
    const btn   = document.getElementById('arb-filter-btn');
    panel.classList.toggle('open');
    btn.classList.toggle('active', panel.classList.contains('open'));
}

function addExcludedItem() {
    const input = document.getElementById('filter-exclude-input');
    const val   = input.value.trim();
    if (!val) return;
    if (!arbFilters.excludedItems.some(i => i.toLowerCase() === val.toLowerCase())) {
        arbFilters.excludedItems.push(val);
        saveArbFilters();
        renderExcludedTags();
        if (lastArbitrageData) {
            const buyInfo  = getServerInfo(selectedBuyServer);
            const sellInfo = getServerInfo(selectedSellServer);
            updateArbitrageContent(lastArbitrageData, '✅', null,
                selectedBuyServer, selectedSellServer,
                buyInfo?.name, sellInfo?.name, sellInfo?.sell_rate);
        }
    }
    input.value = '';
    input.focus();
}

function removeExcludedItem(index) {
    arbFilters.excludedItems.splice(index, 1);
    saveArbFilters();
    renderExcludedTags();
    if (lastArbitrageData) {
        const buyInfo  = getServerInfo(selectedBuyServer);
        const sellInfo = getServerInfo(selectedSellServer);
        updateArbitrageContent(lastArbitrageData, '✅', null,
            selectedBuyServer, selectedSellServer,
            buyInfo?.name, sellInfo?.name, sellInfo?.sell_rate);
    }
}

function renderExcludedTags() {
    const container = document.getElementById('excluded-tags');
    if (!container) return;
    if (!arbFilters.excludedItems.length) { container.innerHTML = ''; return; }
    container.innerHTML = arbFilters.excludedItems.map((item, i) =>
        `<span class="exclude-tag">${item}<button class="tag-remove" onclick="removeExcludedItem(${i})">×</button></span>`
    ).join('');
}

function updateFilterBadge() {
    const badge = document.getElementById('filter-badge');
    if (!badge) return;
    const count = (arbFilters.minProfit > 0 ? 1 : 0) + (arbFilters.minLavkas > 0 ? 1 : 0) + arbFilters.excludedItems.length;
    if (count > 0) { badge.textContent = count; badge.style.display = 'inline-flex'; }
    else badge.style.display = 'none';
}

function applyArbFilters(deals) {
    let filtered = deals;
    if (arbFilters.minProfit > 0) filtered = filtered.filter(d => d.total_profit >= arbFilters.minProfit);
    if (arbFilters.minLavkas > 0) filtered = filtered.filter(d => (d.sell_lavka_count || 0) >= arbFilters.minLavkas);
    if (arbFilters.excludedItems.length > 0) {
        filtered = filtered.filter(d =>
            !arbFilters.excludedItems.some(ex => d.item.toLowerCase().includes(ex.toLowerCase()))
        );
    }
    return filtered;
}

// ─── Background canvas ───────────────────────────────────────
function initCanvas() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
    resize();
    window.addEventListener('resize', resize);
    const dots   = [];
    const COUNT  = 50;
    const colors = ['53,0,211', '56,189,248', '34,197,94'];
    for (let i = 0; i < COUNT; i++) {
        dots.push({
            x: Math.random() * canvas.width, y: Math.random() * canvas.height,
            r: Math.random() * 1.2 + 0.3,
            vx: (Math.random() - 0.5) * 0.10, vy: (Math.random() - 0.5) * 0.10,
            o: Math.random() * 0.3 + 0.08,
            c: colors[Math.floor(Math.random() * colors.length)]
        });
    }
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        dots.forEach(d => {
            d.x += d.vx; d.y += d.vy;
            if (d.x < 0 || d.x > canvas.width) d.vx *= -1;
            if (d.y < 0 || d.y > canvas.height) d.vy *= -1;
            ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${d.c},${d.o})`; ctx.fill();
        });
        for (let i = 0; i < dots.length; i++) {
            for (let j = i + 1; j < dots.length; j++) {
                const dx = dots[i].x - dots[j].x, dy = dots[i].y - dots[j].y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 100) {
                    ctx.beginPath();
                    ctx.moveTo(dots[i].x, dots[i].y);
                    ctx.lineTo(dots[j].x, dots[j].y);
                    ctx.strokeStyle = `rgba(91,95,239,${0.08 * (1 - dist/100)})`;
                    ctx.lineWidth = 0.4; ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
}

// ─── Best Deals ──────────────────────────────────────────────
let lastBdData = null;

async function loadBestDeals() {
    try {
        const res  = await fetch('/api/best_deals');
        const data = await res.json();
        lastBdData = data;
        renderBestDeals(data);
    } catch(e) {}
}

async function toggleAutoBd() {
    const res    = await fetch('/toggle_auto_bestdeals', {method: 'POST'});
    const result = await res.json();
    if (result.success === false) {
        showToast(result.error || 'Недоступно в вашем тарифе');
        return;
    }
    const btn = document.getElementById('bd-auto-btn');
    const dot = document.getElementById('dot-bd');
    if (result.bd_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
        if (dot) dot.classList.add('on');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан';
        if (dot) dot.classList.remove('on');
    }
}

async function scanBestDeals() {
    const btn = document.getElementById('bd-scan-btn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Сканирую...';
    const bdStatus = document.getElementById('bd-status');
    if (bdStatus) bdStatus.querySelector('span:last-child').textContent = 'Сканирую все серверы...';
    document.getElementById('bd-content').innerHTML =
        '<div class="empty-state"><div class="spinner"></div><p>Сканирую все 33 сервера...</p></div>';
    const scanRes = await fetch('/scan_best_deals', {method: 'POST'});
    const scanData = await scanRes.json();
    if (scanData.success === false) {
        document.getElementById('bd-content').innerHTML =
            `<div class="empty-state plan-locked"><div class="plan-lock-icon">🔒</div><p>${scanData.error || 'Недоступно в вашем тарифе'}</p><p style="color:var(--text-muted);font-size:12px;margin-top:6px">Доступно в тарифе Профи</p></div>`;
        if (bdStatus) bdStatus.querySelector('span:last-child').textContent = 'Требуется тариф Профи';
        btn.disabled = false;
        btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 6v4l3 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Скан`;
        return;
    }

    const resetBtn = () => {
        btn.disabled = false;
        btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 6v4l3 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Скан`;
    };

    let attempts = 0;
    const maxAttempts = 20;
    const poll = async () => {
        attempts++;
        try {
            const res  = await fetch('/api/best_deals');
            const data = await res.json();
            lastBdData = data;
            const scanning = data.status && data.status.includes('Сканирую');
            if (!scanning || attempts >= maxAttempts) {
                renderBestDeals(data);
                resetBtn();
            } else {
                setTimeout(poll, 2000);
            }
        } catch(e) {
            if (attempts < maxAttempts) setTimeout(poll, 2000);
            else resetBtn();
        }
    };
    setTimeout(poll, 3000);
}

function applyBdFilters() {
    if (lastBdData) renderBestDeals(lastBdData);
}

function renderBestDeals(data) {
    const content   = document.getElementById('bd-content');
    const statusEl  = document.getElementById('bd-status');
    const minProfit = parseFloat(document.getElementById('bd-min-profit')?.value) || 0;
    const minPct    = parseFloat(document.getElementById('bd-min-pct')?.value)    || 0;

    if (statusEl) {
        const lastSpan = statusEl.querySelector('span:last-child');
        if (lastSpan) lastSpan.textContent = data.status + (data.last_update ? ' · ' + data.last_update : '');
    }

    let deals = data.deals || [];
    if (minProfit > 0) deals = deals.filter(d => d.total_profit_vc >= minProfit);
    if (minPct    > 0) deals = deals.filter(d => d.profit_pct     >= minPct);

    if (!deals.length) {
        content.innerHTML = `<div class="empty-state"><p>${!data.deals?.length ? 'Нажмите «Скан», чтобы начать сканирование' : 'Нет сделок по заданным фильтрам'}</p></div>`;
        return;
    }

    const totalProfitVc = deals.reduce((s, d) => s + d.total_profit_vc, 0);

    const buyGroups = {};
    deals.forEach(d => {
        if (!buyGroups[d.lavka_buy]) buyGroups[d.lavka_buy] = [];
        buyGroups[d.lavka_buy].push(d);
    });

    const sortedLavkas = Object.keys(buyGroups)
        .map(id => ({ id, profit: buyGroups[id].reduce((s, d) => s + d.total_profit_vc, 0) }))
        .sort((a, b) => b.profit - a.profit)
        .map(x => x.id);

    // Clear and rebuild DOM directly to avoid HTML parsing issues
    content.innerHTML = '';

    // Stats summary
    const statsEl = document.createElement('div');
    statsEl.className = 'stats-card';
    statsEl.innerHTML = `
        <div class="stat-item"><span class="stat-label">Сделок</span><span class="stat-value">${deals.length}</span></div>
        <div class="stat-item"><span class="stat-label">Общий профит</span><span class="stat-value green">+${Math.ceil(totalProfitVc).toLocaleString()} VC$</span></div>
    `;
    content.appendChild(statsEl);

    sortedLavkas.forEach(buyLavka => {
        const group       = [...buyGroups[buyLavka]].sort((a, b) => b.total_profit_vc - a.total_profit_vc);
        const groupProfit = group.reduce((s, d) => s + d.total_profit_vc, 0);
        const buySrvName  = currencyRates.find(s => s.id === group[0].buy_server)?.name || `Сервер ${group[0].buy_server}`;

        const card = document.createElement('div');
        card.className = 'arb-card';

        // Head
        const head = document.createElement('div');
        head.className = 'arb-head';
        head.innerHTML = `
            <div class="arb-icon">💹</div>
            <span class="arb-id">Лавка #${buyLavka}
                <span style="color:var(--text-muted);font-weight:400;font-size:12px;margin-left:4px;">${buySrvName}</span>
            </span>
            <span class="arb-count">${group.length} ${group.length === 1 ? 'сделка' : group.length < 5 ? 'сделки' : 'сделок'}</span>
            <span class="arb-total">+${Math.ceil(groupProfit).toLocaleString()} VC$</span>
        `;
        card.appendChild(head);

        // Table wrap
        const wrap = document.createElement('div');
        wrap.className = 'table-wrap';
        wrap.style.cssText = 'overflow-x:auto;-webkit-overflow-scrolling:touch;';

        const table = document.createElement('table');
        table.className = 'arb-table bd-arb-table';

        // thead
        const thead = document.createElement('thead');
        thead.innerHTML = `<tr>
            <th>Скуп Лавка</th><th>Сервер</th><th>Предмет</th>
            <th>Покупка</th><th>Скупка</th>
            <th>Профит/шт</th><th>%</th><th>Итого (VC$)</th><th>Кол-во</th><th></th>
        </tr>`;
        table.appendChild(thead);

        // tbody
        const tbody = document.createElement('tbody');
        group.slice(0, 20).forEach(d => {
            const bc          = d.buy_currency  || 'SA$';
            const sc          = d.sell_currency || 'SA$';
            const sellSrvName = currencyRates.find(s => s.id === d.sell_server)?.name || `Сервер ${d.sell_server}`;
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="td-sell">#${d.lavka_sell}</td>
                <td class="td-num" style="font-size:11px;">${sellSrvName}</td>
                <td class="td-item" title="${d.item}">${d.item.slice(0, 28)}${d.item.length > 28 ? '…' : ''}</td>
                <td class="td-num">${Math.ceil(d.price_buy).toLocaleString()} ${bc}</td>
                <td class="td-num">${Math.ceil(d.price_sell).toLocaleString()} ${sc}</td>
                <td class="td-profit">+${Math.ceil(d.profit_vc).toLocaleString()} VC$</td>
                <td class="td-pct">+${d.profit_pct}%</td>
                <td class="td-profit">+${Math.ceil(d.total_profit_vc).toLocaleString()} VC$</td>
                <td class="td-num">${d.count_buy}</td>
                <td class="td-action"><button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${d.lavka_sell}')">копировать</button></td>
            `;
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        wrap.appendChild(table);

        if (group.length > 20) {
            const more = document.createElement('div');
            more.className = 'more-deals';
            more.textContent = `+${group.length - 20} ещё сделок`;
            wrap.appendChild(more);
        }

        card.appendChild(wrap);
        content.appendChild(card);
    });
}

// ─── Sidebar toggle ───────────────────────────────────────────
function toggleSidebar() {
    const hidden = document.body.classList.toggle('sidebar-hidden');
    localStorage.setItem('sidebarHidden', hidden ? '1' : '0');
}

(function () {
    if (localStorage.getItem('sidebarHidden') === '1') {
        document.body.classList.add('sidebar-hidden');
    }
})();

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.bnav-item').forEach(n => n.classList.remove('active'));

    const tabEl = document.getElementById(tabName);
    if (tabEl) { tabEl.style.display = ''; tabEl.classList.add('active'); }

    const sideNav = document.getElementById('nav-' + tabName);
    if (sideNav) sideNav.classList.add('active');
    const botNav = document.getElementById('bnav-' + tabName);
    if (botNav) botNav.classList.add('active');

    const titles = {
        scanner:       ['Продажа через лавки',            'Инвентарь · Сервер 0'],
        dashboard:     ['Дашборд',                         'Статистика баланса'],
        market:        ['Рынок',                           'Поиск товаров по лавкам'],
        bestdeals:     ['Лучшие сделки',                   'Глобальный арбитраж по всем серверам'],
        settings:      ['Настройки',                       'Профиль и параметры'],
        'map-shops':   ['Карта лавок',                     'Расположение лавок на всех серверах'],
        'map-trash':   ['Карта мусорок',                   'Расположение мусорных точек · Профи'],
        'map-treasure':['Карта кладов',                    'Расположение кладов · Профи'],
        'arizona-map': ['Карта Аризоны',                   'Интерактивная карта домов и бизнесов'],
        'avtomarket':  ['Авторынок',                        'Объявления о продаже и покупке авто'],
        'admin-users': ['Пользователи',                    'Управление пользователями'],
        'admin-codes': ['Коды активации',                  'Управление кодами'],
        'admin-log':   ['Журнал активности',               'Логи системы'],
    };

    if (tabName === 'arbitrage') {
        document.getElementById('page-title').textContent = 'Арбитраж';
        updateArbSubtitle();
        loadArbitrage();
    } else if (tabName === 'favorites') {
        document.getElementById('page-title').textContent    = 'Избранное';
        document.getElementById('page-subtitle').textContent = 'Сохранённые товары';
        renderFavorites();
    } else if (titles[tabName]) {
        document.getElementById('page-title').textContent    = titles[tabName][0];
        document.getElementById('page-subtitle').textContent = titles[tabName][1];
        if (tabName === 'scanner')           loadScanner();
        else if (tabName === 'dashboard')    loadDashboard();
        else if (tabName === 'market')       setTimeout(() => document.getElementById('market-search-input')?.focus(), 50);
        else if (tabName === 'bestdeals')    loadBestDeals();
        else if (tabName === 'arizona-map')  { setTimeout(() => { if (typeof loadArizonaMap === 'function') loadArizonaMap(); }, 50); }
        else if (tabName === 'avtomarket')   loadAvtomarket();
        else if (tabName === 'admin-users')  loadAdminUsers();
        else if (tabName === 'admin-codes')  loadAdminCodes();
        else if (tabName === 'admin-log')    loadAdminLog();
    }
}

// ─── Map tabs ─────────────────────────────────────────────────
function renderMapShops() {
    // placeholder: map-shops-area already has static HTML, just update stats if available
}

// ─── Trash Map ────────────────────────────────────────────────
/* Uses the same tile system and CSS classes as the Arizona map.
   HTML is static in the template (tm-map-wrap / tm-map-container /
   tm-map-inner / tm-tile-layer / tm-marker-layer).
   JS only shows/hides and initialises the existing elements.    */
(function () {
    const TM_TILE_URL   = 'https://pc.rod-ins.com/resource/web/arizona/map_dark/{z}/{x}/{y}.png';
    const TM_WORLD_MIN  = -3000, TM_WORLD_MAX = 3000, TM_WORLD_SIZE = 6000;
    const TM_TILE_SIZE  = 256;
    const TM_MAX_ZOOM   = 5;
    const TM_MAX_GRID   = 24;
    const TM_IMG_SIZE   = TM_TILE_SIZE * TM_MAX_GRID;

    let _tmScale = 1, _tmTx = 0, _tmTy = 0;
    let _tmDragging = false, _tmDragStart = null;
    let _tmTiles = new Map();
    let _tmMarkers = [];
    let _tmData = null;
    let _tmInited = false;

    function tmWorldToPixel(x, y) {
        const px = ((x - TM_WORLD_MIN) / TM_WORLD_SIZE) * TM_IMG_SIZE;
        const py = ((TM_WORLD_MAX - y) / TM_WORLD_SIZE) * TM_IMG_SIZE;
        return { px, py };
    }

    function tmGetContainer() { return document.getElementById('tm-map-container'); }
    function tmGetInner()     { return document.getElementById('tm-map-inner'); }
    function tmGetTileLayer() { return document.getElementById('tm-tile-layer'); }
    function tmGetMarkerLayer() { return document.getElementById('tm-marker-layer'); }

    function tmMinScale() {
        const c = tmGetContainer();
        if (!c) return 0.08;
        const r = c.getBoundingClientRect();
        return Math.max(r.width / TM_IMG_SIZE, r.height / TM_IMG_SIZE);
    }

    function tmClamp() {
        const c = tmGetContainer();
        if (!c) return;
        const r = c.getBoundingClientRect();
        const ms = tmMinScale();
        _tmScale = Math.max(ms, Math.min(8, _tmScale));
        const maxTx = 0, minTx = r.width  - TM_IMG_SIZE * _tmScale;
        const maxTy = 0, minTy = r.height - TM_IMG_SIZE * _tmScale;
        _tmTx = Math.max(minTx, Math.min(maxTx, _tmTx));
        _tmTy = Math.max(minTy, Math.min(maxTy, _tmTy));
    }

    function tmApply() {
        tmClamp();
        const inner = tmGetInner();
        if (inner) inner.style.transform = `translate(${_tmTx}px,${_tmTy}px) scale(${_tmScale})`;
        tmUpdateMarkers();
        tmRenderTiles();
    }

    function tmUpdateMarkers() {
        for (const m of _tmMarkers) {
            m.el.style.left = (_tmTx + m.px * _tmScale) + 'px';
            m.el.style.top  = (_tmTy + m.py * _tmScale) + 'px';
        }
    }

    function tmTileGridSize(z) {
        return Math.ceil(TM_MAX_GRID / Math.pow(2, TM_MAX_ZOOM - z));
    }

    function tmChooseZoom() {
        const z = Math.round(TM_MAX_ZOOM + Math.log2(Math.max(_tmScale, 0.001)));
        return Math.max(0, Math.min(TM_MAX_ZOOM, z));
    }

    function tmRenderTiles() {
        const layer = tmGetTileLayer();
        const c = tmGetContainer();
        if (!layer || !c) return;
        const z = tmChooseZoom();
        const grid = tmTileGridSize(z);
        const tSize = TM_IMG_SIZE / grid;
        const r = c.getBoundingClientRect();

        const x0 = Math.max(0, Math.floor(-_tmTx / (_tmScale * tSize)));
        const y0 = Math.max(0, Math.floor(-_tmTy / (_tmScale * tSize)));
        const x1 = Math.min(grid - 1, Math.floor((r.width  - _tmTx) / (_tmScale * tSize)));
        const y1 = Math.min(grid - 1, Math.floor((r.height - _tmTy) / (_tmScale * tSize)));

        const needed = new Set();
        for (let ty = y0; ty <= y1; ty++) {
            for (let tx = x0; tx <= x1; tx++) {
                const key = `${z}:${tx}:${ty}`;
                needed.add(key);
                if (!_tmTiles.has(key)) {
                    const img = document.createElement('img');
                    img.className = 'az-map-tile';
                    img.style.left   = (tx * tSize) + 'px';
                    img.style.top    = (ty * tSize) + 'px';
                    img.style.width  = tSize + 'px';
                    img.style.height = tSize + 'px';
                    img.src = TM_TILE_URL.replace('{z}', z).replace('{x}', tx).replace('{y}', ty);
                    img.onload = () => img.classList.add('loaded');
                    layer.appendChild(img);
                    _tmTiles.set(key, img);
                }
            }
        }
        for (const [key, img] of [..._tmTiles.entries()]) {
            const tileZ = parseInt(key.split(':')[0], 10);
            if (tileZ !== z) { img.remove(); _tmTiles.delete(key); }
        }
    }

    function tmRenderMarkers(locations) {
        const layer = tmGetMarkerLayer();
        if (!layer) return;
        layer.innerHTML = '';
        _tmMarkers = [];
        const tooltip = document.getElementById('tm-tooltip');

        for (const loc of locations) {
            const lx = parseFloat(loc.x ?? loc.lx);
            const ly = parseFloat(loc.y ?? loc.ly);
            if (isNaN(lx) || isNaN(ly)) continue;
            const { px, py } = tmWorldToPixel(lx, ly);

            const el = document.createElement('div');
            el.className = 'tm-marker';
            el.style.left = (_tmTx + px * _tmScale) + 'px';
            el.style.top  = (_tmTy + py * _tmScale) + 'px';

            el.addEventListener('mouseenter', (e) => {
                if (!tooltip) return;
                tooltip.innerHTML = `<strong>${loc.name || 'Мусорка'}</strong><br><span style="color:var(--text-muted);font-size:11px">X: ${lx.toFixed(1)} Y: ${ly.toFixed(1)}</span>`;
                tooltip.className = 'az-map-tooltip visible';
            });
            el.addEventListener('mouseleave', () => {
                if (tooltip) tooltip.className = 'az-map-tooltip';
            });
            el.addEventListener('mousemove', (e) => {
                if (!tooltip) return;
                tooltip.style.left = (e.clientX + 14) + 'px';
                tooltip.style.top  = (e.clientY - 10) + 'px';
            });

            layer.appendChild(el);
            _tmMarkers.push({ el, px, py });
        }

        const countEl = document.getElementById('tm-count');
        if (countEl) countEl.textContent = locations.length + ' точек';
    }

    function tmInitInteraction() {
        const c = tmGetContainer();
        if (!c) return;
        c.addEventListener('wheel', (e) => {
            e.preventDefault();
            const r = c.getBoundingClientRect();
            const mx = e.clientX - r.left, my = e.clientY - r.top;
            const factor = e.deltaY < 0 ? 1.15 : 0.87;
            const newScale = Math.max(tmMinScale(), Math.min(8, _tmScale * factor));
            _tmTx = mx - (mx - _tmTx) * (newScale / _tmScale);
            _tmTy = my - (my - _tmTy) * (newScale / _tmScale);
            _tmScale = newScale;
            tmApply();
        }, { passive: false });

        c.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            _tmDragging = true;
            _tmDragStart = { x: e.clientX - _tmTx, y: e.clientY - _tmTy };
            c.style.cursor = 'grabbing';
        });
        window.addEventListener('mousemove', (e) => {
            if (!_tmDragging) return;
            _tmTx = e.clientX - _tmDragStart.x;
            _tmTy = e.clientY - _tmDragStart.y;
            tmApply();
        });
        window.addEventListener('mouseup', () => {
            _tmDragging = false;
            const c2 = tmGetContainer();
            if (c2) c2.style.cursor = 'grab';
        });

        c.addEventListener('touchstart', (e) => {
            if (e.touches.length === 1) {
                _tmDragging = true;
                _tmDragStart = { x: e.touches[0].clientX - _tmTx, y: e.touches[0].clientY - _tmTy };
            }
        }, { passive: true });
        c.addEventListener('touchmove', (e) => {
            if (!_tmDragging || e.touches.length !== 1) return;
            _tmTx = e.touches[0].clientX - _tmDragStart.x;
            _tmTy = e.touches[0].clientY - _tmDragStart.y;
            tmApply();
        }, { passive: true });
        c.addEventListener('touchend', () => { _tmDragging = false; });
    }

    function tmCenterMap() {
        const c = tmGetContainer();
        if (!c) return;
        const r = c.getBoundingClientRect();
        const ms = tmMinScale();
        _tmScale = ms;
        _tmTx = (r.width  - TM_IMG_SIZE * _tmScale) / 2;
        _tmTy = (r.height - TM_IMG_SIZE * _tmScale) / 2;
    }

    async function tmLoadData() {
        try {
            const res = await fetch('/api/trash_map?t=' + Date.now());
            const data = await res.json();
            if (data.ok) {
                _tmData = data.locations;
                tmRenderMarkers(_tmData);
            }
        } catch(e) {}
    }

    window.renderTrashMap = async function () {
        const proWrap  = document.getElementById('map-trash-wrap');
        const mapWrap  = document.getElementById('tm-map-wrap');
        if (!mapWrap) return;

        // ── Access gate ──────────────────────────────────────────
        if (userPlan !== 'pro' && !userIsAdmin) {
            if (proWrap) proWrap.innerHTML = `
                <div class="map-pro-gate">
                    <div class="map-pro-gate-icon">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
                            <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            <circle cx="12" cy="16" r="1.5" fill="currentColor"/>
                        </svg>
                    </div>
                    <p class="map-pro-gate-title">Карта мусорок</p>
                    <p class="map-pro-gate-sub">Эта функция доступна только на тарифе <span class="map-pro-badge">Профи</span></p>
                    <p class="map-pro-gate-desc">Карта мусорок показывает точное расположение всех мусорных точек на игровой карте с координатами.</p>
                    <button class="btn-primary map-pro-gate-btn" onclick="switchTab('settings')">
                        <svg width="14" height="14" viewBox="0 0 20 20" fill="none"><path d="M10 2l2.09 4.26L17 7.27l-3.5 3.41.83 4.82L10 13.27l-4.33 2.23.83-4.82L3 7.27l4.91-.01L10 2z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
                        Узнать о тарифе Профи
                    </button>
                </div>`;
            mapWrap.style.display = 'none';
            return;
        }

        // ── Show map ─────────────────────────────────────────────
        if (proWrap) proWrap.innerHTML = '';
        mapWrap.style.display = '';   // restore flex layout from .az-map-wrap CSS

        // Inject admin buttons once
        const tbRight = document.getElementById('tm-toolbar-right');
        if (tbRight && userIsAdmin && !tbRight.children.length) {
            tbRight.innerHTML = `
                <label class="btn-primary tm-upload-btn" title="Загрузить .json с координатами мусорок">
                    <svg width="13" height="13" viewBox="0 0 20 20" fill="none"><path d="M10 3v10M6 7l4-4 4 4M4 15h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    Загрузить JSON
                    <input type="file" accept=".json" style="display:none" onchange="tmHandleUpload(this)">
                </label>
                <button class="btn-ghost tm-clear-btn" onclick="tmClearMap()" title="Очистить всю базу мусорок">
                    <svg width="13" height="13" viewBox="0 0 20 20" fill="none"><path d="M3 5h14M8 5V3h4v2M8 9v6M12 9v6M5 5h10l-1 13H6L5 5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    Очистить базу
                </button>`;
        }

        // Show the inner map div (hidden by default in template)
        const inner = document.getElementById('tm-map-inner');
        if (inner) inner.style.display = '';

        // First visit: attach interaction handlers once
        if (!_tmInited) {
            tmInitInteraction();
            _tmInited = true;
        }

        // Let layout settle, then centre + render
        await new Promise(r => setTimeout(r, 50));
        tmCenterMap();
        tmApply();
        await tmLoadData();
    };

    window.tmHandleUpload = async function (input) {
        const file = input.files[0];
        if (!file) return;
        const statusEl = document.getElementById('tm-upload-status');
        if (statusEl) statusEl.textContent = 'Загружаю...';

        const fd = new FormData();
        fd.append('file', file);
        try {
            const res  = await fetch('/api/trash_map/upload', { method: 'POST', body: fd });
            const data = await res.json();
            if (data.ok) {
                if (statusEl) statusEl.textContent = `Добавлено ${data.added} точек · Всего: ${data.total}`;
                await tmLoadData();
            } else {
                if (statusEl) statusEl.textContent = 'Ошибка: ' + (data.error || 'неизвестная');
            }
        } catch(e) {
            if (statusEl) statusEl.textContent = 'Ошибка сети';
        }
        input.value = '';
    };

    window.tmClearMap = async function () {
        if (!confirm('Очистить всю базу мусорок? Это действие нельзя отменить.')) return;
        const statusEl = document.getElementById('tm-upload-status');
        try {
            const res  = await fetch('/api/trash_map/clear', { method: 'POST' });
            const data = await res.json();
            if (data.ok) {
                if (statusEl) statusEl.textContent = 'База очищена';
                await tmLoadData();
            }
        } catch(e) {}
    };
})();

function renderMapProGate(wrapperId, typeName, typeKey) {
    const wrap = document.getElementById(wrapperId);
    if (!wrap) return;

    if (userPlan === 'pro' || userIsAdmin) {
        wrap.innerHTML = `
            <div class="map-controls">
                <div class="map-stat-pill">
                    <svg width="13" height="13" viewBox="0 0 20 20" fill="none">
                        <path d="M10 2C6.686 2 4 4.686 4 8c0 4.5 6 10 6 10s6-5.5 6-10c0-3.314-2.686-6-6-6z" stroke="currentColor" stroke-width="1.5"/>
                        <circle cx="10" cy="8" r="2" stroke="currentColor" stroke-width="1.5"/>
                    </svg>
                    <span>— точек</span>
                </div>
            </div>
            <div class="map-container">
                <div class="map-coming-soon">
                    <svg width="48" height="48" viewBox="0 0 20 20" fill="none" opacity="0.3">
                        <path d="M10 2C6.686 2 4 4.686 4 8c0 4.5 6 10 6 10s6-5.5 6-10c0-3.314-2.686-6-6-6z" stroke="currentColor" stroke-width="1.2"/>
                        <circle cx="10" cy="8" r="2.5" stroke="currentColor" stroke-width="1.2"/>
                    </svg>
                    <p class="map-coming-title">Карта ${typeName}</p>
                    <p class="map-coming-sub">Данные скоро появятся</p>
                </div>
            </div>
        `;
    } else {
        wrap.innerHTML = `
            <div class="map-pro-gate">
                <div class="map-pro-gate-icon">
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
                        <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" stroke-width="1.5"/>
                        <path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        <circle cx="12" cy="16" r="1.5" fill="currentColor"/>
                    </svg>
                </div>
                <p class="map-pro-gate-title">Карта ${typeName}</p>
                <p class="map-pro-gate-sub">Эта функция доступна только на тарифе <span class="map-pro-badge">Профи</span></p>
                <p class="map-pro-gate-desc">Карта ${typeName} показывает точное расположение всех точек на игровой карте с координатами и дополнительной информацией.</p>
                <button class="btn-primary map-pro-gate-btn" onclick="switchTab('settings')">
                    <svg width="14" height="14" viewBox="0 0 20 20" fill="none"><path d="M10 2l2.09 4.26L17 7.27l-3.5 3.41.83 4.82L10 13.27l-4.33 2.23.83-4.82L3 7.27l4.91-.01L10 2z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
                    Узнать о тарифе Профи
                </button>
            </div>
        `;
    }
}

// ─── Inventory Modal ─────────────────────────────────────────
async function showInventoryModal() {
    const modal   = document.getElementById('inventoryModal');
    const content = document.getElementById('inventoryContent');
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка инвентаря...</p></div>';
    modal.classList.add('open');
    try {
        const res  = await fetch('/api/inventory-summary?t=' + Date.now());
        const data = await res.json();
        if (data.success && data.data.items.length > 0) {
            const d = data.data;
            let html = `
                <div class="inv-summary">
                    <div class="inv-sum-item"><span class="inv-sum-label">Видов</span><span class="inv-sum-value">${d.item_types}</span></div>
                    <div class="inv-sum-item"><span class="inv-sum-label">Штук</span><span class="inv-sum-value">${d.total_items.toLocaleString()}</span></div>
                    <div class="inv-sum-item"><span class="inv-sum-label">Стоимость</span><span class="inv-sum-value gold">${d.total_cost.toLocaleString()}</span></div>
                </div>
            `;
            d.items.forEach(item => {
                html += `
                    <div class="inv-item">
                        <div>
                            <div class="inv-name">${item.name}</div>
                            <div class="inv-qty">${item.qty.toLocaleString()} шт</div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span class="inv-cost">${item.total_cost.toLocaleString()} SA$</span>
                            <button class="btn-delete-item" onclick="deleteItem('${item.name.replace(/'/g, "\\'")}')">
                                <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                                    <path d="M3 5h14M8 5V3h4v2M8 9v6M12 9v6M5 5h10l-1 13H6L5 5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `;
            });
            content.innerHTML = html;
        } else {
            content.innerHTML = '<div class="empty-state"><p>Инвентарь пуст</p></div>';
        }
        updateHeaderStats();
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

function closeInventoryModal() { document.getElementById('inventoryModal').classList.remove('open'); }

// ─── Scanner ─────────────────────────────────────────────────
async function loadScanner() {
    try {
        const res  = await fetch('/api/scanner');
        const resp = await res.json();
        updateScannerContent(resp);
    } catch(e) {}
}

async function scanScanner() {
    if (scannerLoading) return;
    scannerLoading = true;
    document.getElementById('scanner-content').innerHTML =
        '<div class="empty-state"><div class="spinner"></div><p>Сканирую лавки...</p></div>';
    const res  = await fetch('/scan_scanner', {method: 'POST'});
    const data = await res.json();
    if (data.status === 'cooldown') {
        document.getElementById('scanner-content').innerHTML =
            `<div class="empty-state"><p>⏳ ${data.message}</p></div>`;
        setStatus('scanner-status', '', data.message);
        scannerLoading = false;
        return;
    }
    setTimeout(() => { loadScanner(); scannerLoading = false; }, 2500);
}

async function toggleAutoScanner() {
    const res    = await fetch('/toggle_auto_scanner', {method: 'POST'});
    const result = await res.json();
    if (result.success === false) {
        showToast(result.error || 'Недоступно в вашем тарифе');
        return;
    }
    const btn = document.getElementById('auto-scanner-btn');
    const dot = document.getElementById('dot-scanner');
    if (result.scanner_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
        dot.classList.add('on');
        setStatus('scanner-status', 'ok', 'Автоскан активен — обновление каждые 30 сек');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан';
        dot.classList.remove('on');
        setStatus('scanner-status', '', 'Автоскан выключен');
    }
}

// ─── Arbitrage BUY→SELL ──────────────────────────────────────
async function loadArbitrage() {
    try {
        const res  = await fetch(`/api/arbitrage?buy=${selectedBuyServer}&sell=${selectedSellServer}&commission=${userCommission}`);
        const resp = await res.json();
        // resp.data = {deals: [...], status: "...", last_update: "..."}
        const state = resp.data || {};
        updateArbitrageContent(state.deals || [], state.status, state.last_update,
                               resp.buy_id, resp.sell_id, resp.buy_name, resp.sell_name, resp.sell_rate);
    } catch(e) {}
}

async function scanArbitrage() {
    if (arbitrageLoading) return;
    arbitrageLoading = true;
    const btn = document.getElementById('arbitrage-scan-btn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Сканирую...';
    const buyInfo  = getServerInfo(selectedBuyServer);
    const sellInfo = getServerInfo(selectedSellServer);
    setStatus('arbitrage-status', '', `Сканирую ${buyInfo?.name || selectedBuyServer} → ${sellInfo?.name || selectedSellServer}...`);
    const res  = await fetch(`/scan_arbitrage?buy=${selectedBuyServer}&sell=${selectedSellServer}`, {method: 'POST'});
    const data = await res.json();
    if (data.status === 'cooldown') {
        setStatus('arbitrage-status', '', data.message);
        btn.disabled = false;
        btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><path d="M3 10h14M13 6l4 4-4 4M7 6L3 10l4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Скан';
        arbitrageLoading = false;
        return;
    }
    setTimeout(() => {
        loadArbitrage();
        btn.disabled = false;
        btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><path d="M3 10h14M13 6l4 4-4 4M7 6L3 10l4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Скан';
        arbitrageLoading = false;
    }, 3000);
}

async function toggleAutoArbitrage() {
    const res    = await fetch('/toggle_auto_arbitrage', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ buy: selectedBuyServer, sell: selectedSellServer })
    });
    const result = await res.json();
    if (result.success === false) {
        showToast(result.error || 'Недоступно в вашем тарифе');
        return;
    }
    const btn    = document.getElementById('auto-arbitrage-btn');
    const dot    = document.getElementById('dot-arbitrage');
    if (result.arbitrage_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
        dot.classList.add('on');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби';
        dot.classList.remove('on');
    }
}

// ─── Status bar helper ───────────────────────────────────────
function setStatus(id, type, text) {
    const bar = document.getElementById(id);
    if (!bar) return;
    const ind = bar.querySelector('.status-indicator');
    if (ind) ind.className = 'status-indicator' + (type ? ' ' + type : '');
    const span = bar.querySelector('span');
    if (span) span.textContent = text;
}

// ─── Scanner Content ─────────────────────────────────────────
// resp = full API response: {success, data: [sorted_lavki, total_stats]}
// sorted_lavki = [[lavka_uid, {item_name: [item_objs]}], ...]
// item_obj = {name, quantity, buy_price, buy_price_per_unit, lavka_uid, lavka_price, lavka_count, profit, entries}
function updateScannerContent(resp) {
    const content  = document.getElementById('scanner-content');
    const statusEl = document.getElementById('scanner-status');

    if (!resp || !resp.success || !resp.data) {
        setStatus('scanner-status', '', 'Нет данных — нажмите «Скан» для запуска');
        content.innerHTML = '<div class="empty-state"><p>Нажмите «Скан» для запуска сканирования</p></div>';
        return;
    }

    // data is [sorted_lavki, total_stats]
    const sortedLavki = resp.data[0] || [];   // [[uid, {name: [items]}], ...]
    const totalStats  = resp.data[1] || {};

    if (!sortedLavki.length) {
        setStatus('scanner-status', '', 'Нет предметов в inventory.json');
        content.innerHTML = '<div class="empty-state"><p>Нет предметов в инвентаре</p></div>';
        return;
    }

    const totalProfit = totalStats.total_profit || 0;
    const totalItems  = totalStats.item_groups  || 0;
    const lavkaCount  = totalStats.lavka_count  || 0;
    setStatus('scanner-status', 'ok', `${lavkaCount} лавок · ${totalItems} позиций · профит +${Math.ceil(totalProfit).toLocaleString()} SA$`);

    let html = `
        <div class="stats-card">
            <div class="stat-item"><span class="stat-label">Лавок</span><span class="stat-value">${lavkaCount}</span></div>
            <div class="stat-item"><span class="stat-label">Позиций</span><span class="stat-value">${totalItems}</span></div>
            <div class="stat-item"><span class="stat-label">Профит</span><span class="stat-value green">+${Math.ceil(totalProfit).toLocaleString()} SA$</span></div>
        </div>
    `;

    sortedLavki.forEach(([lavkaUid, itemGroups]) => {
        // itemGroups = {item_name: [item_objs]}
        const allItems = Object.values(itemGroups).flat();
        const lavkaProfit = allItems.reduce((s, it) => s + (it.profit || 0), 0);
        const posClass    = lavkaProfit >= 0 ? 'pos' : 'neg';
        const sign        = lavkaProfit >= 0 ? '+' : '';

        html += `
            <div class="lavka-card">
                <div class="lavka-head">
                    <div class="lavka-icon">🏪</div>
                    <span class="lavka-id">Лавка #${lavkaUid}</span>
                    <span class="lavka-items-count">${allItems.length} позиций</span>
                    <button class="copy-cmd-btn" onclick="copyToClipboard('/findilavka ${lavkaUid}')">
                        📋 /findilavka ${lavkaUid}
                    </button>
                    <span class="lavka-profit ${posClass}">${sign}${Math.ceil(lavkaProfit).toLocaleString()} SA$</span>
                </div>
                <div class="lavka-body">
        `;

        allItems.sort((a, b) => (b.profit || 0) - (a.profit || 0));
        allItems.forEach(item => {
            const profit  = item.profit || 0;
            const pClass  = profit >= 0 ? 'profit-ok' : 'profit-bad';
            const profCls = profit >= 0 ? 'pos' : 'neg';
            const pSign   = profit >= 0 ? '+' : '';
            html += `
                <div class="detail-line ${pClass}">
                    <div class="detail-line-left">
                        <span class="detail-name">${item.name}</span>
                        <span class="detail-buy">Куплено: ${(item.buy_price_per_unit || 0).toLocaleString()} SA$/шт × ${item.quantity || 0} шт</span>
                    </div>
                    <div class="detail-line-right">
                        <span class="detail-lavka">Скупка: ${(item.lavka_price || 0).toLocaleString()} VC$ · ${item.lavka_count || 0} шт</span>
                        <span class="detail-profit ${profCls}">${pSign}${Math.ceil(profit).toLocaleString()} SA$</span>
                    </div>
                </div>
            `;
        });

        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Arbitrage Content ───────────────────────────────────────
// deals = array of deal objects from data.data.deals
function updateArbitrageContent(deals, apiStatus, lastUpdate, buyId, sellId, buyName, sellName, sellRate) {
    const content = document.getElementById('arbitrage-content');

    // Save deals for filter re-apply
    lastArbitrageData = deals;

    const statusText = apiStatus || '';
    const hasScanned = statusText !== 'Нажмите «Скан»' && statusText !== '';

    if (!hasScanned) {
        setStatus('arbitrage-status', '', 'Нажмите «Скан» для запуска арбитража');
        content.innerHTML = '<div class="empty-state"><p>Нажмите «Скан» для запуска арбитража</p></div>';
        return;
    }

    const filtered = applyArbFilters(deals || []);

    const buyCurrency  = buyId  === 0 ? 'VC$' : 'SA$';
    const totalBuyAmt  = filtered.reduce((s, d) => s + (d.price_buy || 0) * (d.count_buy || 1), 0);
    const totalProfit  = filtered.reduce((s, d) => s + (d.total_profit || 0), 0);
    const totalProfPct = totalBuyAmt > 0 ? (totalProfit / totalBuyAmt * 100).toFixed(1) : 0;

    const label = buyName && sellName
        ? `${buyName} → ${sellName} • ${filtered.length} сделок`
        : statusText;
    setStatus('arbitrage-status', filtered.length > 0 ? 'ok' : '', label);

    if (filtered.length > 0) {
        const statsBar = document.getElementById('arb-global-stats');
        if (statsBar) {
            statsBar.innerHTML = `
                <span class="arb-stat-item">Скупить на: <strong>${totalBuyAmt.toLocaleString()} ${buyCurrency}</strong></span>
                <span class="arb-stat-sep">·</span>
                <span class="arb-stat-item">Профит: <strong class="green-text">+${totalProfit.toLocaleString()} ${buyCurrency}</strong></span>
                <span class="arb-stat-sep">·</span>
                <span class="arb-stat-item"><strong class="cyan-text">+${totalProfPct}%</strong></span>
            `;
            statsBar.style.display = 'flex';
        }
    } else {
        const statsBar = document.getElementById('arb-global-stats');
        if (statsBar) statsBar.style.display = 'none';
    }

    if (!filtered.length) {
        content.innerHTML = `<div class="empty-state"><p>${hasScanned ? 'Нет арбитражных возможностей по выбранным параметрам' : 'Нажмите «Скан» для запуска арбитража'}</p></div>`;
        return;
    }

    // Group by buy lavka
    const grouped = {};
    filtered.forEach(d => {
        const key = d.lavka_buy || '?';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(d);
    });

    const sortedLavkas = Object.keys(grouped)
        .map(id => ({ id, profit: grouped[id].reduce((s, d) => s + (d.total_profit || 0), 0) }))
        .sort((a, b) => b.profit - a.profit)
        .map(x => x.id);

    let html = '';
    sortedLavkas.forEach(lavkaId => {
        const group       = [...grouped[lavkaId]].sort((a, b) => (b.total_profit || 0) - (a.total_profit || 0));
        const groupProfit = group.reduce((s, d) => s + (d.total_profit || 0), 0);
        const currency    = buyId === 0 ? 'VC$' : 'SA$';

        html += `
            <div class="arb-card">
                <div class="arb-head">
                    <div class="arb-icon">🔄</div>
                    <span class="arb-id">Лавка #${lavkaId}</span>
                    <span class="arb-count">${group.length} позиций</span>
                    <button class="copy-cmd-btn" onclick="copyToClipboard('/findilavka ${lavkaId}')">📋 /findilavka ${lavkaId}</button>
                    <span class="arb-total">+${Math.ceil(groupProfit).toLocaleString()} ${currency}</span>
                </div>
                <div class="table-wrap">
                    <table class="arb-table">
                        <thead><tr>
                            <th>Скуп лавка</th><th>Предмет</th><th>Покупка</th>
                            <th>Скупка</th><th>Профит/шт</th><th>%</th><th>Итого</th><th>Кол-во</th><th></th>
                        </tr></thead>
                        <tbody>
        `;
        group.slice(0, 30).forEach(d => {
            const buyCur  = d.buy_currency  || (buyId  === 0 ? 'VC$' : 'SA$');
            const sellCur = d.sell_currency || (sellId === 0 ? 'VC$' : 'SA$');
            html += `
                <tr>
                    <td class="td-sell">#${d.lavka_sell || '—'}</td>
                    <td class="td-item" title="${d.item}">${(d.item || '—').slice(0, 26)}${(d.item || '').length > 26 ? '…' : ''}</td>
                    <td class="td-num">${Math.ceil(d.price_buy || 0).toLocaleString()} ${buyCur}</td>
                    <td class="td-num">${Math.ceil(d.price_sell || 0).toLocaleString()} ${sellCur}</td>
                    <td class="td-profit">+${Math.ceil(d.profit || 0).toLocaleString()} ${buyCur}</td>
                    <td class="td-pct">${d.profit_pct || 0}%</td>
                    <td class="td-profit">+${Math.ceil(d.total_profit || 0).toLocaleString()} ${buyCur}</td>
                    <td class="td-num">${d.count_buy || 0} шт</td>
                    <td class="td-action"><button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${d.lavka_sell}')">копировать</button></td>
                </tr>
            `;
        });
        html += `</tbody></table>`;
        if (group.length > 30) html += `<div class="more-deals">+${group.length - 30} ещё позиций</div>`;
        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Dashboard ───────────────────────────────────────────────
let balanceChart = null;

async function loadDashboard() {
    try {
        const [balRes, invRes] = await Promise.all([
            fetch('/api/balance/history'),
            fetch('/api/inventory-summary?t=' + Date.now())
        ]);
        const balData = await balRes.json();
        if (balData.success) renderDashboard(balData.records || []);
        const invData = await invRes.json();
        renderDashboardInventory(invData);
    } catch(e) {}
}

function renderDashboardInventory(data) {
    const el = document.getElementById('dash-inv-list');
    if (!el) return;
    if (!data.success || !data.data || !data.data.items.length) {
        el.innerHTML = '<div class="empty-state" style="min-height:100px"><p>Инвентарь пуст</p></div>';
        return;
    }
    const d = data.data;
    let html = `
        <div class="inv-summary" style="margin-bottom:8px">
            <div class="inv-sum-item"><span class="inv-sum-label">Видов</span><span class="inv-sum-value">${d.item_types}</span></div>
            <div class="inv-sum-item"><span class="inv-sum-label">Штук</span><span class="inv-sum-value">${d.total_items.toLocaleString()}</span></div>
            <div class="inv-sum-item"><span class="inv-sum-label">Стоимость</span><span class="inv-sum-value gold">${d.total_cost.toLocaleString()}</span></div>
        </div>
    `;
    d.items.forEach(item => {
        html += `
            <div class="inv-item">
                <div>
                    <div class="inv-name">${item.name}</div>
                    <div class="inv-qty">${item.qty.toLocaleString()} шт</div>
                </div>
                <div style="display:flex;align-items:center;gap:8px">
                    <span class="inv-cost">${item.total_cost.toLocaleString()} SA$</span>
                    <button class="btn-delete-item" onclick="deleteItem('${item.name.replace(/'/g, "\\'")}').then(()=>loadDashboard())">
                        <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                            <path d="M3 5h14M8 5V3h4v2M8 9v6M12 9v6M5 5h10l-1 13H6L5 5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;
    });
    el.innerHTML = html;
}

function renderDashboard(records) {
    const todayEl   = document.getElementById('dash-today');
    const allEl     = document.getElementById('dash-all');
    const curEl     = document.getElementById('dash-current');
    const countEl   = document.getElementById('dash-count');
    const histEl    = document.getElementById('dash-history-list');
    const chartSub  = document.getElementById('dash-chart-sub');

    if (!records.length) {
        if (todayEl)  todayEl.textContent  = '0 SA$';
        if (allEl)    allEl.textContent    = '0 SA$';
        if (curEl)    curEl.textContent    = '— SA$';
        if (countEl)  countEl.textContent  = '0';
        if (histEl)   histEl.innerHTML     = '<div class="empty-state" style="min-height:120px"><p>Нет записей. Добавьте первый баланс.</p></div>';
        return;
    }

    const today     = new Date().toDateString();
    const todayRecs = records.filter(r => new Date(r.timestamp).toDateString() === today);
    const todayProfit = todayRecs.length > 1
        ? todayRecs[todayRecs.length-1].amount - todayRecs[0].amount
        : 0;
    const allProfit = records.length > 1
        ? records[records.length-1].amount - records[0].amount
        : 0;

    if (todayEl) todayEl.textContent  = (todayProfit >= 0 ? '+' : '') + Math.round(todayProfit).toLocaleString() + ' SA$';
    if (allEl)   allEl.textContent    = (allProfit   >= 0 ? '+' : '') + Math.round(allProfit).toLocaleString()   + ' SA$';
    if (curEl)   curEl.textContent    = Math.round(records[records.length-1].amount).toLocaleString() + ' SA$';
    if (countEl) countEl.textContent  = records.length;
    if (chartSub) chartSub.textContent = `SA$ · ${records.length} записей`;

    const sorted = [...records].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    if (histEl) {
        histEl.innerHTML = [...sorted].reverse().map((r, i, arr) => {
            const prev  = arr[i + 1];
            const delta = prev ? r.amount - prev.amount : null;
            const dSign = delta !== null ? (delta >= 0 ? '+' : '') : '';
            const dCls  = delta !== null ? (delta >= 0 ? 'pos' : 'neg') : '';
            const dt    = new Date(r.timestamp);
            const timeStr = dt.toLocaleString('ru', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' });
            return `
                <div class="hist-row">
                    <div class="hist-left">
                        <span class="hist-time">${timeStr}</span>
                        <span class="hist-note">${r.note || '—'}</span>
                    </div>
                    <div class="hist-right">
                        <span class="hist-amount">${Math.round(r.amount).toLocaleString()} SA$</span>
                        ${delta !== null ? `<span class="hist-delta ${dCls}">${dSign}${Math.round(delta).toLocaleString()}</span>` : ''}
                        <button class="btn-copy-small" onclick="deleteBalanceRecord('${r.id}')">✕</button>
                    </div>
                </div>
            `;
        }).join('');
    }

    const labels = sorted.map(r => {
        const dt = new Date(r.timestamp);
        return dt.toLocaleString('ru', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' });
    });
    const values = sorted.map(r => r.amount);

    const ctx = document.getElementById('balance-chart')?.getContext('2d');
    if (!ctx) return;
    if (balanceChart) { balanceChart.destroy(); balanceChart = null; }

    balanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                data: values,
                borderColor: '#5B5FEF',
                backgroundColor: 'rgba(91,95,239,0.12)',
                borderWidth: 2,
                pointRadius: values.length > 30 ? 0 : 3,
                pointHoverRadius: 5,
                fill: true,
                tension: 0.35,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: {
                backgroundColor: '#1A1D27',
                borderColor: 'rgba(91,95,239,0.45)',
                borderWidth: 1,
                titleColor: '#fafaf8',
                bodyColor: '#c4b5fd',
                callbacks: { label: ctx => ' ' + Math.round(ctx.parsed.y).toLocaleString() + ' SA$' }
            }},
            scales: {
                x: { display: false },
                y: {
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    ticks: { color: '#52525b', font: { family: 'JetBrains Mono', size: 11 }, callback: v => v.toLocaleString() }
                }
            }
        }
    });
}

async function addBalanceRecord() {
    const amountEl = document.getElementById('balance-amount-input');
    const noteEl   = document.getElementById('balance-note-input');
    const amount   = parseFloat(amountEl.value);
    if (!amount || amount < 0) return;
    try {
        await fetch('/api/balance/add', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ amount, note: noteEl.value.trim() })
        });
        amountEl.value = '';
        noteEl.value   = '';
        loadDashboard();
    } catch(e) {}
}

async function deleteBalanceRecord(id) {
    try {
        await fetch('/api/balance/delete', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        loadDashboard();
    } catch(e) {}
}

// ─── Market ──────────────────────────────────────────────────
let marketData    = null;
let marketSortAsc = true;

function buildMarketServerSelect() {
    const sel = document.getElementById('market-server-select');
    if (!sel) return;
    sel.innerHTML = '';
    currencyRates.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.id === 0 ? `0. ${s.name}` : `${s.id}. ${s.name}`;
        if (s.id === userServer) opt.selected = true;
        sel.appendChild(opt);
    });
}

async function searchMarket() {
    const query    = document.getElementById('market-search-input').value.trim();
    const serverId = parseInt(document.getElementById('market-server-select').value) || 0;
    const btn      = document.getElementById('market-search-btn');

    if (!query) {
        setStatus('market-status', '', 'Введите название товара');
        return;
    }
    btn.disabled = true;
    btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Ищу...';
    setStatus('market-status', '', `Поиск "${query}" на сервере ${serverId}...`);
    try {
        const res  = await fetch(`/api/market?q=${encodeURIComponent(query)}&server=${serverId}`);
        const data = await res.json();
        if (!data.success) {
            setStatus('market-status', '', data.error || 'Ошибка поиска');
        } else {
            marketData = data;
            const totalBuy  = data.buy_shops.length;
            const totalSell = data.sell_shops.length;
            if (totalBuy + totalSell === 0) {
                setStatus('market-status', '', `Ничего не найдено по запросу "${query}"`);
            } else {
                setStatus('market-status', 'ok', `Найдено: ${totalBuy} скупщиков · ${totalSell} продавцов`);
            }
            renderMarket();
        }
    } catch(e) {
        setStatus('market-status', '', 'Ошибка соединения');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="8.5" cy="8.5" r="5.5" stroke="currentColor" stroke-width="1.5"/><path d="M13 13l3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Поиск';
    }
}

function toggleMarketSort() {
    marketSortAsc = !marketSortAsc;
    const label = document.getElementById('market-sort-label');
    const btn   = document.getElementById('market-sort-btn');
    if (marketSortAsc) { label.textContent = 'По цене ↑'; btn.classList.remove('sort-desc'); }
    else               { label.textContent = 'По цене ↓'; btn.classList.add('sort-desc'); }
    renderMarket();
}

function renderMarket() {
    const buyList  = document.getElementById('market-buy-list');
    const sellList = document.getElementById('market-sell-list');
    const buyCount  = document.getElementById('buy-count');
    const sellCount = document.getElementById('sell-count');
    const sortFn = (a, b) => marketSortAsc ? a.price - b.price : b.price - a.price;
    const buySorted  = [...(marketData.buy_shops  || [])].sort(sortFn);
    const sellSorted = [...(marketData.sell_shops || [])].sort(sortFn);
    if (buyCount)  buyCount.textContent  = buySorted.length  ? `(${buySorted.length})`  : '';
    if (sellCount) sellCount.textContent = sellSorted.length ? `(${sellSorted.length})` : '';
    buyList.innerHTML  = buySorted.length  ? renderMarketRows(buySorted,  'buy')  : '<div class="empty-state" style="min-height:200px"><p>Скупщики не найдены</p></div>';
    sellList.innerHTML = sellSorted.length ? renderMarketRows(sellSorted, 'sell') : '<div class="empty-state" style="min-height:200px"><p>Продавцы не найдены</p></div>';
}

function renderMarketRows(shops, type) {
    const serverId = parseInt(document.getElementById('market-server-select').value) || 0;
    const currency = serverId === 0 ? 'VC$' : 'SA$';
    let html = `
        <table class="market-table">
            <thead><tr>
                <th>Лавка</th>
                <th>Товар</th>
                <th>${type === 'buy' ? `Цена скупки (${currency})` : `Цена продажи (${currency})`}</th>
                <th>Кол-во</th>
                <th></th>
            </tr></thead>
            <tbody>
    `;
    shops.forEach(s => {
        const favActive = isFavorite(s.item_name);
        const safeItem  = s.item_name.replace(/'/g, "\\'").replace(/"/g, '&quot;');
        html += `
            <tr>
                <td class="td-lavka">#${s.lavka_uid}</td>
                <td class="td-item" title="${s.item_name}">${s.item_name.slice(0, 28)}${s.item_name.length > 28 ? '…' : ''}</td>
                <td class="td-price ${type === 'buy' ? 'price-buy' : 'price-sell'}">${s.price.toLocaleString()} ${currency}</td>
                <td class="td-count">${s.count > 0 ? s.count.toLocaleString() + ' шт' : '—'}</td>
                <td class="td-action" style="white-space:nowrap;display:flex;gap:4px;align-items:center">
                    <button class="fav-btn${favActive ? ' active' : ''}" data-item="${s.item_name.replace(/"/g, '&quot;')}"
                        title="${favActive ? 'Убрать из избранного' : 'Добавить в избранное'}"
                        onclick="toggleFavorite('${safeItem}', ${serverId}, ${s.price}, '${type}')">
                        <svg width="13" height="13" viewBox="0 0 20 20" fill="none">
                            <path d="M10 2l2.09 4.26L17 7.27l-3.5 3.41.83 4.82L10 13.27l-4.33 2.23.83-4.82L3 7.27l4.91-.01L10 2z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${s.lavka_uid}')">копировать</button>
                </td>
            </tr>
        `;
    });
    html += '</tbody></table>';
    return html;
}

// ─── Авторынок ───────────────────────────────────────────────
let _avtoListings = [];

async function loadAvtomarket() {
    const statusEl = document.getElementById('avto-status');
    const statusTxt = document.getElementById('avto-status-text');
    if (statusEl) { statusEl.style.display = 'flex'; statusTxt.textContent = 'Загрузка...'; }
    try {
        const res  = await fetch('/api/avtomarket?t=' + Date.now());
        const data = await res.json();
        if (!data.success) throw new Error();
        _avtoListings = data.listings || [];
        avtoFillServerFilter();
        avtoRender();
        if (statusEl) statusEl.style.display = 'none';
    } catch(e) {
        if (statusEl) { statusTxt.textContent = 'Ошибка загрузки'; }
    }
}

function avtoFillServerFilter() {
    const ids = [...new Set(_avtoListings.map(l => l.server_id))].sort((a,b) => a-b);
    const sel  = document.getElementById('avto-server-select');
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '<option value="0">Все</option>';
    ids.forEach(id => {
        const opt = document.createElement('option');
        opt.value = id;
        opt.textContent = 'Сервер ' + id;
        sel.appendChild(opt);
    });
    sel.value = cur;

    // Also fill modal server select
    const modalSel = document.getElementById('avto-server-modal');
    if (modalSel) {
        const curM = modalSel.value;
        modalSel.innerHTML = '';
        for (let i = 1; i <= 32; i++) {
            const o = document.createElement('option');
            o.value = i; o.textContent = 'Сервер ' + i;
            modalSel.appendChild(o);
        }
        if (curM) modalSel.value = curM;
    }
}

function avtoRender() {
    const query   = (document.getElementById('avto-search-input')?.value || '').toLowerCase().trim();
    const serverId = parseInt(document.getElementById('avto-server-select')?.value || '0');
    const sort    = document.getElementById('avto-sort-select')?.value || 'date';

    let list = _avtoListings.filter(l => {
        const matchQ = !query || l.model.toLowerCase().includes(query) || (l.note && l.note.toLowerCase().includes(query));
        const matchS = !serverId || l.server_id === serverId;
        return matchQ && matchS;
    });

    const sortFn = {
        date:       (a, b) => b.added_at.localeCompare(a.added_at),
        price_asc:  (a, b) => a.price - b.price,
        price_desc: (a, b) => b.price - a.price,
        cond:       (a, b) => b.condition - a.condition,
    }[sort] || ((a,b) => 0);

    list.sort(sortFn);

    const sells = list.filter(l => l.ad_type === 'sell');
    const buys  = list.filter(l => l.ad_type === 'buy');

    const sellEl = document.getElementById('avto-sell-list');
    const buyEl  = document.getElementById('avto-buy-list');
    const sellCnt = document.getElementById('avto-sell-count');
    const buyCnt  = document.getElementById('avto-buy-count');

    if (sellCnt) sellCnt.textContent = sells.length ? `(${sells.length})` : '';
    if (buyCnt)  buyCnt.textContent  = buys.length  ? `(${buys.length})`  : '';

    if (sellEl) sellEl.innerHTML = sells.length ? avtoRenderRows(sells) : '<div class="empty-state" style="min-height:200px"><p>Нет объявлений о продаже</p></div>';
    if (buyEl)  buyEl.innerHTML  = buys.length  ? avtoRenderRows(buys)  : '<div class="empty-state" style="min-height:200px"><p>Нет объявлений о поиске</p></div>';
}

function avtoRenderRows(list) {
    let html = '';
    list.forEach(l => {
        const condCls = l.condition >= 80 ? 'avto-cond-good' : l.condition >= 50 ? 'avto-cond-mid' : 'avto-cond-bad';
        const isOwn   = l.added_by === (window._currentUser || '');
        html += `
        <div class="avto-card">
            <div class="avto-card-top">
                <div class="avto-model">${l.model}</div>
                <div class="avto-price">${l.price.toLocaleString()} SA$</div>
            </div>
            <div class="avto-card-meta">
                <span class="avto-badge">Сервер ${l.server_id}</span>
                <span class="avto-badge ${condCls}">Сост. ${l.condition}%</span>
                ${l.contact ? `<span class="avto-badge avto-contact">
                    <svg width="10" height="10" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="7" r="3" stroke="currentColor" stroke-width="1.5"/><path d="M4 18c0-3.3 2.7-6 6-6s6 2.7 6 6" stroke="currentColor" stroke-width="1.5"/></svg>
                    ${l.contact}
                </span>` : ''}
                ${l.note ? `<span class="avto-note" title="${l.note}">${l.note.slice(0,40)}${l.note.length > 40 ? '…' : ''}</span>` : ''}
            </div>
            <div class="avto-card-footer">
                <span class="avto-date">${l.added_at}</span>
                <div style="display:flex;gap:6px">
                    <button class="btn-copy-small" onclick="copyToClipboard('/купитьавто ${l.model} ${l.server_id}')">копировать</button>
                    ${(isOwn || window._isAdmin) ? `<button class="btn-copy-small avto-del-btn" onclick="deleteAvtoListing('${l.id}')">удалить</button>` : ''}
                </div>
            </div>
        </div>`;
    });
    return html;
}

function openAvtoAddModal() {
    avtoFillServerFilter();
    document.getElementById('avto-model-input').value   = '';
    document.getElementById('avto-price-input').value   = '';
    document.getElementById('avto-cond-input').value    = '100';
    document.getElementById('avto-contact-input').value = '';
    document.getElementById('avto-note-input').value    = '';
    document.querySelector('input[name="avto_type"][value="sell"]').checked = true;
    const errEl = document.getElementById('avto-modal-error');
    if (errEl) errEl.style.display = 'none';
    document.getElementById('avtoAddModal').classList.add('open');
    setTimeout(() => document.getElementById('avto-model-input').focus(), 50);
}

function closeAvtoAddModal() {
    document.getElementById('avtoAddModal').classList.remove('open');
}

async function submitAvtoListing() {
    const errEl  = document.getElementById('avto-modal-error');
    const btn    = document.getElementById('avto-submit-btn');
    const model  = document.getElementById('avto-model-input').value.trim();
    const price  = parseInt(document.getElementById('avto-price-input').value);
    const server = parseInt(document.getElementById('avto-server-modal').value || '1');
    const cond   = parseInt(document.getElementById('avto-cond-input').value);
    const contact = document.getElementById('avto-contact-input').value.trim();
    const note    = document.getElementById('avto-note-input').value.trim();
    const adType  = document.querySelector('input[name="avto_type"]:checked')?.value || 'sell';

    errEl.style.display = 'none';
    if (!model) { errEl.textContent = 'Введите марку/модель'; errEl.style.display = 'block'; return; }
    if (!price || price < 0) { errEl.textContent = 'Введите корректную цену'; errEl.style.display = 'block'; return; }

    btn.disabled = true; btn.textContent = 'Публикуем...';
    try {
        const res  = await fetch('/api/avtomarket/add', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ model, price, server_id: server, condition: cond || 100, contact, note, ad_type: adType })
        });
        const data = await res.json();
        if (data.success) {
            closeAvtoAddModal();
            showToast('Объявление опубликовано');
            await loadAvtomarket();
        } else {
            errEl.textContent = data.error || 'Ошибка'; errEl.style.display = 'block';
        }
    } catch(e) {
        errEl.textContent = 'Ошибка сети'; errEl.style.display = 'block';
    }
    btn.disabled = false; btn.textContent = 'Опубликовать';
}

async function deleteAvtoListing(id) {
    if (!confirm('Удалить объявление?')) return;
    try {
        const res  = await fetch('/api/avtomarket/delete', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        const data = await res.json();
        if (data.success) { showToast('Объявление удалено'); await loadAvtomarket(); }
        else showToast('Нет доступа');
    } catch(e) {}
}

// ─── Favorites ───────────────────────────────────────────────
function getFavorites() {
    try { return JSON.parse(localStorage.getItem('r66_favorites') || '[]'); } catch { return []; }
}

function saveFavorites(favs) {
    localStorage.setItem('r66_favorites', JSON.stringify(favs));
}

function isFavorite(itemName) {
    return getFavorites().some(f => f.name === itemName);
}

function toggleFavorite(itemName, serverId, price, type) {
    let favs = getFavorites();
    const idx = favs.findIndex(f => f.name === itemName);
    if (idx >= 0) {
        favs.splice(idx, 1);
    } else {
        favs.push({ name: itemName, serverId, price, type, addedAt: Date.now() });
    }
    saveFavorites(favs);
    document.querySelectorAll(`.fav-btn[data-item="${CSS.escape(itemName)}"]`).forEach(btn => {
        btn.classList.toggle('active', isFavorite(itemName));
        btn.title = isFavorite(itemName) ? 'Убрать из избранного' : 'Добавить в избранное';
    });
}

function clearAllFavorites() {
    saveFavorites([]);
    renderFavorites();
}

function renderFavorites() {
    const el = document.getElementById('favorites-content');
    if (!el) return;
    const favs = getFavorites();
    if (!favs.length) {
        el.innerHTML = `<div class="empty-state">
            <svg width="40" height="40" viewBox="0 0 20 20" fill="none" opacity="0.3">
                <path d="M10 2l2.09 4.26L17 7.27l-3.5 3.41.83 4.82L10 13.27l-4.33 2.23.83-4.82L3 7.27l4.91-.01L10 2z" stroke="currentColor" stroke-width="1.5"/>
            </svg>
            <p>Нет избранных товаров.<br>Добавляйте товары из раздела «Рынок».</p>
        </div>`;
        return;
    }
    let html = `<table class="market-table"><thead><tr>
        <th>Товар</th><th>Тип</th><th>Цена</th><th>Сервер</th><th></th>
    </tr></thead><tbody>`;
    favs.slice().reverse().forEach(f => {
        const typeLabel = f.type === 'buy' ? 'Скупщик' : 'Продавец';
        const typeCls   = f.type === 'buy' ? 'price-buy' : 'price-sell';
        const currency  = (f.serverId === 0 || f.serverId == null) ? 'VC$' : 'SA$';
        html += `<tr>
            <td class="td-item">${f.name}</td>
            <td><span class="fav-type ${typeCls}">${typeLabel}</span></td>
            <td class="td-price ${typeCls}">${f.price ? f.price.toLocaleString() + ' ' + currency : '—'}</td>
            <td class="td-count">Сервер ${f.serverId ?? '—'}</td>
            <td class="td-action">
                <button class="btn-copy-small fav-remove-btn" onclick="toggleFavorite('${f.name.replace(/'/g, "\\'")}'); renderFavorites()">✕ Убрать</button>
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    el.innerHTML = html;
}

// ─── Item modals ─────────────────────────────────────────────
let selectedItemName = '';

async function openAddItemModal() {
    document.getElementById('addItemModal').classList.add('open');
    document.getElementById('itemSearchInput').focus();
}

function closeAddItemModal() {
    document.getElementById('addItemModal').classList.remove('open');
}

async function searchItems() {
    const query   = document.getElementById('itemSearchInput').value.trim();
    const results = document.getElementById('itemSearchResults');
    if (!query || query.length < 2) {
        results.innerHTML = '<p style="color:var(--text-secondary);text-align:center;padding:20px">Начните печатать для поиска...</p>';
        return;
    }
    try {
        const res  = await fetch(`/api/search-items?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (!data.success || !data.items.length) {
            results.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px">Ничего не найдено</p>';
            return;
        }
        results.innerHTML = data.items.slice(0, 30).map(item => `
            <div class="inv-item" style="cursor:pointer;margin-bottom:6px" onclick="openItemDetails('${item.name.replace(/'/g,"\\'")}')">
                <div>
                    <div class="inv-name">${item.name}</div>
                    <div class="inv-qty" style="margin-top:2px">${item.category || ''}</div>
                </div>
                <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M5 10h10M10 5l5 5-5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
        `).join('');
    } catch(e) {
        results.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px">Ошибка загрузки</p>';
    }
}

function openItemDetails(itemName) {
    selectedItemName = itemName;
    document.getElementById('itemDetailsName').textContent = itemName;
    document.getElementById('itemQtyInput').value   = '';
    document.getElementById('itemPriceInput').value = '';
    document.getElementById('addItemModal').classList.remove('open');
    document.getElementById('itemDetailsModal').classList.add('open');
    setTimeout(() => document.getElementById('itemQtyInput').focus(), 50);
}

function closeItemDetailsModal() {
    document.getElementById('itemDetailsModal').classList.remove('open');
}

async function confirmAddItem() {
    const qty   = parseInt(document.getElementById('itemQtyInput').value);
    const price = parseFloat(document.getElementById('itemPriceInput').value);
    if (!qty || !price || qty < 1 || price < 0) return;
    try {
        const res  = await fetch('/api/add-item', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name: selectedItemName, qty, price_per_unit: price })
        });
        const data = await res.json();
        if (data.success) {
            closeItemDetailsModal();
            showToast('Предмет добавлен в инвентарь');
            loadDashboard();
        }
    } catch(e) {}
}

async function deleteItem(itemName) {
    if (!confirm(`Удалить «${itemName}» из инвентаря?`)) return;
    try {
        await fetch('/api/delete-item', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name: itemName })
        });
        loadDashboard();
    } catch(e) {}
}

// ─── Activation Code ─────────────────────────────────────────
async function activateCode() {
    const input = document.getElementById('activation-code-input');
    const statusEl = document.getElementById('activation-status');
    const btn = document.getElementById('activation-btn');
    if (!input || !statusEl) return;
    const code = input.value.trim();
    if (!code) {
        statusEl.textContent = 'Введите код активации';
        statusEl.className = 'activation-status error';
        return;
    }
    btn.disabled = true;
    btn.textContent = 'Проверяю...';
    try {
        const res  = await fetch('/api/activate', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ code })
        });
        const data = await res.json();
        if (data.success) {
            statusEl.textContent = '✅ ' + (data.message || 'Код успешно активирован');
            statusEl.className = 'activation-status success';
            input.value = '';
        } else {
            statusEl.textContent = '❌ ' + (data.error || 'Неверный код активации');
            statusEl.className = 'activation-status error';
        }
    } catch(e) {
        statusEl.textContent = '❌ Ошибка соединения';
        statusEl.className = 'activation-status error';
    } finally {
        btn.disabled = false;
        btn.textContent = 'Активировать';
    }
}

// ─── Copy helpers ─────────────────────────────────────────────
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => showToast('Скопировано в буфер')).catch(() => {});
}

function copyItemName(name) {
    copyToClipboard(name);
}

function showToast(msg) {
    const toast = document.getElementById('copy-toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2200);
}

// ─── Admin Panel ─────────────────────────────────────────────
async function loadAdminUsers() {
    const content = document.getElementById('admin-users-content');
    if (!content) return;
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка...</p></div>';
    try {
        const res  = await fetch('/api/admin/users');
        const data = await res.json();
        if (!data.success) { content.innerHTML = `<div class="empty-state"><p>Ошибка: ${data.error}</p></div>`; return; }
        const countEl = document.getElementById('admin-users-count');
        if (countEl) countEl.textContent = `Всего: ${data.users.length} пользователей`;
        const planLabel = { free: 'Бесплатный', basic: 'Базовый', pro: 'Профи' };
        let html = `
            <div class="table-wrap">
            <table class="admin-table" style="min-width:900px">
                <thead><tr>
                    <th>Логин</th>
                    <th>Email</th>
                    <th>Статус</th>
                    <th>Тариф</th>
                    <th>Истекает</th>
                    <th>Сервер</th>
                    <th>Комиссия</th>
                    <th>Дата рег.</th>
                    <th>Действия</th>
                </tr></thead>
                <tbody>
        `;
        data.users.forEach(u => {
            const planCls   = u.plan === 'pro' ? 'plan-pro' : u.plan === 'basic' ? 'plan-basic' : 'plan-free';
            const expiry    = u.plan_expires ? u.plan_expires.split('T')[0] : (u.role === 'admin' ? '∞' : '—');
            const regDate   = u.reg_date ? u.reg_date.split('T')[0] : '—';
            const isBlocked = u.blocked;
            const isActive  = u.activated;
            const rowStyle  = isBlocked ? 'opacity:0.5' : '';
            const uJson     = encodeURIComponent(JSON.stringify(u));
            html += `
                <tr style="${rowStyle}">
                    <td>
                        <strong>${u.username}</strong>
                        ${u.role === 'admin' ? '<span class="admin-badge">admin</span>' : ''}
                    </td>
                    <td class="td-muted" style="font-size:11px">${u.email || '—'}</td>
                    <td>
                        <span class="plan-badge ${isBlocked ? '' : isActive ? 'plan-pro' : 'plan-free'}"
                              style="${isBlocked ? 'background:rgba(239,68,68,0.15);color:#F87171;border-color:rgba(239,68,68,0.3)' : ''}">
                            ${isBlocked ? '🔒 Заблокирован' : isActive ? '✓ Активен' : '⏸ Не активирован'}
                        </span>
                    </td>
                    <td><span class="plan-badge ${planCls}">${planLabel[u.plan] || u.plan}</span></td>
                    <td class="td-muted" style="font-size:11px">${expiry}</td>
                    <td class="td-muted" style="font-size:11px">#${u.user_server || 2}</td>
                    <td class="td-muted" style="font-size:11px">${u.commission || 9}%</td>
                    <td class="td-muted" style="font-size:11px">${regDate}</td>
                    <td>
                        <div style="display:flex;gap:4px;flex-wrap:wrap">
                            <button class="btn-copy-small" onclick='openEditUserModal(${JSON.stringify(u)})' title="Редактировать">✏️</button>
                            ${u.role !== 'admin' ? `
                            <button class="btn-copy-small" onclick="adminToggleActivate('${u.username}')"
                                style="${isActive ? 'color:var(--amber)' : 'color:var(--green-light)'}"
                                title="${isActive ? 'Деактивировать' : 'Активировать'}">
                                ${isActive ? '⏸' : '▶'}
                            </button>
                            <button class="btn-copy-small" onclick="adminToggleBlock('${u.username}')"
                                style="${isBlocked ? 'color:var(--green-light)' : 'color:var(--red,#F87171)'}"
                                title="${isBlocked ? 'Разблокировать' : 'Заблокировать'}">
                                ${isBlocked ? '🔓' : '🔒'}
                            </button>
                            <button class="btn-copy-small" onclick="adminDeleteUser('${u.username}')"
                                style="color:var(--red,#F87171)" title="Удалить">✕</button>
                            ` : ''}
                        </div>
                    </td>
                </tr>
            `;
        });
        html += '</tbody></table></div>';
        content.innerHTML = html;
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

function openEditUserModal(u) {
    document.getElementById('edit-user-orig').value      = u.username;
    document.getElementById('edit-user-email').value     = u.email || '';
    document.getElementById('edit-user-password').value  = '';
    document.getElementById('edit-user-role').value      = u.role || 'user';
    document.getElementById('edit-user-plan').value      = u.plan_raw || u.plan || 'free';
    document.getElementById('edit-user-days').value      = u.days_left || 30;
    document.getElementById('edit-user-commission').value = u.commission || 9;
    document.getElementById('edit-user-server').value    = u.user_server || 2;
    document.getElementById('editUserModal').classList.add('open');
}

function closeEditUserModal() {
    document.getElementById('editUserModal').classList.remove('open');
}

async function saveEditUser() {
    const username   = document.getElementById('edit-user-orig').value;
    const email      = document.getElementById('edit-user-email').value.trim();
    const password   = document.getElementById('edit-user-password').value.trim();
    const role       = document.getElementById('edit-user-role').value;
    const plan       = document.getElementById('edit-user-plan').value;
    const days       = parseInt(document.getElementById('edit-user-days').value) || 30;
    const commission = parseFloat(document.getElementById('edit-user-commission').value) || 9;
    const userServer = parseInt(document.getElementById('edit-user-server').value) || 2;
    const payload    = { username, email, role, plan, days, commission, user_server: userServer };
    if (password) payload.password = password;
    try {
        const res  = await fetch('/api/admin/users/edit', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) {
            showToast(`Пользователь ${username} обновлён`);
            closeEditUserModal();
            loadAdminUsers();
        } else {
            showToast(data.error || 'Ошибка сохранения');
        }
    } catch(e) { showToast('Ошибка соединения'); }
}

async function adminToggleActivate(username) {
    try {
        const res  = await fetch('/api/admin/users/activate', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`${username}: ${data.activated ? 'активирован' : 'деактивирован'}`);
            loadAdminUsers();
        } else { showToast(data.error || 'Ошибка'); }
    } catch(e) { showToast('Ошибка соединения'); }
}

async function adminToggleBlock(username) {
    try {
        const res  = await fetch('/api/admin/users/block', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`${username}: ${data.blocked ? 'заблокирован' : 'разблокирован'}`);
            loadAdminUsers();
        } else { showToast(data.error || 'Ошибка'); }
    } catch(e) { showToast('Ошибка соединения'); }
}

async function adminDeleteUser(username) {
    if (!confirm(`Удалить пользователя "${username}"? Это действие необратимо.`)) return;
    try {
        const res  = await fetch('/api/admin/users/delete', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`Пользователь ${username} удалён`);
            loadAdminUsers();
        } else { showToast(data.error || 'Ошибка'); }
    } catch(e) { showToast('Ошибка соединения'); }
}

function openGrantModal(username) {
    const plan = prompt(`Тариф для ${username} (free/basic/pro):`, 'pro');
    if (!plan || !['free','basic','pro'].includes(plan)) return;
    const days = plan === 'free' ? 0 : parseInt(prompt('Количество дней:', '30'));
    if (plan !== 'free' && isNaN(days)) return;
    fetch('/api/admin/grant_plan', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ username, plan, days: days || 30 })
    }).then(r => r.json()).then(d => {
        if (d.success) { showToast(`Тариф выдан: ${username} → ${plan}`); loadAdminUsers(); }
        else showToast(d.error || 'Ошибка');
    });
}

async function loadAdminCodes() {
    const content = document.getElementById('admin-codes-content');
    if (!content) return;
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка...</p></div>';
    try {
        const res  = await fetch('/api/admin/codes');
        const data = await res.json();
        if (!data.success) { content.innerHTML = `<div class="empty-state"><p>Ошибка: ${data.error}</p></div>`; return; }
        if (!data.codes.length) { content.innerHTML = '<div class="empty-state"><p>Нет активных кодов</p></div>'; return; }
        const planLabel = { free: 'Бесплатный', basic: 'Базовый', pro: 'Профи' };
        let html = `
            <table class="admin-table">
                <thead><tr><th>Код</th><th>Тариф</th><th>Дней</th><th></th></tr></thead>
                <tbody>
        `;
        data.codes.forEach(c => {
            const planCls = c.plan === 'pro' ? 'plan-pro' : c.plan === 'basic' ? 'plan-basic' : 'plan-free';
            html += `
                <tr>
                    <td><code style="font-size:13px;letter-spacing:1px">${c.code}</code>
                        <button class="btn-copy-small" onclick="copyToClipboard('${c.code}')" style="margin-left:6px">Копировать</button>
                    </td>
                    <td><span class="plan-badge ${planCls}">${planLabel[c.plan] || c.plan}</span></td>
                    <td>${c.duration_days} дней</td>
                    <td><button class="btn-copy-small" style="color:var(--red)" onclick="deleteCode('${c.code}')">✕ Удалить</button></td>
                </tr>
            `;
        });
        html += '</tbody></table>';
        content.innerHTML = html;
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

async function generateCode() {
    const plan = document.getElementById('gen-plan-select')?.value || 'basic';
    const days = parseInt(document.getElementById('gen-days-select')?.value) || 30;
    try {
        const res  = await fetch('/api/admin/codes/generate', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ plan, duration_days: days })
        });
        const data = await res.json();
        if (data.success) {
            const el = document.getElementById('gen-code-result');
            if (el) el.textContent = data.code;
            copyToClipboard(data.code);
            loadAdminCodes();
        }
    } catch(e) {}
}

async function deleteCode(code) {
    if (!confirm(`Удалить код ${code}?`)) return;
    await fetch('/api/admin/codes/delete', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ code })
    });
    loadAdminCodes();
}

async function loadAdminLog() {
    const content = document.getElementById('admin-log-content');
    if (!content) return;
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка...</p></div>';
    try {
        const res  = await fetch('/api/admin/log');
        const data = await res.json();
        if (!data.success) { content.innerHTML = `<div class="empty-state"><p>Ошибка: ${data.error}</p></div>`; return; }
        if (!data.log.length) { content.innerHTML = '<div class="empty-state"><p>Журнал пуст</p></div>'; return; }
        let html = `
            <table class="admin-table">
                <thead><tr><th>Время</th><th>Пользователь</th><th>Действие</th><th>Подробности</th><th>IP</th></tr></thead>
                <tbody>
        `;
        data.log.forEach(e => {
            html += `
                <tr>
                    <td class="td-muted" style="white-space:nowrap;font-size:12px">${e.time}</td>
                    <td><strong>${e.username}</strong></td>
                    <td><span class="log-action">${e.action}</span></td>
                    <td class="td-muted" style="font-size:12px">${e.details || '—'}</td>
                    <td class="td-muted" style="font-size:12px">${e.ip || '—'}</td>
                </tr>
            `;
        });
        html += '</tbody></table>';
        content.innerHTML = html;
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

// ─── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    initLoader();
    initCanvas();
    loadUserServer();
    loadCommission();

    await Promise.all([loadCurrencyRates(), loadUserInfo()]);
    buildMarketServerSelect();

    document.getElementById('inventoryModal').addEventListener('click', function(e) {
        if (e.target === this) closeInventoryModal();
    });
    document.getElementById('avtoAddModal').addEventListener('click', function(e) {
        if (e.target === this) closeAvtoAddModal();
    });
    document.getElementById('addItemModal').addEventListener('click', function(e) {
        if (e.target === this) closeAddItemModal();
    });
    document.getElementById('itemDetailsModal').addEventListener('click', function(e) {
        if (e.target === this) closeItemDetailsModal();
    });

    async function pollStatus() {
        try {
            const res    = await fetch('/api/auto_status');
            const status = await res.json();

            const scanBtn = document.getElementById('auto-scanner-btn');
            const scanDot = document.getElementById('dot-scanner');
            if (status.scanner_running) {
                scanBtn.classList.add('active');
                scanBtn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
                scanDot.classList.add('on');
            }

            const arbBtn = document.getElementById('auto-arbitrage-btn');
            const arbDot = document.getElementById('dot-arbitrage');
            if (status.arbitrage_running) {
                arbBtn.classList.add('active');
                arbBtn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
                arbDot.classList.add('on');
            }
        } catch(e) {}
    }

    setInterval(pollStatus, 5000);

    setInterval(() => {
        if (document.getElementById('scanner').classList.contains('active')) loadScanner();
    }, 30000);

    setInterval(() => {
        const arbBtn = document.getElementById('auto-arbitrage-btn');
        if (arbBtn.classList.contains('active') && document.getElementById('arbitrage').classList.contains('active')) {
            loadArbitrage();
        }
    }, 10000);

    document.getElementById('auto-scanner-btn').onclick   = toggleAutoScanner;
    document.getElementById('auto-arbitrage-btn').onclick = toggleAutoArbitrage;

    loadArbFilters();
    loadScanner();

    const balanceInput = document.getElementById('balance-amount-input');
    if (balanceInput) balanceInput.addEventListener('keydown', e => { if (e.key === 'Enter') addBalanceRecord(); });
    const noteInput = document.getElementById('balance-note-input');
    if (noteInput) noteInput.addEventListener('keydown', e => { if (e.key === 'Enter') addBalanceRecord(); });

    const itemSearchInput = document.getElementById('itemSearchInput');
    if (itemSearchInput) itemSearchInput.addEventListener('input', searchItems);
});


/* ═══════════════════════════════════════════════════════════
   ARIZONA MAP v3
   - Live XYZ tiles from pc.rod-ins.com
   - Markers placed outside tile layer → fixed size on zoom
   - Icon markers: business_0/1, house_0/2
   ═══════════════════════════════════════════════════════════ */
(function () {
    const WORLD_MIN = -3000, WORLD_MAX = 3000, WORLD_SIZE = 6000;
    const TILE_SIZE = 256;
    const MAX_TILE_ZOOM = 5;
    const MAX_TILE_GRID = 24;
    const MAP_PIXEL_SIZE = TILE_SIZE * MAX_TILE_GRID;
    const TILE_URL_DARK  = 'https://pc.rod-ins.com/resource/web/arizona/map_dark/{z}/{x}/{y}.png';
    const TILE_URL_LIGHT = 'https://pc.rod-ins.com/resource/web/arizona/map/{z}/{x}/{y}.png';

    const ICONS = {
        'house-owned':   '/static/marker_house_0.png',
        'house-auction': '/static/marker_house_2.png',
        'house-free':    null, // green dot fallback
        'businesses':    '/static/marker_business_0.png',
        'biz-free':      '/static/marker_business_1.png',
    };

    let _azFilter = 'all';
    let _azData   = null;
    let _markers  = [];   // [{el, wx, wy}] world pixel coords (0..IMG_SIZE)
    let _tiles = new Map();       // key → <img>
    let _baseTiles = new Map();   // key → <img>  low-zoom base layer (always kept)
    let scale = 1, tx = 0, ty = 0;
    let _mapReady = false;
    let _lastContainerSize = '';
    let _tileCleanupTimer = null;
    let _preloadTimer = null;
    let _activeZ = -1;            // zoom level that is currently fully shown
    let _categoryCounts = {};
    let _markerHoverSuspended = false;
    let _tooltipFrame = null;
    let _tooltipX = 0;
    let _tooltipY = 0;
    const BASE_ZOOM = 2;          // always-visible base layer zoom (9 tiles only)

    // ── Moscow time helpers ────────────────────────────────────
    function getMoscowHour() {
        const now = new Date();
        const msk = new Date(now.toLocaleString('en-US', { timeZone: 'Europe/Moscow' }));
        return msk.getHours();
    }

    function isDarkByTime() {
        const h = getMoscowHour();
        return h >= 20 || h < 6;
    }

    function resolveMapTheme() {
        return 'dark';
    }

    function tileGridSize(z) {
        return Math.ceil(MAX_TILE_GRID / Math.pow(2, MAX_TILE_ZOOM - z));
    }

    function tileUrl(z, x, y) {
        const url = resolveMapTheme() === 'dark' ? TILE_URL_DARK : TILE_URL_LIGHT;
        return url.replace('{z}', z).replace('{x}', x).replace('{y}', y);
    }

    function chooseTileZoom() {
        const z = Math.round(MAX_TILE_ZOOM + Math.log2(Math.max(scale, 0.001)));
        return Math.max(0, Math.min(MAX_TILE_ZOOM, z));
    }

    function applyMapImage() {
        renderVisibleTiles();
    }

    window.setMapTheme = function (theme) {
        localStorage.setItem('azMapTheme', theme);
        document.querySelectorAll('.az-theme-btn').forEach(b => {
            b.classList.toggle('active', b.getAttribute('data-theme') === theme);
        });
        const hint = document.getElementById('az-theme-hint');
        if (hint) {
            hint.textContent = theme === 'dark' ? 'Тёмная карта · ночной режим' : 'Светлая карта · дневной режим';
        }
        // Clear tile cache and reload with new theme
        const layer = document.getElementById('az-map-tile-layer');
        if (layer) layer.innerHTML = '';
        _tiles.clear();
        _baseTiles.clear();
        _activeZ = -1;
        loadBaseTiles();
        applyTransform();
    };

    function initThemeButtons() {
        // Always dark — nothing to toggle
        const hint = document.getElementById('az-theme-hint');
        if (hint) hint.textContent = 'Тёмная карта · всегда активна';
    }

    // ── Coord conversion ───────────────────────────────────────
    function worldToPixel(lx, ly) {
        const px = ((lx - WORLD_MIN) / WORLD_SIZE) * MAP_PIXEL_SIZE;
        const py = ((WORLD_MAX - ly) / WORLD_SIZE) * MAP_PIXEL_SIZE;
        return { px, py };
    }

    function getMapRect() {
        const container = document.getElementById('az-map-container');
        if (!container) return null;
        const rect = container.getBoundingClientRect();
        if (!rect.width || !rect.height) return null;
        return rect;
    }

    function getMinScale() {
        const rect = getMapRect();
        if (!rect) return 0.08;
        return Math.max(rect.width / MAP_PIXEL_SIZE, rect.height / MAP_PIXEL_SIZE);
    }

    function clampView() {
        const rect = getMapRect();
        if (!rect) return;
        const minScale = getMinScale();
        scale = Math.max(minScale, Math.min(4, scale));
        const mapW = MAP_PIXEL_SIZE * scale;
        const mapH = MAP_PIXEL_SIZE * scale;
        tx = mapW <= rect.width ? (rect.width - mapW) / 2 : Math.min(0, Math.max(rect.width - mapW, tx));
        ty = mapH <= rect.height ? (rect.height - mapH) / 2 : Math.min(0, Math.max(rect.height - mapH, ty));
    }

    function centerMap() {
        const rect = getMapRect();
        if (!rect) return false;
        scale = getMinScale();
        tx = (rect.width - MAP_PIXEL_SIZE * scale) / 2;
        ty = (rect.height - MAP_PIXEL_SIZE * scale) / 2;
        _lastContainerSize = `${Math.round(rect.width)}x${Math.round(rect.height)}`;
        clampView();
        return true;
    }

    // ── Base layer: always-visible low-zoom tiles covering entire map ──
    function loadBaseTiles() {
        const layer = document.getElementById('az-map-tile-layer');
        if (!layer) return;
        const grid = tileGridSize(BASE_ZOOM);
        const tileWorldSize = MAP_PIXEL_SIZE / grid;
        for (let y = 0; y < grid; y++) {
            for (let x = 0; x < grid; x++) {
                const key = `base:${BASE_ZOOM}:${x}:${y}`;
                if (_baseTiles.has(key)) continue;
                const img = document.createElement('img');
                img.className = 'az-map-tile loaded'; // skip fade — show instantly when cached
                img.draggable = false;
                img.decoding = 'async';
                img.src = tileUrl(BASE_ZOOM, x, y);
                img.style.left   = (x * tileWorldSize - 1) + 'px';
                img.style.top    = (y * tileWorldSize - 1) + 'px';
                img.style.width  = (tileWorldSize + 2) + 'px';
                img.style.height = (tileWorldSize + 2) + 'px';
                img.style.zIndex = '1'; // always at bottom
                img.style.transition = 'none';
                img.onload = () => { img.classList.add('loaded'); img.style.opacity = '1'; };
                img.onerror = () => {};
                layer.appendChild(img);
                _baseTiles.set(key, img);
            }
        }
    }

    // ── Preload tiles for a given zoom level silently ──────────
    function preloadZoomTiles(z) {
        const container = document.getElementById('az-map-container');
        if (!container) return;
        const rect = container.getBoundingClientRect();
        if (!rect.width || !rect.height) return;
        const grid = tileGridSize(z);
        const tileWorldSize = MAP_PIXEL_SIZE / grid;
        const pad = tileWorldSize * 1.5;
        const left   = Math.max(0, (-tx / scale) - pad);
        const top2   = Math.max(0, (-ty / scale) - pad);
        const right  = Math.min(MAP_PIXEL_SIZE, ((rect.width  - tx) / scale) + pad);
        const bottom = Math.min(MAP_PIXEL_SIZE, ((rect.height - ty) / scale) + pad);
        const minX = Math.max(0, Math.floor(left  / tileWorldSize));
        const maxX = Math.min(grid - 1, Math.floor(right  / tileWorldSize));
        const minY = Math.max(0, Math.floor(top2   / tileWorldSize));
        const maxY = Math.min(grid - 1, Math.floor(bottom / tileWorldSize));
        for (let y = minY; y <= maxY; y++) {
            for (let x = minX; x <= maxX; x++) {
                const key = `${z}:${x}:${y}`;
                if (_tiles.has(key)) continue;
                // Use a hidden img to warm browser cache only
                const img = new Image();
                img.src = tileUrl(z, x, y);
            }
        }
    }

    // ── Global sweep: remove stale tiles once current zoom is ready ─
    function checkAndSweep(targetZ, visible) {
        if (targetZ !== _activeZ) return; // zoom changed, skip
        // Check all visible tiles at targetZ are loaded
        for (const key of visible) {
            const img = _tiles.get(key);
            if (!img || !img.classList.contains('loaded')) return; // not ready yet
        }
        // All loaded — remove tiles at other zoom levels
        for (const [key, img] of [..._tiles.entries()]) {
            const tileZ = parseInt(key.split(':')[0], 10);
            if (tileZ !== targetZ || !visible.has(key)) {
                img.remove();
                _tiles.delete(key);
            }
        }
        // Schedule preload of adjacent zoom levels
        clearTimeout(_preloadTimer);
        _preloadTimer = setTimeout(() => {
            if (targetZ > 0)            preloadZoomTiles(targetZ - 1);
            if (targetZ < MAX_TILE_ZOOM) preloadZoomTiles(targetZ + 1);
        }, 600);
    }

    function renderVisibleTiles() {
        const container = document.getElementById('az-map-container');
        const layer = document.getElementById('az-map-tile-layer');
        if (!container || !layer) return;
        const rect = container.getBoundingClientRect();
        if (!rect.width || !rect.height) return;

        const z = chooseTileZoom();
        const grid = tileGridSize(z);
        const tileWorldSize = MAP_PIXEL_SIZE / grid;
        const pad = tileWorldSize; // one extra tile on each edge
        const left   = Math.max(0, (-tx / scale) - pad);
        const top2   = Math.max(0, (-ty / scale) - pad);
        const right  = Math.min(MAP_PIXEL_SIZE, ((rect.width  - tx) / scale) + pad);
        const bottom = Math.min(MAP_PIXEL_SIZE, ((rect.height - ty) / scale) + pad);

        const minX = Math.max(0, Math.floor(left  / tileWorldSize));
        const maxX = Math.min(grid - 1, Math.floor(right  / tileWorldSize));
        const minY = Math.max(0, Math.floor(top2   / tileWorldSize));
        const maxY = Math.min(grid - 1, Math.floor(bottom / tileWorldSize));

        // When zoom level changes: lift old tiles to top so they stay visible
        // (base layer underneath always covers black areas)
        if (z !== _activeZ) {
            _activeZ = z;
            for (const [key, img] of _tiles.entries()) {
                const tileZ = parseInt(key.split(':')[0], 10);
                if (tileZ !== z) {
                    img.style.zIndex = '15'; // above base (1), below new tiles later
                    img.style.transition = 'none';
                }
            }
        }

        const visible = new Set();

        for (let y = minY; y <= maxY; y++) {
            for (let x = minX; x <= maxX; x++) {
                const key = `${z}:${x}:${y}`;
                visible.add(key);
                if (_tiles.has(key)) continue;

                const img = document.createElement('img');
                img.className = 'az-map-tile';
                img.draggable = false;
                img.decoding = 'async';
                img.src = tileUrl(z, x, y);
                img.style.left   = (x * tileWorldSize - 1) + 'px';
                img.style.top    = (y * tileWorldSize - 1) + 'px';
                img.style.width  = (tileWorldSize + 2) + 'px';
                img.style.height = (tileWorldSize + 2) + 'px';
                img.style.zIndex = '20'; // new tiles on top of stale

                img.onload = () => {
                    img.classList.add('loaded');
                    checkAndSweep(z, visible);
                };
                img.onerror = () => { img.remove(); _tiles.delete(key); };
                layer.appendChild(img);
                _tiles.set(key, img);
            }
        }

        // If all tiles already in cache, sweep immediately
        checkAndSweep(z, visible);

        // Force cleanup after 3s regardless (network timeout fallback)
        clearTimeout(_tileCleanupTimer);
        _tileCleanupTimer = setTimeout(() => {
            const curZ = chooseTileZoom();
            for (const [key, img] of [..._tiles.entries()]) {
                const tileZ = parseInt(key.split(':')[0], 10);
                if (tileZ !== curZ) { img.remove(); _tiles.delete(key); }
            }
        }, 3000);
    }

    // ── Marker position update (called after every pan/zoom) ───
    function updateMarkerPositions() {
        for (const m of _markers) {
            const cx = tx + m.px * scale;
            const cy = ty + m.py * scale;
            m.el.style.left = cx + 'px';
            m.el.style.top  = cy + 'px';
        }
    }

    // ── Apply CSS transform to inner map ───────────────────────
    function applyTransform() {
        clampView();
        const inner = document.getElementById('az-map-inner');
        if (inner) inner.style.transform = `translate(${tx}px,${ty}px) scale(${scale})`;
        renderVisibleTiles();
        updateMarkerPositions();
    }

    function hideArizonaTooltip() {
        if (_tooltipFrame) { cancelAnimationFrame(_tooltipFrame); _tooltipFrame = null; }
        const tooltip = document.getElementById('az-map-tooltip');
        if (tooltip) tooltip.className = 'az-map-tooltip';
    }

    function setMarkerHoverSuspended(suspended) {
        _markerHoverSuspended = suspended;
        const container = document.getElementById('az-map-container');
        if (container) container.classList.toggle('az-map-interacting', suspended);
        if (suspended) hideArizonaTooltip();
    }

    function moveArizonaTooltip(e) {
        const tooltip = document.getElementById('az-map-tooltip');
        if (!tooltip || _markerHoverSuspended) return;
        const TW = 220;   // max-width
        const GAP = 16;   // gap from cursor

        // Horizontal: prefer right of cursor, flip left if near edge
        if (e.clientX + GAP + TW > window.innerWidth) {
            _tooltipX = e.clientX - GAP - TW;
        } else {
            _tooltipX = e.clientX + GAP;
        }

        // Vertical: prefer below cursor (below marker icon), flip above if near bottom
        const TH = tooltip.offsetHeight || 90;
        if (e.clientY + GAP + TH > window.innerHeight) {
            _tooltipY = e.clientY - GAP - TH;
        } else {
            _tooltipY = e.clientY + GAP;
        }

        if (_tooltipFrame) return;
        _tooltipFrame = requestAnimationFrame(() => {
            tooltip.style.left = _tooltipX + 'px';
            tooltip.style.top  = _tooltipY + 'px';
            _tooltipFrame = null;
        });
    }

    // ── Marker category helpers ────────────────────────────────
    function getCategory(topKey, hasOwner, hasAuction) {
        if (topKey === 'businesses') return hasOwner ? 'businesses' : 'biz-free';
        if (hasAuction)             return 'house-auction';
        if (hasOwner)               return 'house-owned';
        return 'house-free';
    }

    // ── Render all markers ─────────────────────────────────────
    function renderArizonaMarkers(data) {
        const layer   = document.getElementById('az-markers-layer');
        const tooltip = document.getElementById('az-map-tooltip');
        if (!layer) return;
        layer.innerHTML = '';
        _markers = [];
        _categoryCounts = {
            'house-owned': 0,
            'house-free': 0,
            'house-auction': 0,
            'businesses': 0,
            'biz-free': 0,
        };

        const addMarkers = (items, topKey) => {
            if (!Array.isArray(items)) return;
            items.forEach(item => {
                if (item.lx == null || item.ly == null) return;
                const { px, py } = worldToPixel(item.lx, item.ly);
                const hasOwner   = !!item.owner;
                const hasAuction = !!item.hasAuction;
                const cat        = getCategory(topKey, hasOwner, hasAuction);
                const iconSrc    = ICONS[cat];
                if (_categoryCounts[cat] !== undefined) _categoryCounts[cat]++;

                const el = document.createElement('div');
                el.className = 'az-marker';
                el.setAttribute('data-filter', cat);
                if (_azFilter !== 'all' && _azFilter !== cat) el.classList.add('hidden');

                if (iconSrc) {
                    const img = document.createElement('img');
                    img.src = iconSrc;
                    img.className = 'az-marker-icon';
                    img.draggable = false;
                    el.appendChild(img);
                } else {
                    // Free house — small green dot
                    el.classList.add('az-marker-dot');
                }

                const catLabels = {
                    'house-owned':   ['#ef4444', 'Занят'],
                    'house-free':    ['#22c55e', 'Свободен'],
                    'house-auction': ['#f59e0b', 'Аукцион'],
                    'businesses':    ['#ef4444', 'Бизнес (занят)'],
                    'biz-free':      ['#22c55e', 'Бизнес (свободен)'],
                };
                const [clr, lbl] = catLabels[cat] || ['#888', '—'];
                const tooltipHtml = `
                    <div class="az-tooltip-name">${item.name || 'Без названия'}</div>
                    ${item.owner ? `<div class="az-tooltip-owner">👤 ${item.owner}</div>` : ''}
                    ${hasAuction && item.auMinBet ? `<div class="az-tooltip-owner">💰 Мин. ставка: ${item.auMinBet.toLocaleString()}</div>` : ''}
                    <span class="az-tooltip-tag" style="background:${clr}22;color:${clr};border:1px solid ${clr}44">${lbl}</span>
                    <div class="az-tooltip-owner" style="margin-top:3px;font-size:10px;opacity:0.6">ID:${item.id} · X:${Math.round(item.lx)} Y:${Math.round(item.ly)}</div>
                `;

                // Tooltip
                el.addEventListener('mouseenter', e => {
                    if (_markerHoverSuspended) return;
                    tooltip.className = 'az-map-tooltip visible';
                    tooltip.innerHTML = tooltipHtml;
                    moveArizonaTooltip(e);
                });
                el.addEventListener('mousemove', moveArizonaTooltip);
                el.addEventListener('mouseleave', hideArizonaTooltip);

                // Click → detailed popup
                el.addEventListener('click', e => {
                    e.stopPropagation();
                    tooltip.className = 'az-map-tooltip';
                    openAzObjModal(item, cat, topKey);
                });

                layer.appendChild(el);
                _markers.push({ el, px, py });
            });
        };

        const walk = (obj, topKey) => {
            if (Array.isArray(obj)) { addMarkers(obj, topKey); return; }
            if (typeof obj === 'object' && obj !== null) {
                Object.entries(obj).forEach(([k, v]) => {
                    const nextKey = (k === 'businesses' || k === 'stateSeason') ? 'businesses' : topKey;
                    walk(v, nextKey);
                });
            }
        };
        walk(data, 'houses');
        updateMarkerPositions();
        updateLegendCounts();
    }

    // ── Count helpers ──────────────────────────────────────────
    function countAllMarkers(data) {
        let n = 0;
        const c = (o) => { if (Array.isArray(o)) { n += o.length; return; } if (typeof o === 'object' && o) Object.values(o).forEach(c); };
        c(data);
        return n;
    }

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    function updateLegendCounts() {
        setText('az-count-house-owned', _categoryCounts['house-owned'] ?? 0);
        setText('az-count-house-free', _categoryCounts['house-free'] ?? 0);
        setText('az-count-house-auction', _categoryCounts['house-auction'] ?? 0);
        setText('az-count-businesses', _categoryCounts['businesses'] ?? 0);
        setText('az-count-biz-free', _categoryCounts['biz-free'] ?? 0);
    }

    function resetLegendCounts() {
        ['az-count-house-owned', 'az-count-house-free', 'az-count-house-auction', 'az-count-businesses', 'az-count-biz-free']
            .forEach(id => setText(id, '—'));
    }

    function setLegendStatus(text) {
        setText('az-legend-status', text);
    }

    function setMapLoading(show, text = '') {
        // Loading animation removed — map loads instantly without overlay
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function fetchArizonaObjects(serverId) {
        const attempts = [
            `/api/arizona_map/${serverId}`,
            `https://n-api.arizona-rp.com/api/map/${serverId}`,
        ];
        let lastError = null;
        for (const url of attempts) {
            try {
                const ctrl  = new AbortController();
                const timer = setTimeout(() => ctrl.abort(), url.startsWith('/api/') ? 38000 : 14000);
                const resp  = await fetch(url, { signal: ctrl.signal, mode: 'cors' });
                clearTimeout(timer);
                if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
                const data = await resp.json();
                if (data && data.error) throw new Error(data.error);
                return data;
            } catch (e) {
                lastError = e;
            }
        }
        throw lastError || new Error('objects unavailable');
    }

    // ── Show / hide states ─────────────────────────────────────
    function showMapSuccess(total) {
        setMapLoading(false);
        document.getElementById('az-paste-fallback')?.style && (document.getElementById('az-paste-fallback').style.display = 'none');
        const inner = document.getElementById('az-map-inner');
        if (inner) inner.style.display = 'block';
        const stats = document.getElementById('az-map-stats');
        if (stats) stats.textContent = `${total} объектов`;
        setLegendStatus(`${total} объектов загружено автоматически`);
    }

    function showMapFallback(serverId) {
        setMapLoading(false);
        const fb = document.getElementById('az-paste-fallback');
        if (fb) fb.style.display = 'none';
        const link = document.getElementById('az-paste-link');
        if (link) { const u = `https://n-api.arizona-rp.com/api/map/${serverId}`; link.href = u; link.textContent = u; }
        const inner = document.getElementById('az-map-inner');
        if (inner) inner.style.display = 'block';
        const stats = document.getElementById('az-map-stats');
        if (stats) stats.textContent = 'Карта загружена · объекты недоступны';
        setLegendStatus('Карта загружена, API объектов пока не отвечает');
        resetLegendCounts();
    }

    // ── Load from API ──────────────────────────────────────────
    window.loadArizonaMap = async function () {
        const serverId = document.getElementById('az-server-select')?.value || 5;
        const fb       = document.getElementById('az-paste-fallback');
        const inner    = document.getElementById('az-map-inner');

        setMapLoading(true, 'Загрузка карты');
        if (fb)    fb.style.display    = 'none';
        if (inner) inner.style.display = 'block';
        resetLegendCounts();
        setLegendStatus('Подгружаем тайлы и объекты сервера');

        const rect = getMapRect();
        const size = rect ? `${Math.round(rect.width)}x${Math.round(rect.height)}` : '';
        if (!_mapReady || size !== _lastContainerSize) _mapReady = centerMap();
        applyTransform();
        const stats = document.getElementById('az-map-stats');
        if (stats) stats.textContent = 'Загрузка объектов...';

        try {
            _azData = await fetchArizonaObjects(serverId);
            renderArizonaMarkers(_azData);
            showMapSuccess(countAllMarkers(_azData));
        } catch (e) {
            showMapFallback(serverId);
        }
    };

    // ── Load from paste ────────────────────────────────────────
    window.loadArizonaMapFromPaste = function () {
        const ta = document.getElementById('az-paste-area');
        if (!ta || !ta.value.trim()) return;
        try {
            _azData = JSON.parse(ta.value.trim());
            renderArizonaMarkers(_azData);
            showMapSuccess(countAllMarkers(_azData));
            applyMapImage();
        } catch (e) {
            ta.style.borderColor = '#ef4444';
            ta.placeholder = 'Ошибка: неверный JSON. Попробуй ещё раз.';
            setTimeout(() => { ta.style.borderColor = ''; }, 2000);
        }
    };

    // ── Map object popup modal ─────────────────────────────────
    let _auctionTimer    = null;
    let _currentGpsCmd   = '';
    let _currentPhotoKey = '';

    function row(label, value, valueClass = '') {
        return `<div class="az-obj-row">
            <span class="az-obj-row-label">${label}</span>
            <span class="az-obj-row-value ${valueClass}">${value}</span>
        </div>`;
    }

    function formatCountdown(endDateStr) {
        if (!endDateStr) return null;
        const end = new Date(endDateStr).getTime();
        if (isNaN(end)) return null;
        const diff = end - Date.now();
        if (diff <= 0) return 'Завершён';
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    }

    window.openAzObjModal = function (item, cat, topKey) {
        const modal = document.getElementById('azObjModal');
        if (!modal) return;

        const isBiz   = cat === 'businesses' || cat === 'biz-free';
        const isHouse = !isBiz;
        const hasAuction = !!item.hasAuction;

        // Photo key: "house_123" or "biz_456"
        _currentPhotoKey = (isBiz ? 'biz' : 'house') + '_' + item.id;

        // Title & subtitle
        const catLabels = {
            'house-owned':   ['🏠 Дом', '#ef4444'],
            'house-free':    ['🏠 Дом', '#22c55e'],
            'house-auction': ['🏠 Дом на аукционе', '#f59e0b'],
            'businesses':    ['🏢 Бизнес', '#ef4444'],
            'biz-free':      ['🏢 Бизнес', '#22c55e'],
        };
        const [typeLabel, typeColor] = catLabels[cat] || ['Объект', '#888'];
        document.getElementById('azObjModalTitle').textContent = item.name || typeLabel;
        document.getElementById('azObjModalSub').textContent = typeLabel;
        document.getElementById('azObjModalSub').style.color = typeColor;

        // Info rows (ID + Owner only, no coords)
        const rows = [
            row('ID', item.id ?? '—'),
            row('Владелец', item.owner ? item.owner : '<span style="opacity:0.5">Нет</span>', 'owner'),
        ];
        document.getElementById('azObjRows').innerHTML = rows.join('');

        // Auction countdown + bets
        const auctionEl = document.getElementById('azObjAuction');
        const countdownEl = document.getElementById('azObjCountdown');
        const auctionRowsEl = document.getElementById('azObjAuctionRows');
        clearInterval(_auctionTimer);
        if (hasAuction && (item.auEndDate || item.auctionEndDate || item.auEnd)) {
            const endField = item.auEndDate || item.auctionEndDate || item.auEnd;
            auctionEl.style.display = 'flex';
            const tick = () => {
                const t = formatCountdown(endField);
                if (countdownEl) countdownEl.textContent = t || '—';
            };
            tick();
            _auctionTimer = setInterval(tick, 1000);
            // Auction bet rows
            const auctionRows = [];
            if (item.auMinBet) auctionRows.push(row('Мин. ставка', item.auMinBet.toLocaleString() + ' ₽'));
            if (item.auCurBet) auctionRows.push(row('Текущая ставка', item.auCurBet.toLocaleString() + ' ₽'));
            if (auctionRowsEl) auctionRowsEl.innerHTML = auctionRows.join('');
        } else {
            auctionEl.style.display = 'none';
            if (auctionRowsEl) auctionRowsEl.innerHTML = '';
        }

        // Photo
        _loadAzObjPhoto(_currentPhotoKey);

        // GPS command
        _currentGpsCmd = isBiz
            ? `/findibiz ${item.id}`
            : `/findihouse ${item.id}`;
        const copyBtn = document.getElementById('azObjCopyBtn');
        if (copyBtn) {
            copyBtn.textContent = '';
            copyBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 20 20" fill="none"><rect x="7" y="7" width="10" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M3 13V3h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> ${_currentGpsCmd}`;
            copyBtn.classList.remove('copied');
        }

        modal.classList.add('open');
    };

    function _setPhotoUI(url) {
        const img     = document.getElementById('azObjPhoto');
        const empty   = document.getElementById('azObjPhotoEmpty');
        const wrap    = document.getElementById('azObjPhotoWrap');
        const overlay = document.getElementById('azObjPhotoOverlay');
        const emptyLabel = document.getElementById('azObjPhotoEmptyLabel');
        if (!img) return;

        if (url) {
            img.src = url + '?t=' + Date.now();
            img.style.display = 'block';
            if (empty) empty.style.display = 'none';
            if (overlay) overlay.style.display = window.IS_ADMIN ? 'flex' : 'none';
            if (wrap) {
                wrap.classList.remove('admin-no-photo');
                if (window.IS_ADMIN) wrap.classList.add('admin-has-photo');
                wrap.style.cursor = window.IS_ADMIN ? '' : 'default';
            }
        } else {
            img.src = '';
            img.style.display = 'none';
            if (empty) empty.style.display = 'flex';
            if (overlay) overlay.style.display = 'none';
            if (wrap) {
                wrap.classList.remove('admin-has-photo');
                if (window.IS_ADMIN) {
                    wrap.classList.add('admin-no-photo');
                    if (emptyLabel) emptyLabel.textContent = 'Нажмите, чтобы добавить фото';
                } else {
                    if (emptyLabel) emptyLabel.textContent = 'Фото не добавлено';
                }
                wrap.style.cursor = '';
            }
        }
    }

    window.azPhotoWrapClick = function () {
        if (!window.IS_ADMIN) return;
        const wrap = document.getElementById('azObjPhotoWrap');
        if (wrap && wrap.classList.contains('admin-no-photo')) {
            document.getElementById('azObjPhotoInput').click();
        }
    };

    function _loadAzObjPhoto(key) {
        _setPhotoUI(null);
        if (!key) return;
        fetch(`/api/map_photo/${encodeURIComponent(key)}`)
            .then(r => r.ok ? r.json() : null)
            .then(d => { if (d && d.url) _setPhotoUI(d.url); });
    }

    window.uploadAzObjPhoto = function (input) {
        if (!input.files || !input.files[0]) return;
        const file = input.files[0];
        const fd   = new FormData();
        fd.append('key',  _currentPhotoKey);
        fd.append('file', file);
        const wrap = document.getElementById('azObjPhotoWrap');
        if (wrap) wrap.style.opacity = '0.6';
        fetch('/api/admin/map_photo', { method: 'POST', body: fd })
            .then(r => r.json())
            .then(d => {
                if (d.url) _setPhotoUI(d.url);
                if (wrap) wrap.style.opacity = '';
            })
            .catch(() => {
                if (wrap) wrap.style.opacity = '';
            });
        input.value = '';
    };

    window.deleteAzObjPhoto = function () {
        if (!_currentPhotoKey) return;
        fetch(`/api/admin/map_photo/${encodeURIComponent(_currentPhotoKey)}`, { method: 'DELETE' })
            .then(() => _setPhotoUI(null));
    };

    window.closeAzObjModal = function () {
        const modal = document.getElementById('azObjModal');
        if (modal) modal.classList.remove('open');
        clearInterval(_auctionTimer);
    };

    window.copyAzObjGps = function () {
        if (!_currentGpsCmd) return;
        navigator.clipboard.writeText(_currentGpsCmd).then(() => {
            const btn = document.getElementById('azObjCopyBtn');
            if (!btn) return;
            const orig = btn.innerHTML;
            btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 20 20" fill="none"><path d="M4 10l4 4 8-8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Скопировано!';
            btn.classList.add('copied');
            setTimeout(() => { btn.innerHTML = orig; btn.classList.remove('copied'); }, 2000);
        });
    };

    // Close modal on overlay click
    document.addEventListener('DOMContentLoaded', () => {
        const m = document.getElementById('azObjModal');
        if (m) m.addEventListener('click', e => { if (e.target === m) window.closeAzObjModal(); });
    });

    // ── Legend toggle ──────────────────────────────────────────
    window.toggleAzLegend = function () {
        const legend = document.getElementById('az-map-legend');
        const toggle = document.getElementById('az-legend-toggle');
        if (!legend) return;
        const hidden = legend.classList.toggle('hidden');
        if (toggle) toggle.classList.toggle('legend-open', !hidden);
    };

    // ── Filter ─────────────────────────────────────────────────
    window.azMapFilter = function (btn, filter) {
        const aliases = {
            'houses-owned': 'house-owned',
            'houses-free': 'house-free',
            'houses-auction': 'house-auction',
        };
        filter = aliases[filter] || filter;
        _azFilter = filter;
        document.querySelectorAll('.az-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.az-marker').forEach(m => {
            const mf = m.getAttribute('data-filter');
            const show = filter === 'all' ||
                         filter === mf ||
                         (filter === 'businesses' && (mf === 'businesses' || mf === 'biz-free'));
            m.classList.toggle('hidden', !show);
        });
    };

    window.toggleArizonaMapFullscreen = function () {
        const wrap = document.querySelector('#arizona-map .az-map-wrap');
        const label = document.getElementById('az-expand-label');
        const btn = document.getElementById('az-expand-btn');
        if (!wrap) return;
        const expanded = wrap.classList.toggle('az-map-fullscreen');
        document.body.classList.toggle('sidebar-hidden', expanded);
        document.body.classList.toggle('az-map-expanded', expanded);
        if (label) label.textContent = expanded ? 'Свернуть' : 'Развернуть';
        if (btn) btn.classList.toggle('active', expanded);
        requestAnimationFrame(() => {
            centerMap();
            applyTransform();
        });
    };

    // ── Drag & Zoom ────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', () => {
        const container = document.getElementById('az-map-container');
        if (!container) return;

        initThemeButtons();
        _mapReady = centerMap();
        // Load base layer first (eliminates black background during all zooms)
        loadBaseTiles();
        applyTransform();

        // Prevent native image drag and text selection on map
        container.addEventListener('dragstart', e => e.preventDefault());
        container.addEventListener('selectstart', e => e.preventDefault());

        let dragging = false, _hasDragged = false, startX, startY, startTx, startTy;
        const DRAG_THRESHOLD = 6;
        const clamp = (v, mn, mx) => Math.min(mx, Math.max(mn, v));

        // Freeze marker interaction during zoom to prevent lag
        let _zoomEndTimer = null;
        let _rafPending = false;
        const markersLayer = document.getElementById('az-markers-layer');
        const tooltip = document.getElementById('az-map-tooltip');

        function startZooming() {
            if (markersLayer) markersLayer.style.pointerEvents = 'none';
            if (tooltip) tooltip.className = 'az-map-tooltip'; // hide tooltip
            if (_tooltipFrame) { cancelAnimationFrame(_tooltipFrame); _tooltipFrame = null; }
            setMarkerHoverSuspended(true);
        }
        function stopZooming() {
            if (markersLayer) markersLayer.style.pointerEvents = '';
            setMarkerHoverSuspended(false);
        }

        container.addEventListener('wheel', e => {
            e.preventDefault();
            startZooming();
            clearTimeout(_zoomEndTimer);
            _zoomEndTimer = setTimeout(stopZooming, 300);

            const rect  = container.getBoundingClientRect();
            const mx    = e.clientX - rect.left;
            const my    = e.clientY - rect.top;
            const delta = e.deltaY < 0 ? 1.12 : 0.89;
            const ns    = clamp(scale * delta, getMinScale(), 4);
            tx = mx - (mx - tx) * (ns / scale);
            ty = my - (my - ty) * (ns / scale);
            scale = ns;

            // Throttle to one frame — prevents stacking wheel events
            if (!_rafPending) {
                _rafPending = true;
                requestAnimationFrame(() => {
                    _rafPending = false;
                    applyTransform();
                });
            }
        }, { passive: false });

        container.addEventListener('mousedown', e => {
            if (e.button !== 0) return;
            dragging = true;
            _hasDragged = false;
            startX = e.clientX; startY = e.clientY;
            startTx = tx; startTy = ty;
        });
        window.addEventListener('mousemove', e => {
            if (!dragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            if (!_hasDragged) {
                if (Math.sqrt(dx * dx + dy * dy) < DRAG_THRESHOLD) return;
                _hasDragged = true;
                setMarkerHoverSuspended(true);
            }
            tx = startTx + dx;
            ty = startTy + dy;
            applyTransform();
        });
        window.addEventListener('mouseup', () => {
            dragging = false;
            if (_hasDragged) setMarkerHoverSuspended(false);
            _hasDragged = false;
        });

        // Touch
        let lastDist = null;
        container.addEventListener('touchstart', e => {
            if (e.touches.length === 1) {
                dragging = true;
                setMarkerHoverSuspended(true);
                startX = e.touches[0].clientX; startY = e.touches[0].clientY;
                startTx = tx; startTy = ty;
            }
        });
        container.addEventListener('touchmove', e => {
            e.preventDefault();
            if (e.touches.length === 1 && dragging) {
                tx = startTx + (e.touches[0].clientX - startX);
                ty = startTy + (e.touches[0].clientY - startY);
                applyTransform();
            } else if (e.touches.length === 2) {
                const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
                if (lastDist) {
                    const ns = clamp(scale * (d / lastDist), getMinScale(), 4);
                    scale = ns;
                    applyTransform();
                }
                lastDist = d;
            }
        }, { passive: false });
        container.addEventListener('touchend', () => { dragging = false; lastDist = null; setMarkerHoverSuspended(false); });
        window.addEventListener('resize', () => {
            centerMap();
            applyTransform();
        });
        window.addEventListener('keydown', e => {
            if (e.key !== 'Escape') return;
            const wrap = document.querySelector('#arizona-map .az-map-wrap.az-map-fullscreen');
            if (wrap) window.toggleArizonaMapFullscreen();
        });
    });

    // ── Auto-load on tab switch ────────────────────────────────
    const _origSwitch = window.switchTab;
    if (_origSwitch) {
        window.switchTab = function (tab) {
            _origSwitch(tab);
            if (tab === 'arizona-map' && !_azData) loadArizonaMap();
        };
    }
})();
