-- ════════════════════════════════════════════════════════════════════════════
--  Road66 CEF Panel — браузерная версия торговой аналитики (HTML/CSS/JS)
--  Альтернатива road66.lua (mimgui). Тот же бэкенд, тот же протокол, тот же
--  набор хоткеев, но рендер через встроенный Chromium → красивый дизайн.
--
--  Зависимости (поставить рядом со скриптом):
--    1. moonloader/asi/mod_cef.asi          — CEF runtime
--    2. moonloader/lib/cef.lua              — Lua-обёртка над mod_cef
--    3. moonloader/lib/samp/events.lua      — для чата (опционально)
--    4. ресурсы:
--         moonloader/resource/road66_cef/index.html
--         moonloader/resource/road66_cef/style.css
--         moonloader/resource/road66_cef/app.js
--
--  Переключение: CTRL+N (открыть/закрыть), команда чата /r66cef
-- ════════════════════════════════════════════════════════════════════════════

script_name('Road66 CEF Panel')
script_author('Road66 Market')
script_version('1.0')
script_dependencies('cef')

local ffi    = require 'ffi'
local json   = require 'cjson' -- если нет cjson, замените на 'dkjson'
local effil  = require 'effil'

-- ─── CEF wrapper shim ──────────────────────────────────────────────────────
-- В разных сборках MoonLoader CEF API чуть-чуть отличается. Эта прослойка
-- инкапсулирует все вызовы — если у вас другая обёртка, перепишите 5 функций
-- ниже и весь остальной код продолжит работать без изменений.
local cef_lib_ok, cef = pcall(require, 'cef')
if not cef_lib_ok then
    print('[Road66 CEF] Не найден lib/cef. Положите cef.lua в moonloader/lib/.')
    return
end

local Browser = {}
Browser.__index = Browser

function Browser.new(url)
    local self = setmetatable({}, Browser)
    -- Большинство популярных обёрток поддерживают одно из:
    --   cef.create / cef.new / cef.CreateBrowser
    local create =
        cef.create or cef.new or cef.CreateBrowser or cef.createBrowser
    if not create then
        error('[Road66 CEF] cef.create / cef.new не найдены в обёртке')
    end
    self._b = create(url, true) -- transparent = true
    return self
end

function Browser:show(v)
    local fn = self._b.setVisible or self._b.SetVisible or self._b.show
    if fn then fn(self._b, v ~= false) end
end

function Browser:focus(v)
    local fn = self._b.setFocus or self._b.SetFocus or self._b.focus
    if fn then fn(self._b, v ~= false) end
end

function Browser:set_geometry(x, y, w, h)
    local sp = self._b.setPosition or self._b.SetPosition
    local sz = self._b.setSize     or self._b.SetSize
    if sp then sp(self._b, x, y) end
    if sz then sz(self._b, w, h) end
end

function Browser:execute(js)
    local fn = self._b.execute or self._b.Execute or self._b.executeJavaScript
    if fn then fn(self._b, js) end
end

function Browser:on_event(handler)
    -- handler(event_name:string, payload:table)
    local sub = self._b.onEvent or self._b.OnEvent or cef.addEventHandler
    if sub then
        if cef.addEventHandler then
            cef.addEventHandler(function(name, data) handler(name, data) end)
        else
            sub(self._b, function(name, data) handler(name, data) end)
        end
    end
end

-- ─── Config ────────────────────────────────────────────────────────────────
local CONFIG_PATH = getWorkingDirectory() .. '/config/road66cef_config.json'
local cfg = {
    api_key    = '',
    server_url = 'http://localhost:5000',
    auto_sync  = true,
    panel_w    = 1200,
    panel_h    = 800,
}

local function ensure_dir(path)
    local f = io.open(path, 'rb')
    if f then f:close(); return end
    os.execute('mkdir "' .. path:gsub('/', '\\') .. '"')
end

local function load_config()
    local f = io.open(CONFIG_PATH, 'r')
    if not f then return end
    local data = f:read('*a'); f:close()
    local ok, t = pcall(json.decode, data)
    if ok and type(t) == 'table' then
        for k, v in pairs(t) do cfg[k] = v end
    end
end

local function save_config()
    ensure_dir(getWorkingDirectory() .. '/config')
    local f = io.open(CONFIG_PATH, 'w')
    if not f then return end
    f:write(json.encode(cfg)); f:close()
end

-- ─── Async HTTP via effil ──────────────────────────────────────────────────
local http_worker_code = [[
    local effil = require 'effil'
    local http  = require 'socket.http'
    local ltn12 = require 'ltn12'
    return function(method, url, headers, body, timeout)
        http.TIMEOUT = timeout or 8
        local sink_t = {}
        local req = {
            method = method, url = url, headers = headers,
            sink   = ltn12.sink.table(sink_t),
        }
        if body then
            req.source  = ltn12.source.string(body)
            req.headers = req.headers or {}
            req.headers['Content-Length'] = tostring(#body)
        end
        local ok, code = http.request(req)
        return ok and true or false, tonumber(code) or 0, table.concat(sink_t)
    end
]]

local function http_async(method, url, headers, body, timeout)
    local thr = effil.thread(load(http_worker_code)())(
        method, url, headers, body, timeout
    )
    -- ждём не блокируя поток MoonLoader: ждём в lua_thread
    while thr:status() == 'running' do wait(50) end
    return thr:get()
end

local function api_post(path, body_table)
    local ok, status, text = http_async('POST', cfg.server_url .. path, {
        ['Content-Type'] = 'application/json',
        ['X-API-Key']    = cfg.api_key,
    }, json.encode(body_table or {}), 8)
    if not ok then return nil end
    local jok, data = pcall(json.decode, text or '')
    return jok and data or nil
end

local function api_get(path)
    local ok, status, text = http_async('GET', cfg.server_url .. path, {
        ['X-API-Key'] = cfg.api_key,
    }, nil, 8)
    if not ok then return nil end
    local jok, data = pcall(json.decode, text or '')
    return jok and data or nil
end

-- ─── Browser instance & state ──────────────────────────────────────────────
local browser
local panel_visible = false
local sync_status = { online = false, msg = 'Не подключено' }
local server_list = {}

local function panel_url()
    local p = getWorkingDirectory():gsub('\\', '/')
    return 'file:///' .. p .. '/resource/road66_cef/index.html'
end

local function center_panel()
    local sw, sh = getScreenResolution()
    local x = math.floor((sw - cfg.panel_w) / 2)
    local y = math.floor((sh - cfg.panel_h) / 2)
    browser:set_geometry(x, y, cfg.panel_w, cfg.panel_h)
end

-- ─── Lua → JS пуш данных ───────────────────────────────────────────────────
local function js_push(channel, payload)
    if not browser then return end
    local s = json.encode({ channel = channel, payload = payload or {} })
    -- В JS обработчик объявлен в app.js: window.r66.dispatch(msg)
    -- Экранируем кавычки/переводы строк (минимум):
    s = s:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n')
    browser:execute('window.r66 && window.r66.dispatch("' .. s .. '")')
end

local function push_status()
    js_push('status', {
        online   = sync_status.online,
        message  = sync_status.msg,
        api_key  = cfg.api_key ~= '' and '••••••••' or '',
        server   = cfg.server_url,
        version  = '1.0 CEF',
    })
end

-- ─── Backend actions (всё крутится в lua_thread) ───────────────────────────
local function do_ping()
    if cfg.api_key == '' then
        sync_status.online = false
        sync_status.msg    = 'Введите API ключ'
        push_status(); return
    end
    local d = api_post('/api/sync/ping', { api_key = cfg.api_key })
    if d and d.success then
        sync_status.online = true; sync_status.msg = 'Подключено'
    else
        sync_status.online = false
        sync_status.msg    = (d and d.error) or 'Нет ответа от сервера'
    end
    push_status()
end

local function do_load_servers()
    local d = api_get('/api/sync/servers')
    if d and d.servers then
        server_list = d.servers
        js_push('servers', d.servers)
    end
end

local function do_load_arbitrage()
    js_push('arbitrage:loading', { loading = true })
    local d = api_get('/api/sync/arbitrage')
    js_push('arbitrage', { rows = (d and d.rows) or {}, error = d and d.error })
end

local function do_load_market(query, server_id)
    js_push('market:loading', { loading = true })
    local path = string.format('/api/sync/market?q=%s&server=%d',
        (query or ''), tonumber(server_id) or 0)
    local d = api_get(path)
    js_push('market', { rows = (d and d.rows) or {}, error = d and d.error })
end

local function do_load_top(scan)
    if scan then api_post('/api/sync/top/scan', { api_key = cfg.api_key }) end
    js_push('top:loading', { loading = true })
    local d = api_get('/api/sync/top')
    js_push('top', { rows = (d and d.rows) or {}, error = d and d.error })
end

-- ─── JS → Lua обработчик событий ───────────────────────────────────────────
local function on_js_event(name, data)
    -- name всегда строка, data — table. Все действия выполняем в lua_thread,
    -- чтобы не блокировать рендер браузера.
    if name == 'close' then
        panel_visible = false
        if browser then browser:show(false); browser:focus(false) end

    elseif name == 'save_config' then
        if data and type(data) == 'table' then
            if data.api_key    then cfg.api_key    = tostring(data.api_key) end
            if data.server_url then cfg.server_url = tostring(data.server_url):gsub('/+$', '') end
            if data.auto_sync ~= nil then cfg.auto_sync = data.auto_sync and true or false end
            save_config()
        end
        lua_thread.create(do_ping)

    elseif name == 'request_status' then
        push_status()

    elseif name == 'request_servers' then
        lua_thread.create(do_load_servers)

    elseif name == 'request_arbitrage' then
        lua_thread.create(do_load_arbitrage)

    elseif name == 'request_market' then
        lua_thread.create(function()
            do_load_market(data and data.query or '', data and data.server or 0)
        end)

    elseif name == 'request_top' then
        lua_thread.create(function() do_load_top(data and data.scan) end)

    elseif name == 'open_link' then
        if data and data.url then
            os.execute('start ' .. data.url)
        end
    end
end

-- ─── Toggle panel ──────────────────────────────────────────────────────────
local function toggle_panel()
    if not browser then
        browser = Browser.new(panel_url())
        center_panel()
        browser:on_event(on_js_event)
        -- стартовый push после загрузки страницы
        lua_thread.create(function()
            wait(800)
            push_status()
            if cfg.auto_sync then do_ping() end
            do_load_servers()
        end)
    end
    panel_visible = not panel_visible
    browser:show(panel_visible)
    browser:focus(panel_visible)
    if panel_visible then
        showCursor(true, true)
    else
        showCursor(false, false)
    end
end

-- ─── Hotkeys & chat command ────────────────────────────────────────────────
local function hotkey_loop()
    local VK_CTRL, VK_N = 0x11, 0x4E
    local pressed_last = false
    while true do
        wait(0)
        if not isSampLoaded() or not isSampfuncsLoaded() then
            wait(500)
        else
            local ok_c, ctrl = pcall(isKeyDown, VK_CTRL)
            local ok_n, n    = pcall(isKeyDown, VK_N)
            local pressed = (ok_c and ctrl) and (ok_n and n)
            if pressed and not pressed_last then
                toggle_panel()
            end
            pressed_last = pressed
        end
    end
end

function main()
    while not isSampAvailable() do wait(100) end
    load_config()
    sampRegisterChatCommand('r66cef', toggle_panel)
    sampAddChatMessage('{a855f7}[Road66 CEF]{ffffff} Загружено. CTRL+N или /r66cef', -1)
    lua_thread.create(hotkey_loop)
    while true do wait(500) end
end
