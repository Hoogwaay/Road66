/* ════════════════════════════════════════════════════════════════════════════
   Road66 CEF · frontend logic
   Связь с Lua-стороной идёт через объект `window.cef` (предоставляется
   мост-обёрткой mod_cef). Все события из Lua прилетают в window.r66.dispatch.
   Все действия из браузера в Lua → window.r66.send(name, payload).
   ════════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  // ─── CEF bridge shim (адаптируется под любую обёртку) ──────────────────
  function send(name, payload) {
    payload = payload || {};
    try {
      // Чаще всего у CEF есть один из этих API:
      if (window.cef && typeof window.cef.call === 'function') {
        window.cef.call(name, payload); return;
      }
      if (window.cef && typeof window.cef.send === 'function') {
        window.cef.send(name, payload); return;
      }
      if (window.cefQuery) {
        window.cefQuery({ request: JSON.stringify({ event: name, data: payload }) });
        return;
      }
      if (window.external && typeof window.external.notify === 'function') {
        window.external.notify(JSON.stringify({ event: name, data: payload }));
        return;
      }
      // dev-fallback
      console.log('[r66 dev]', name, payload);
    } catch (e) { console.error('[r66 send]', e); }
  }

  // ─── Tabs ─────────────────────────────────────────────────────────────
  const TITLES = {
    arbitrage: 'Арбитраж',
    market:    'Рынок',
    avg:       'Средние цены',
    top:       'Топ сделок',
    settings:  'Настройки',
  };

  function activate(tab) {
    document.querySelectorAll('.nav-item').forEach(b =>
      b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('.tab').forEach(s =>
      s.hidden = (s.dataset.tab !== tab));
    document.getElementById('page-title').textContent = TITLES[tab] || '—';

    // Lazy-pull data on first visit
    if (tab === 'arbitrage') send('request_arbitrage');
    if (tab === 'market')    send('request_servers');
    if (tab === 'top')       send('request_top');
  }

  document.getElementById('nav').addEventListener('click', (e) => {
    const btn = e.target.closest('.nav-item'); if (!btn) return;
    activate(btn.dataset.tab);
  });

  document.getElementById('btn-close').addEventListener('click', () => send('close'));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') send('close'); });

  // ─── Global action delegation ─────────────────────────────────────────
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-act]'); if (!btn) return;
    const act = btn.dataset.act;
    switch (act) {
      case 'reload-arb':   send('request_arbitrage'); break;
      case 'reload-market':
        send('request_market', {
          query:  document.getElementById('mkt-query').value || '',
          server: parseInt(document.getElementById('mkt-server').value, 10) || 0,
        }); break;
      case 'reload-top':   send('request_top'); break;
      case 'rescan-top':   send('request_top', { scan: true }); break;
      case 'save-cfg': {
        send('save_config', {
          api_key:    document.getElementById('cfg-key').value,
          server_url: document.getElementById('cfg-url').value,
          auto_sync:  document.getElementById('cfg-auto').checked,
        });
        const s = document.getElementById('cfg-status');
        s.textContent = 'Сохранено, проверяю связь…';
        s.style.color = 'var(--accent-light)';
        break;
      }
      case 'ping': send('request_status'); break;
    }
  });

  // ─── Renderers ────────────────────────────────────────────────────────
  function fmt(n) {
    if (n == null || isNaN(n)) return '—';
    return Number(n).toLocaleString('ru-RU');
  }

  function renderRows(targetId, rows, kind) {
    const root = document.getElementById(targetId);
    if (!rows || rows.length === 0) {
      root.innerHTML = '<div class="empty">Нет данных</div>'; return;
    }
    const html = rows.map(r => {
      const profit = r.profit != null ? `<span class="profit">+${fmt(r.profit)}</span>` : '';
      const buy    = r.buy_price  != null ? `<span class="price buy">${fmt(r.buy_price)}</span>`   : '';
      const sell   = r.sell_price != null ? `<span class="price sell">${fmt(r.sell_price)}</span>` : '';
      const meta   = [r.buy_server, r.sell_server, r.shop, r.server].filter(Boolean).join(' → ');
      return `
        <div class="card" data-kind="${kind}">
          <div>
            <div class="name">${escapeHtml(r.name || r.item || '—')}</div>
            <div class="meta">${escapeHtml(meta)}</div>
          </div>
          ${buy}${sell}${profit}
        </div>`;
    }).join('');
    root.innerHTML = html;
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function renderServers(servers) {
    const sel = document.getElementById('mkt-server');
    sel.innerHTML = '<option value="0">Все серверы</option>' +
      servers.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join('');
  }

  function renderStatus(p) {
    const pill = document.getElementById('status-pill');
    const dot  = pill.querySelector('.status-dot');
    const txt  = pill.querySelector('.status-text');
    const ok   = !!p.online;
    pill.classList.toggle('online', ok);
    dot.classList.toggle('online', ok);
    txt.textContent = p.message || (ok ? 'Online' : 'Offline');

    document.getElementById('side-online').textContent = ok ? 'Online' : 'Offline';
    document.getElementById('side-online').style.color = ok ? 'var(--ok)' : 'var(--text-mute)';
    document.getElementById('side-version').textContent = p.version || '1.0 CEF';

    document.getElementById('cfg-key').placeholder = p.api_key || '••••••••';
    document.getElementById('cfg-url').placeholder = p.server  || 'http://localhost:5000';

    const cs = document.getElementById('cfg-status');
    cs.textContent = p.message || '';
    cs.style.color = ok ? 'var(--ok)' : 'var(--bad)';
  }

  // ─── Lua → JS dispatcher ──────────────────────────────────────────────
  // Lua вызывает: window.r66.dispatch('{"channel":"xxx","payload":{...}}')
  window.r66 = {
    send: send,
    dispatch: function (raw) {
      let msg;
      try { msg = (typeof raw === 'string') ? JSON.parse(raw) : raw; }
      catch (e) { console.error('[r66 dispatch parse]', e); return; }
      const ch = msg && msg.channel; const p = (msg && msg.payload) || {};
      switch (ch) {
        case 'status':           renderStatus(p); break;
        case 'servers':          renderServers(Array.isArray(p) ? p : []); break;
        case 'arbitrage':        renderRows('arb-list', p.rows, 'arb'); break;
        case 'market':           renderRows('mkt-list', p.rows, 'mkt'); break;
        case 'top':              renderRows('top-list', p.rows, 'top'); break;
        case 'arbitrage:loading':
          document.getElementById('arb-list').innerHTML = '<div class="empty">Загрузка…</div>'; break;
        case 'market:loading':
          document.getElementById('mkt-list').innerHTML = '<div class="empty">Загрузка…</div>'; break;
        case 'top:loading':
          document.getElementById('top-list').innerHTML = '<div class="empty">Загрузка…</div>'; break;
      }
    }
  };

  // Bootstrap
  activate('arbitrage');
  send('request_status');
})();
