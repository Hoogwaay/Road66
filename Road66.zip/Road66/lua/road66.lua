script_name('Road66 Market')
script_author('Road66 Market')
script_version('1.1')

require 'lib.moonloader'
local sampev   = require 'lib.samp.events'
local json     = require 'dkjson'
local imgui    = require 'mimgui'
local encoding = require 'encoding'
local requests = require 'requests'
local ffi      = require('ffi')

encoding.default = 'CP1251'
u8 = encoding.UTF8

local function safe_u8(s)
    if type(s) ~= 'string' or s == '' then return s or '' end
    local ok, result = pcall(function() return tostring(u8(s)) end)
    if ok and result and result ~= '' then return result end
    local ok2, result2 = pcall(function() return u8:decode(s) end)
    if ok2 and result2 and result2 ~= '' then return result2 end
    return s
end

-- Config
local CFG_FILE = getWorkingDirectory() .. '/road66_config.json'

local SYNC_INTERVAL         = 30
local TRADE_SEND_INTERVAL   = 3
local CMD_POLL_INTERVAL     = 2
local DATA_REFRESH_INTERVAL = 30

local cfg = {
    api_key    = '',
    server_url = 'http://localhost:5000',
}

-- Runtime state
local current_balance   = 0
local balance_known     = false
local last_sync_time    = 0
local last_trade_send   = 0
local last_cmd_poll     = 0
local sync_ok           = false
local sync_status_msg   = ''
local pending_trades    = {}
local trades_sent       = 0
local trades_captured   = 0
local chat_seen         = 0
local last_chat_message = ''
local last_trade_error  = ''
local request_busy      = false
local syncing_busy      = false

-- UI state
local wnd_open    = imgui.new.bool(false)
local current_tab = 'arbitrage'
local inp_api_key = imgui.new.char[128]('')
local inp_srv_url = imgui.new.char[256]('')

local arb_data       = nil
local arb_loading    = false
local arb_last_load  = 0
local arb_error      = ''

-- Helpers
local function fmt_money(n)
    n = math.floor(tonumber(n) or 0)
    local s = tostring(n):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^%s+','')
    return s
end

local function fmt_price(n, currency)
    return fmt_money(n) .. ' ' .. (currency or 'SA$')
end

local function get_player_nick()
    local nick = 'Unknown'
    pcall(function()
        if sampGetPlayerNickname then
            nick = sampGetPlayerNickname() or 'Unknown'
        end
    end)
    return nick
end

local function load_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'r')
        if f then
            local ok, t = pcall(json.decode, f:read('*a'))
            f:close()
            if ok and type(t) == 'table' then
                cfg.api_key    = t.api_key or ''
                cfg.server_url = t.server_url or 'http://localhost:5000'
            end
        end
    end)
end

local function save_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'w')
        if f then
            f:write(json.encode({ api_key = cfg.api_key, server_url = cfg.server_url }))
            f:close()
        end
    end)
end

-- HTTP
local function http_post(path, body_table)
    if request_busy then return nil end
    request_busy = true
    local ok, res = pcall(function()
        return requests.post(cfg.server_url .. path, {
            headers = {
                ['Content-Type'] = 'application/json',
                ['X-API-Key']    = cfg.api_key,
            },
            data    = json.encode(body_table),
            timeout = 8,
        })
    end)
    request_busy = false
    if ok and res then
        local status = res.status_code or 0
        local ok2, data = pcall(json.decode, res.text or '')
        return ok2 and data or { success = status >= 200 and status < 300 }
    end
    return nil
end

local function http_get(path)
    if request_busy then return nil end
    request_busy = true
    local ok, res = pcall(function()
        return requests.get(cfg.server_url .. path, {
            headers = { ['X-API-Key'] = cfg.api_key },
            timeout = 8,
        })
    end)
    request_busy = false
    if ok and res then
        local ok2, data = pcall(json.decode, res.text or '')
        return ok2 and data or nil
    end
    return nil
end

-- Sync
local function test_connection()
    if cfg.api_key == '' then
        sync_ok = false
        sync_status_msg = 'Введите API ключ'
        return
    end
    local data = http_post('/api/sync/ping', { api_key = cfg.api_key })
    if data and data.success then
        sync_ok = true
        sync_status_msg = 'Подключено'
    elseif data and data.error then
        sync_ok = false
        sync_status_msg = tostring(data.error)
    else
        sync_ok = false
        sync_status_msg = 'Нет ответа от сервера'
    end
end

local function sync_balance()
    if cfg.api_key == '' or not balance_known or syncing_busy then return end
    syncing_busy = true
    local data = http_post('/api/sync/balance', {
        api_key = cfg.api_key,
        balance = current_balance,
    })
    syncing_busy = false
    if data and data.success then
        sync_ok = true
        sync_status_msg = 'Баланс отправлен'
    else
        sync_ok = false
    end
end

local function sync_pending_trades()
    if cfg.api_key == '' or #pending_trades == 0 or syncing_busy then return end
    syncing_busy = true
    local to_send = {}
    for i = 1, #pending_trades do to_send[i] = pending_trades[i] end
    pending_trades = {}
    local data = http_post('/api/sync/trades', {
        api_key = cfg.api_key,
        trades  = to_send,
    })
    if data and data.success then
        trades_sent = trades_sent + (data.inserted or #to_send)
    else
        for i = 1, #to_send do table.insert(pending_trades, to_send[i]) end
    end
    syncing_busy = false
end

local function poll_remote_commands()
    if cfg.api_key == '' then return end
    local data = http_get('/api/sync/commands/pop')
    if data and data.success and data.command and data.command ~= '' then
        local cmd = tostring(data.command)
        pcall(function() sampSendChat(cmd, 1) end)
    end
end

local function refresh_arbitrage()
    if cfg.api_key == '' then arb_error = 'Нужен API ключ' return end
    arb_loading = true
    arb_error = ''
    local data = http_get('/api/sync/arbitrage')
    arb_loading = false
    if data and data.success then
        arb_data = data
        arb_last_load = os.time()
    else
        arb_error = (data and data.error) or 'Ошибка загрузки'
    end
end

-- Trade parsing (preserved with fixed encoding)
local function set_balance(num)
    num = tonumber((num)) or 0
    if num < 0 then num = 0 end
    current_balance = math.floor(num)
    balance_known = true
end

local function parse_num(s)
    if not s then return 0 end
    local cleaned = tostring(s):gsub('[%s%. ]', '')
    return tonumber((cleaned)) or 0
end

local CP_BUY_WORD  = string.char(0xEA, 0xF3, 0xEF, 0xE8, 0xEB, 0xE8)
local CP_SELL_WORD = string.char(0xEF, 0xF0, 0xEE, 0xE4, 0xE0, 0xEB, 0xE8)
local CP_SHT_WORD  = string.char(0xF8, 0xF2)

local function strip_chat_markup(s)
    return tostring(s or ''):gsub('{%x%x%x%x%x%x}', ''):gsub('\194\160', ' ')
end

local function trim(s)
    return tostring(s or ''):match('^%s*(.-)%s*$')
end

local function append_trade(trade)
    table.insert(pending_trades, trade)
    trades_captured = trades_captured + 1
end

local function append_parsed_trade(action, item, qty, price, total, currency)
    qty   = tonumber((qty)) or 1
    price = parse_num(price)
    total = parse_num(total)
    if total == 0 then total = qty * price end
    local clean_item = trim(item)
    if clean_item == '' then clean_item = 'Unknown' end
    append_trade({
        action   = action,
        item     = clean_item,
        quantity = qty,
        count    = qty,
        price    = price,
        total    = total,
        currency = currency or '',
        nick     = get_player_nick(),
        type     = action,
        ts       = os.date('%Y-%m-%d %H:%M:%S')
    })
end

local function is_trade_noise(msg)
    if type(msg) ~= 'string' then return false end
    local s = safe_u8(strip_chat_markup(msg))
    local low = s:lower()
    if low:find('tradelog') then return true end
    if low:find('покупка') then return true end
    if low:find('продажа') then return true end
    if low:find('итого') then return true end
    if low:find('вы успешно купили') then return true end
    if low:find('вы успешно продали') then return true end
    if low:find('вам был добавлен предмет') then return true end
    if low:find('вы купили') then return true end
    if low:find('вы приобрели') then return true end
    if low:find('вы продали') then return true end
    if low:find('игрок купил у вас') then return true end
    if low:find('купил у вас') then return true end
    return false
end

local function try_parse_trade_raw(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    msg = strip_chat_markup(msg)

    do
        local item, qty, price = msg:match('%[sell%] (.+) x(%d+) | (%d+) VC%$')
        if item then
            append_parsed_trade('sell', safe_u8(item), qty, price, tonumber((qty)) * parse_num(price), 'VC$')
            return true
        end
        item, qty, price = msg:match('%[buy%] (.+) x(%d+) | (%d+) VC%$')
        if item then
            append_parsed_trade('buy', safe_u8(item), qty, price, tonumber((qty)) * parse_num(price), 'VC$')
            return true
        end
    end

    local action
    if msg:find(CP_BUY_WORD, 1, true) then action = 'buy'
    elseif msg:find(CP_SELL_WORD, 1, true) then action = 'sell'
    else return false end

    local price_raw, currency
    local p_m  = msg:match(':M:%s*([%d%.]+)')
    local p_kk = msg:match(':KK:%s*([%d%.]+)')
    local p_k  = msg:match(':K:%s*([%d%.]+)')
    if p_m then price_raw = p_m; currency = 'M'
    elseif p_kk then price_raw = p_kk; currency = 'KK'
    elseif p_k then price_raw = p_k; currency = 'K'
    else
        price_raw = msg:match('([%d][%d%.%s]-)%s*$')
        currency = 'K'
    end
    if not price_raw or parse_num(price_raw) == 0 then return false end

    local qty = msg:match('%((%d+)%s+' .. CP_SHT_WORD .. '%.?%)')
            or msg:match('%((%d+)')
            or msg:match('[xXхХ](%d+)')
            or '1'

    local kword = (action == 'buy') and CP_BUY_WORD or CP_SELL_WORD
    local item_raw = msg:match(kword .. '%s+(.-)%s+%(%d')
                  or msg:match(kword .. '%s+(.-)%s+:K:')
                  or msg:match(kword .. '%s+(.-)%s+:M:')

    local item_utf8 = item_raw and safe_u8(item_raw) or 'Unknown'
    append_parsed_trade(action, item_utf8, qty, price_raw, tonumber((qty)) * parse_num(price_raw), currency)
    return true
end

local function try_parse_trade_from_chat(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    local item, qty, price, total

    item, qty, price = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber((qty)) * parse_num(price) end
        append_parsed_trade('buy', item, qty, price, total, '$')
        return true
    end

    item, qty, total = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('[Вв]ы приобрели%s+(.-)%s+%((%d+)%s*[шШ][тТ]%.?%)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, price = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber((qty)) * parse_num(price) end
        append_parsed_trade('sell', item, qty, price, total, '$')
        return true
    end

    item, qty, total = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('sell', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('[Ии]грок купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    return false
end

function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
end

function sampev.onServerMessage(color, msg)
    local ok, err = pcall(function()
        chat_seen = chat_seen + 1
        last_chat_message = tostring(msg or '')
        if is_trade_noise(msg) then return true end
        local decoded = safe_u8(strip_chat_markup(msg or ''))
        last_chat_message = decoded
        if try_parse_trade_raw(decoded)  then return true end
        if try_parse_trade_from_chat(decoded) then return true end
    end)
    if not ok then last_trade_error = tostring(err or '') end
end

function sampev.onResetPlayerMoney() return false end
function sampev.onGivePlayerMoney(money) return false end

-- UI
local SIDEBAR_W = 196

local TABS = {
    {id='arbitrage', label='Арбитраж'},
    {id='market',    label='Рынок'},
    {id='avg',       label='Средние цены'},
    {id='top',       label='Топ сделки'},
    {id='settings',  label='Настройки'},
}

local C_BG       = imgui.ImVec4(0.043, 0.043, 0.071, 1.0)
local C_SIDEBAR  = imgui.ImVec4(0.059, 0.059, 0.133, 1.0)
local C_ACCENT   = imgui.ImVec4(0.659, 0.333, 0.969, 1.0)
local C_ACC_DIM  = imgui.ImVec4(0.659, 0.333, 0.969, 0.18)
local C_ACC_HOV  = imgui.ImVec4(0.659, 0.333, 0.969, 0.30)
local C_TEXT     = imgui.ImVec4(0.949, 0.953, 1.000, 1.0)
local C_TEXT_DIM = imgui.ImVec4(0.949, 0.953, 1.000, 0.55)
local C_GREEN    = imgui.ImVec4(0.40, 0.90, 0.50, 1.0)
local C_RED      = imgui.ImVec4(0.95, 0.42, 0.42, 1.0)
local C_TRANS    = imgui.ImVec4(0, 0, 0, 0)
local C_HOVER    = imgui.ImVec4(1, 1, 1, 0.06)

local function draw_logo()
    imgui.PushStyleColor(imgui.Col.Text, C_ACCENT)
    imgui.SetCursorPosX(18)
    imgui.Text('ROUTE 66')
    imgui.PopStyleColor()
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.SetCursorPosX(18)
    imgui.Text('MARKET')
    imgui.PopStyleColor()
end

local function draw_sidebar()
    imgui.PushStyleColor(imgui.Col.ChildBg, C_SIDEBAR)
    imgui.BeginChild('sidebar', imgui.ImVec2(SIDEBAR_W, 0), false)

    imgui.Spacing(); imgui.Spacing()
    draw_logo()
    imgui.Spacing(); imgui.Separator(); imgui.Spacing()

    for _, t in ipairs(TABS) do
        local sel = (current_tab == t.id)
        if sel then
            imgui.PushStyleColor(imgui.Col.Button,        C_ACC_DIM)
            imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACC_HOV)
            imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACC_HOV)
            imgui.PushStyleColor(imgui.Col.Text,          C_ACCENT)
        else
            imgui.PushStyleColor(imgui.Col.Button,        C_TRANS)
            imgui.PushStyleColor(imgui.Col.ButtonHovered, C_HOVER)
            imgui.PushStyleColor(imgui.Col.ButtonActive,  C_HOVER)
            imgui.PushStyleColor(imgui.Col.Text,          C_TEXT)
        end
        imgui.SetCursorPosX(10)
        if imgui.Button(t.label .. '##nav_' .. t.id, imgui.ImVec2(SIDEBAR_W - 20, 32)) then
            current_tab = t.id
            if t.id == 'arbitrage' and (not arb_data or os.time() - arb_last_load > DATA_REFRESH_INTERVAL) then
                lua_thread.create(refresh_arbitrage)
            end
        end
        imgui.PopStyleColor(4)
    end

    local h = imgui.GetWindowHeight()
    imgui.SetCursorPosY(h - 70)
    imgui.Separator()
    imgui.SetCursorPosX(14)
    imgui.PushStyleColor(imgui.Col.Text, sync_ok and C_GREEN or C_RED)
    imgui.Text((sync_ok and '● онлайн' or '● оффлайн'))
    imgui.PopStyleColor()
    imgui.SetCursorPosX(14)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    if balance_known then
        imgui.Text(fmt_money(current_balance) .. ' SA$')
    else
        imgui.Text('—')
    end
    imgui.PopStyleColor()

    imgui.EndChild()
    imgui.PopStyleColor()
end

local function tab_header(title, subtitle)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT)
    imgui.Text(title)
    imgui.PopStyleColor()
    if subtitle and subtitle ~= '' then
        imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
        imgui.Text(subtitle)
        imgui.PopStyleColor()
    end
    imgui.Spacing(); imgui.Separator(); imgui.Spacing()
end

local function draw_arbitrage()
    local subtitle = ''
    if arb_data then
        subtitle = (arb_data.buy_name or '') .. '  →  ' .. (arb_data.sell_name or '')
    end
    tab_header('Арбитраж', subtitle)

    if imgui.Button(arb_loading and 'Загрузка...' or 'Обновить', imgui.ImVec2(120, 26)) and not arb_loading then
        lua_thread.create(refresh_arbitrage)
    end
    imgui.SameLine()
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    if arb_last_load > 0 then
        imgui.Text('Обновлено: ' .. os.date('%H:%M:%S', arb_last_load))
    end
    imgui.PopStyleColor()
    imgui.Spacing()

    if cfg.api_key == '' then
        imgui.PushStyleColor(imgui.Col.Text, C_RED)
        imgui.Text('Нужен API ключ. Откройте «Настройки».')
        imgui.PopStyleColor()
        return
    end

    if arb_error ~= '' then
        imgui.PushStyleColor(imgui.Col.Text, C_RED)
        imgui.Text('Ошибка: ' .. arb_error)
        imgui.PopStyleColor()
        return
    end

    if not arb_data or not arb_data.deals or #arb_data.deals == 0 then
        imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
        imgui.Text('Нет данных. Нажмите «Обновить».')
        imgui.PopStyleColor()
        return
    end

    local flags = imgui.TableFlags.Borders + imgui.TableFlags.RowBg + imgui.TableFlags.SizingStretchProp
    if imgui.BeginTable('arb_table', 7, flags) then
        imgui.TableSetupColumn('Скуп лавка',  imgui.TableColumnFlags.WidthFixed, 80)
        imgui.TableSetupColumn('Предмет')
        imgui.TableSetupColumn('Покупка')
        imgui.TableSetupColumn('Скупка')
        imgui.TableSetupColumn('Профит/шт')
        imgui.TableSetupColumn('%',           imgui.TableColumnFlags.WidthFixed, 60)
        imgui.TableSetupColumn('',            imgui.TableColumnFlags.WidthFixed, 90)
        imgui.TableHeadersRow()

        for i, d in ipairs(arb_data.deals) do
            imgui.TableNextRow()

            imgui.TableNextColumn()
            imgui.Text('#' .. tostring(d.lavka_sell or '-'))

            imgui.TableNextColumn()
            imgui.Text(tostring(d.item_name or ''))

            imgui.TableNextColumn()
            imgui.Text(fmt_price(d.price_buy, d.buy_currency or 'SA$'))

            imgui.TableNextColumn()
            imgui.Text(fmt_price(d.price_sell, d.sell_currency or 'VC$'))

            imgui.TableNextColumn()
            imgui.PushStyleColor(imgui.Col.Text, C_GREEN)
            imgui.Text('+' .. fmt_money(d.profit) .. ' ' .. (d.buy_currency or 'SA$'))
            imgui.PopStyleColor()

            imgui.TableNextColumn()
            imgui.Text(string.format('%.1f%%', tonumber(d.profit_pct or 0)))

            imgui.TableNextColumn()
            imgui.PushStyleColor(imgui.Col.Button,        C_ACC_DIM)
            imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACC_HOV)
            imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACC_HOV)
            imgui.PushStyleColor(imgui.Col.Text,          C_ACCENT)
            if imgui.SmallButton('Найти##find_' .. i) then
                if d.lavka_sell then
                    pcall(function()
                        sampSendChat('/findilavka ' .. tostring(d.lavka_sell), 1)
                    end)
                end
            end
            imgui.PopStyleColor(4)
        end
        imgui.EndTable()
    end
end

local function draw_settings()
    tab_header('Настройки', 'API ключ и адрес сервера Road66')

    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('API ключ')
    imgui.PopStyleColor()
    imgui.PushItemWidth(-1)
    imgui.InputText('##apikey', inp_api_key, ffi.sizeof(inp_api_key) - 1)
    imgui.PopItemWidth()

    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('URL сервера')
    imgui.PopStyleColor()
    imgui.PushItemWidth(-1)
    imgui.InputText('##srvurl', inp_srv_url, ffi.sizeof(inp_srv_url) - 1)
    imgui.PopItemWidth()

    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Button,        C_ACC_DIM)
    imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACC_HOV)
    imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACC_HOV)
    imgui.PushStyleColor(imgui.Col.Text,          C_ACCENT)
    if imgui.Button('Сохранить и проверить подключение', imgui.ImVec2(-1, 32)) then
        cfg.api_key    = ffi.string(inp_api_key)
        cfg.server_url = ffi.string(inp_srv_url)
        if cfg.server_url == '' then cfg.server_url = 'http://localhost:5000' end
        cfg.server_url = cfg.server_url:gsub('/+$', '')
        save_cfg()
        sync_status_msg = 'Проверка подключения...'
        sync_ok = false
        lua_thread.create(test_connection)
    end
    imgui.PopStyleColor(4)

    imgui.Spacing(); imgui.Separator(); imgui.Spacing()

    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('Состояние')
    imgui.PopStyleColor()

    imgui.Text('Статус: ' .. (sync_status_msg ~= '' and sync_status_msg or 'Ожидание'))
    imgui.Text('Баланс: ' .. (balance_known and (fmt_money(current_balance) .. ' SA$') or '—'))
    imgui.Text('Сделок отправлено: ' .. tostring(trades_sent))
    imgui.Text('Сделок поймано: ' .. tostring(trades_captured))
    imgui.Text('В очереди: ' .. tostring(#pending_trades))
end

local function draw_placeholder(title)
    tab_header(title, 'Раздел в разработке')
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('Скоро здесь появится тот же функционал, что и на сайте.')
    imgui.PopStyleColor()
end

local function draw_window()
    imgui.SetNextWindowSize(imgui.ImVec2(960, 560), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(140, 140), imgui.Cond.FirstUseEver)

    imgui.PushStyleColor(imgui.Col.WindowBg, C_BG)
    imgui.PushStyleColor(imgui.Col.Text,     C_TEXT)
    imgui.PushStyleVar(imgui.StyleVar.WindowPadding, imgui.ImVec2(0, 0))
    imgui.PushStyleVar(imgui.StyleVar.ItemSpacing,   imgui.ImVec2(6, 6))

    imgui.Begin('Road66 Market##road66', wnd_open, imgui.WindowFlags.NoCollapse)

    draw_sidebar()
    imgui.SameLine()

    imgui.BeginChild('content', imgui.ImVec2(0, 0), false)
    imgui.Indent(20)
    imgui.Spacing()
    if     current_tab == 'arbitrage' then draw_arbitrage()
    elseif current_tab == 'market'    then draw_placeholder('Рынок')
    elseif current_tab == 'avg'       then draw_placeholder('Средние цены')
    elseif current_tab == 'top'       then draw_placeholder('Топ сделки')
    elseif current_tab == 'settings'  then draw_settings()
    end
    imgui.Unindent(20)
    imgui.EndChild()

    imgui.End()
    imgui.PopStyleVar(2)
    imgui.PopStyleColor(2)
end

imgui.OnFrame(function() return wnd_open[0] end, function() draw_window() end)

local function cmd_r66()
    ffi.copy(inp_api_key, cfg.api_key)
    ffi.copy(inp_srv_url, cfg.server_url ~= '' and cfg.server_url or 'http://localhost:5000')
    wnd_open[0] = not wnd_open[0]
end

function main()
    repeat wait(250) until isSampAvailable()
    load_cfg()
    sampRegisterChatCommand('r66', cmd_r66)

    while true do
        wait(1000)
        local now = os.time()

        if now - last_sync_time >= SYNC_INTERVAL and cfg.api_key ~= '' then
            last_sync_time = now
            lua_thread.create(sync_balance)
        end

        if #pending_trades > 0 and cfg.api_key ~= '' and now - last_trade_send >= TRADE_SEND_INTERVAL then
            last_trade_send = now
            lua_thread.create(sync_pending_trades)
        end

        if now - last_cmd_poll >= CMD_POLL_INTERVAL and cfg.api_key ~= '' then
            last_cmd_poll = now
            lua_thread.create(poll_remote_commands)
        end

        if wnd_open[0] and current_tab == 'arbitrage' and cfg.api_key ~= ''
           and arb_last_load > 0 and not arb_loading
           and now - arb_last_load >= DATA_REFRESH_INTERVAL then
            lua_thread.create(refresh_arbitrage)
        end
    end
end
