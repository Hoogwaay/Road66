script_name('Road66 Market')
script_author('Road66 Market')
script_version('1.1')

require 'lib.moonloader'
local sampev   = require 'lib.samp.events'
local json     = require 'dkjson'
local imgui    = require 'mimgui'
local encoding = require 'encoding'
local requests = require 'requests'
local ffi      = require('ffi')

-- effil = real OS threads (bundled with MoonLoader). Falls back gracefully
-- if the library isn't available — script still works, just synchronously.
local effil_ok, effil = pcall(require, 'effil')
if not effil_ok then effil = nil end

-- ─── mimgui style helpers (compat across builds) ─────────────────────────────
-- Some mimgui builds expose only PushStyleVarVec2 / PushStyleVarFloat instead
-- of the overloaded PushStyleVar. Provide safe wrappers so the script does
-- not crash if a particular variant is missing.
local _push_var_stack = 0
local function safe_push_style_var(idx, val)
    local is_vec2 = type(val) == 'cdata'
    local fn
    if is_vec2 then
        fn = imgui.PushStyleVarVec2 or imgui.PushStyleVar
    else
        fn = imgui.PushStyleVarFloat or imgui.PushStyleVar
    end
    if fn then
        local ok = pcall(fn, idx, val)
        if ok then _push_var_stack = _push_var_stack + 1 end
    end
end
local function safe_pop_style_var(count)
    count = count or 1
    local n = math.min(count, _push_var_stack)
    if n > 0 and imgui.PopStyleVar then
        pcall(imgui.PopStyleVar, n)
        _push_var_stack = _push_var_stack - n
    end
end

-- Older mimgui builds don't expose every imgui.Col.* enum (e.g. table colors
-- TableBorderLight/TableBorderStrong/TableHeaderBg/TableRowBg/TableRowBgAlt
-- were added in newer ImGui versions). Even *reading* a missing key on
-- imgui.Col raises an error via __index — so we resolve names via pcall and
-- silently skip ones that don't exist on this build. PopStyleColor is
-- balanced via a tiny stack so we only pop what we actually pushed.
local _color_stacks = {}

local function _resolve_col(name)
    if type(name) ~= 'string' then return name end
    local ok, v = pcall(function() return imgui.Col[name] end)
    if ok then return v end
    return nil
end

local function color_block_begin()
    table.insert(_color_stacks, 0)
end
local function safe_push_style_color(name, value)
    local id = _resolve_col(name)
    if id == nil then return end
    local ok = pcall(imgui.PushStyleColor, id, value)
    if ok then
        local i = #_color_stacks
        if i > 0 then _color_stacks[i] = _color_stacks[i] + 1 end
    end
end
local function color_block_end()
    local i = #_color_stacks
    if i == 0 then return end
    local n = _color_stacks[i]
    table.remove(_color_stacks)
    if n > 0 then pcall(imgui.PopStyleColor, n) end
end

encoding.default = 'CP1251'
u8 = encoding.UTF8

local function safe_u8(s)
    if type(s) ~= 'string' or s == '' then return s or '' end
    local ok, result = pcall(function() return tostring(u8(s)) end)
    if ok and result and result ~= '' then return result end
    local ok2, result2 = pcall(function() return u8:decode(s) end)
    if ok2 and result2 and result2 ~= '' then return result2 end
    return s
end

-- Config
local CFG_FILE = getWorkingDirectory() .. '/road66_config.json'

local SYNC_INTERVAL         = 30
local TRADE_SEND_INTERVAL   = 3
local CMD_POLL_INTERVAL     = 2
local DATA_REFRESH_INTERVAL = 30

local cfg = {
    api_key    = '',
    server_url = 'http://localhost:5000',
}

-- Runtime state
local current_balance   = 0
local balance_known     = false
local last_sync_time    = 0
local last_trade_send   = 0
local last_cmd_poll     = 0
local sync_ok           = false
local sync_status_msg   = ''
local pending_trades    = {}
local trades_sent       = 0
local trades_captured   = 0
local chat_seen         = 0
local last_chat_message = ''
local last_trade_error  = ''
local request_busy      = false
local syncing_busy      = false

-- UI state
local wnd_open    = imgui.new.bool(false)
local current_tab = 'arbitrage'
local inp_api_key = imgui.new.char[128]('')
local inp_srv_url = imgui.new.char[256]('')

local arb_data       = nil
local arb_loading    = false
local arb_last_load  = 0
local arb_error      = ''

-- Helpers
local function fmt_money(n)
    n = math.floor(tonumber(n) or 0)
    local s = tostring(n):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^%s+','')
    return s
end

local function fmt_price(n, currency)
    return fmt_money(n) .. ' ' .. (currency or 'SA$')
end

local function get_player_nick()
    local nick = 'Unknown'
    pcall(function()
        if sampGetPlayerNickname then
            nick = sampGetPlayerNickname() or 'Unknown'
        end
    end)
    return nick
end

local function load_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'r')
        if f then
            local ok, t = pcall(json.decode, f:read('*a'))
            f:close()
            if ok and type(t) == 'table' then
                cfg.api_key    = t.api_key or ''
                cfg.server_url = t.server_url or 'http://localhost:5000'
            end
        end
    end)
end

local function save_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'w')
        if f then
            f:write(json.encode({ api_key = cfg.api_key, server_url = cfg.server_url }))
            f:close()
        end
    end)
end

-- HTTP
-- The `requests` library is synchronous and blocks the main game thread.
-- Wrapping it in lua_thread.create() does NOT help because lua_threads are
-- coroutines, not OS threads. To stop the game from stuttering every time
-- we hit the server, we run the actual socket call in an effil OS thread
-- and poll its completion from the lua_thread, yielding via wait(50) so
-- the game keeps rendering frames.
--
-- These helpers MUST be called from inside a lua_thread (which all sync
-- functions in this script already are).

local HTTP_POLL_MS = 30
local HTTP_MAX_WAIT_MS = 15000  -- safety cap above the requests timeout

local function _http_sync(method, url, headers, body, timeout)
    local ok, res = pcall(function()
        local opts = { headers = headers, timeout = timeout }
        if body then opts.data = body end
        if method == 'POST' then return requests.post(url, opts) end
        return requests.get(url, opts)
    end)
    if ok and res then
        return true, res.status_code or 0, res.text or ''
    end
    return false, 0, ''
end

-- Persistent worker thread + channels.
-- Spawned ONCE on first request; reused for all subsequent calls.
-- This avoids per-request OS-thread creation cost and per-request
-- `require 'requests'` (LuaSocket/LuaSec) initialization, which on
-- Windows can stall the main game thread for 50–200 ms each time.
local _http_in        -- effil.channel — main → worker (jobs)
local _http_out       -- effil.channel — worker → main (results)
local _http_worker_ok -- bool: false if worker failed to start

local function _ensure_http_worker()
    if not effil then return false end
    if _http_in then return _http_worker_ok end
    _http_worker_ok = false

    local ok_in,  in_chan  = pcall(effil.channel)
    local ok_out, out_chan = pcall(effil.channel)
    if not (ok_in and ok_out and in_chan and out_chan) then return false end

    -- Pass package paths so `require 'requests'` works inside the new
    -- Lua state (effil threads start with default paths only).
    local ppath = package.path  or ''
    local cpath = package.cpath or ''

    local ok_spawn = pcall(function()
        effil.thread(function(in_ch, out_ch, ppath, cpath)
            package.path  = ppath
            package.cpath = cpath
            local ok_req, requests = pcall(require, 'requests')
            if not ok_req then
                -- Drain the queue forever, returning failures so callers
                -- don't deadlock waiting on a result.
                while true do
                    local job = in_ch:pop()
                    if job == nil or job == 'STOP' then break end
                    out_ch:push(false, 0, '')
                end
                return
            end
            while true do
                local job = in_ch:pop()  -- blocks until a job arrives
                if job == nil or job == 'STOP' then break end
                local ok, res = pcall(function()
                    local opts = { headers = job.headers, timeout = job.timeout }
                    if job.body then opts.data = job.body end
                    if job.method == 'POST' then return requests.post(job.url, opts) end
                    return requests.get(job.url, opts)
                end)
                if ok and res then
                    out_ch:push(true, res.status_code or 0, res.text or '')
                else
                    out_ch:push(false, 0, '')
                end
            end
        end)(in_chan, out_chan, ppath, cpath)
    end)

    if not ok_spawn then return false end
    _http_in  = in_chan
    _http_out = out_chan
    _http_worker_ok = true
    return true
end

local function _http_async(method, url, headers, body, timeout)
    if not _ensure_http_worker() then
        return _http_sync(method, url, headers, body, timeout)
    end

    -- Drain any stale results left over from a previous timed-out call,
    -- so we don't pick them up as the response to this request.
    while true do
        local stale = { _http_out:pop(0) }
        if #stale == 0 then break end
    end

    local ok_push = pcall(function()
        _http_in:push({
            method  = method,
            url     = url,
            headers = headers,
            body    = body,
            timeout = timeout,
        })
    end)
    if not ok_push then
        return _http_sync(method, url, headers, body, timeout)
    end

    local waited = 0
    while waited < HTTP_MAX_WAIT_MS do
        local got = { _http_out:pop(0) }  -- non-blocking
        if #got > 0 then
            return got[1] and true or false, got[2] or 0, got[3] or ''
        end
        wait(HTTP_POLL_MS)
        waited = waited + HTTP_POLL_MS
    end
    return false, 0, ''
end

local function http_post(path, body_table)
    if request_busy then return nil end
    request_busy = true
    local ok, status, text = _http_async('POST', cfg.server_url .. path, {
        ['Content-Type'] = 'application/json',
        ['X-API-Key']    = cfg.api_key,
    }, json.encode(body_table), 8)
    request_busy = false
    if ok then
        local ok2, data = pcall(json.decode, text or '')
        return ok2 and data or { success = status >= 200 and status < 300 }
    end
    return nil
end

local function http_get(path)
    if request_busy then return nil end
    request_busy = true
    local ok, status, text = _http_async('GET', cfg.server_url .. path, {
        ['X-API-Key'] = cfg.api_key,
    }, nil, 8)
    request_busy = false
    if ok then
        local ok2, data = pcall(json.decode, text or '')
        return ok2 and data or nil
    end
    return nil
end

-- Sync
local function test_connection()
    if cfg.api_key == '' then
        sync_ok = false
        sync_status_msg = 'Введите API ключ'
        return
    end
    local data = http_post('/api/sync/ping', { api_key = cfg.api_key })
    if data and data.success then
        sync_ok = true
        sync_status_msg = 'Подключено'
    elseif data and data.error then
        sync_ok = false
        sync_status_msg = tostring(data.error)
    else
        sync_ok = false
        sync_status_msg = 'Нет ответа от сервера'
    end
end

local function sync_balance()
    if cfg.api_key == '' or not balance_known or syncing_busy then return end
    syncing_busy = true
    local data = http_post('/api/sync/balance', {
        api_key = cfg.api_key,
        balance = current_balance,
    })
    syncing_busy = false
    if data and data.success then
        sync_ok = true
        sync_status_msg = 'Баланс отправлен'
    else
        sync_ok = false
    end
end

local function sync_pending_trades()
    if cfg.api_key == '' or #pending_trades == 0 or syncing_busy then return end
    syncing_busy = true
    local to_send = {}
    for i = 1, #pending_trades do to_send[i] = pending_trades[i] end
    pending_trades = {}
    local data = http_post('/api/sync/trades', {
        api_key = cfg.api_key,
        trades  = to_send,
    })
    if data and data.success then
        trades_sent = trades_sent + (data.inserted or #to_send)
    else
        for i = 1, #to_send do table.insert(pending_trades, to_send[i]) end
    end
    syncing_busy = false
end

local function poll_remote_commands()
    if cfg.api_key == '' then return end
    local data = http_get('/api/sync/commands/pop')
    if data and data.success and data.command and data.command ~= '' then
        local cmd = tostring(data.command)
        pcall(function() sampSendChat(cmd, 1) end)
    end
end

local function refresh_arbitrage()
    if cfg.api_key == '' then arb_error = 'Нужен API ключ' return end
    arb_loading = true
    arb_error = ''
    local data = http_get('/api/sync/arbitrage')
    arb_loading = false
    if data and data.success then
        arb_data = data
        arb_last_load = os.time()
    else
        arb_error = (data and data.error) or 'Ошибка загрузки'
    end
end

-- Trade parsing (preserved with fixed encoding)
local function set_balance(num)
    num = tonumber((num)) or 0
    if num < 0 then num = 0 end
    current_balance = math.floor(num)
    balance_known = true
end

local function parse_num(s)
    if not s then return 0 end
    local cleaned = tostring(s):gsub('[%s%. ]', '')
    return tonumber((cleaned)) or 0
end

local CP_BUY_WORD  = string.char(0xEA, 0xF3, 0xEF, 0xE8, 0xEB, 0xE8)
local CP_SELL_WORD = string.char(0xEF, 0xF0, 0xEE, 0xE4, 0xE0, 0xEB, 0xE8)
local CP_SHT_WORD  = string.char(0xF8, 0xF2)

local function strip_chat_markup(s)
    return tostring(s or ''):gsub('{%x%x%x%x%x%x}', ''):gsub('\194\160', ' ')
end

local function trim(s)
    return tostring(s or ''):match('^%s*(.-)%s*$')
end

local function append_trade(trade)
    table.insert(pending_trades, trade)
    trades_captured = trades_captured + 1
end

local function append_parsed_trade(action, item, qty, price, total, currency)
    qty   = tonumber((qty)) or 1
    price = parse_num(price)
    total = parse_num(total)
    if total == 0 then total = qty * price end
    local clean_item = trim(item)
    if clean_item == '' then clean_item = 'Unknown' end
    append_trade({
        action   = action,
        item     = clean_item,
        quantity = qty,
        count    = qty,
        price    = price,
        total    = total,
        currency = currency or '',
        nick     = get_player_nick(),
        type     = action,
        ts       = os.date('%Y-%m-%d %H:%M:%S')
    })
end

local function is_trade_noise(msg)
    if type(msg) ~= 'string' then return false end
    local s = safe_u8(strip_chat_markup(msg))
    local low = s:lower()
    if low:find('tradelog') then return true end
    if low:find('покупка') then return true end
    if low:find('продажа') then return true end
    if low:find('итого') then return true end
    if low:find('вы успешно купили') then return true end
    if low:find('вы успешно продали') then return true end
    if low:find('вам был добавлен предмет') then return true end
    if low:find('вы купили') then return true end
    if low:find('вы приобрели') then return true end
    if low:find('вы продали') then return true end
    if low:find('игрок купил у вас') then return true end
    if low:find('купил у вас') then return true end
    return false
end

local function try_parse_trade_raw(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    msg = strip_chat_markup(msg)

    do
        local item, qty, price = msg:match('%[sell%] (.+) x(%d+) | (%d+) VC%$')
        if item then
            append_parsed_trade('sell', safe_u8(item), qty, price, tonumber((qty)) * parse_num(price), 'VC$')
            return true
        end
        item, qty, price = msg:match('%[buy%] (.+) x(%d+) | (%d+) VC%$')
        if item then
            append_parsed_trade('buy', safe_u8(item), qty, price, tonumber((qty)) * parse_num(price), 'VC$')
            return true
        end
    end

    local action
    if msg:find(CP_BUY_WORD, 1, true) then action = 'buy'
    elseif msg:find(CP_SELL_WORD, 1, true) then action = 'sell'
    else return false end

    local price_raw, currency
    local p_m  = msg:match(':M:%s*([%d%.]+)')
    local p_kk = msg:match(':KK:%s*([%d%.]+)')
    local p_k  = msg:match(':K:%s*([%d%.]+)')
    if p_m then price_raw = p_m; currency = 'M'
    elseif p_kk then price_raw = p_kk; currency = 'KK'
    elseif p_k then price_raw = p_k; currency = 'K'
    else
        price_raw = msg:match('([%d][%d%.%s]-)%s*$')
        currency = 'K'
    end
    if not price_raw or parse_num(price_raw) == 0 then return false end

    local qty = msg:match('%((%d+)%s+' .. CP_SHT_WORD .. '%.?%)')
            or msg:match('%((%d+)')
            or msg:match('[xXхХ](%d+)')
            or '1'

    local kword = (action == 'buy') and CP_BUY_WORD or CP_SELL_WORD
    local item_raw = msg:match(kword .. '%s+(.-)%s+%(%d')
                  or msg:match(kword .. '%s+(.-)%s+:K:')
                  or msg:match(kword .. '%s+(.-)%s+:M:')

    local item_utf8 = item_raw and safe_u8(item_raw) or 'Unknown'
    append_parsed_trade(action, item_utf8, qty, price_raw, tonumber((qty)) * parse_num(price_raw), currency)
    return true
end

local function try_parse_trade_from_chat(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    local item, qty, price, total

    item, qty, price = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber((qty)) * parse_num(price) end
        append_parsed_trade('buy', item, qty, price, total, '$')
        return true
    end

    item, qty, total = msg:match('[Вв]ы купили%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('[Вв]ы приобрели%s+(.-)%s+%((%d+)%s*[шШ][тТ]%.?%)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, price = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+по%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[Ии]того%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber((qty)) * parse_num(price) end
        append_parsed_trade('sell', item, qty, price, total, '$')
        return true
    end

    item, qty, total = msg:match('[Вв]ы продали%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('sell', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('[Ии]грок купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('купил у вас%s+(.-)%s+[xх](%d+)%s+за%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    return false
end

function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
end

function sampev.onServerMessage(color, msg)
    local ok, err = pcall(function()
        chat_seen = chat_seen + 1
        last_chat_message = tostring(msg or '')
        if is_trade_noise(msg) then return true end
        local decoded = safe_u8(strip_chat_markup(msg or ''))
        last_chat_message = decoded
        if try_parse_trade_raw(decoded)  then return true end
        if try_parse_trade_from_chat(decoded) then return true end
    end)
    if not ok then last_trade_error = tostring(err or '') end
end

function sampev.onResetPlayerMoney() return false end
function sampev.onGivePlayerMoney(money) return false end

-- ─── UI palette (matches Route66 site, frontend/static/css/landing.css) ────
local function rgb(r, g, b, a) return imgui.ImVec4(r / 255, g / 255, b / 255, a or 1.0) end

local C_BG          = rgb( 11,  15,  26)            -- #0B0F1A  page bg
local C_PANEL       = rgb( 18,  19,  28, 0.92)      -- topbar / content panel
local C_PANEL_SIDE  = rgb( 20,  18,  36, 0.95)      -- sidebar
local C_PANEL_INNER = rgb( 26,  21,  53, 0.85)      -- status block / cards
local C_BORDER      = rgb(200,  77, 255, 0.22)      -- subtle purple border
local C_BORDER_SOFT = rgb(255, 255, 255, 0.08)
local C_ACCENT      = rgb(200,  77, 255)            -- #C84DFF
local C_ACCENT_SOFT = rgb(200,  77, 255, 0.18)
local C_ACCENT_HOV  = rgb(200,  77, 255, 0.32)
local C_ACCENT_BRD  = rgb(200,  77, 255, 0.55)
local C_TEXT        = rgb(255, 255, 255)
local C_TEXT_DIM    = rgb(201, 209, 255, 0.72)      -- #C9D1FF dim
local C_TEXT_MUTE   = rgb(138, 144, 178)            -- #8A90B2
local C_GREEN       = rgb( 34, 227, 169)            -- #22E3A9
local C_RED         = rgb(255,  91, 122)
local C_AMBER       = rgb(251, 191,  36)            -- #FBBF24
local C_INDIGO      = rgb( 91,  95, 239)            -- #5B5FEF (logo accent)
local C_TRANS       = rgb(  0,   0,   0, 0)
local C_HOVER       = rgb(255, 255, 255, 0.06)

-- ─── UI layout constants ───────────────────────────────────────────────────
local WIN_W       = 1100
local WIN_H       = 680
local TOPBAR_H    = 60
local SIDEBAR_W   = 240
local PANEL_PAD   = 12
local PANEL_GAP   = 12

local TABS = {
    {id='arbitrage', label='Арбитраж',      title='Арбитраж',       desc='Лучшие связки покупка → скупка прямо сейчас'},
    {id='market',    label='Рынок',         title='Рынок',          desc='Все лоты по серверам Arizona Games'},
    {id='avg',       label='Средние цены',  title='Средние цены',   desc='Аналитика и история цен по предметам'},
    {id='top',       label='Топ сделки',    title='Топ сделок',     desc='Самые прибыльные сделки за период'},
    {id='settings',  label='Настройки',     title='Настройки',      desc='API ключ, адрес сервера и автоподключение'},
}

local function tab_meta(id)
    for _, t in ipairs(TABS) do if t.id == id then return t end end
    return TABS[1]
end

-- ─── Drawing primitives ────────────────────────────────────────────────────
-- All wrapped in pcall to survive mimgui builds that lack a particular method.
local function _u32(c) return imgui.ColorConvertFloat4ToU32(c) end
local function _alpha(c, a)
    return imgui.ImVec4(c.x, c.y, c.z, (c.w or 1) * a)
end
-- Soft pulse value in [lo..hi] driven by os.clock().
local function pulse(lo, hi, speed)
    local t = os.clock() * (speed or 2.0)
    local s = 0.5 + 0.5 * math.sin(t)
    return lo + (hi - lo) * s
end

-- Horizontal gradient fill (no rounding — use for full bars).
local function draw_gradient_h(dl, p1, p2, c_left, c_right)
    pcall(function()
        dl:AddRectFilledMultiColor(p1, p2,
            _u32(c_left), _u32(c_right), _u32(c_right), _u32(c_left))
    end)
end
-- Vertical gradient fill.
local function draw_gradient_v(dl, p1, p2, c_top, c_bottom)
    pcall(function()
        dl:AddRectFilledMultiColor(p1, p2,
            _u32(c_top), _u32(c_top), _u32(c_bottom), _u32(c_bottom))
    end)
end
-- Soft glow circle (multi-pass for fake blur).
local function draw_glow(dl, cx, cy, r, color, layers)
    layers = layers or 4
    pcall(function()
        for i = 1, layers do
            local k = i / layers
            dl:AddCircleFilled(imgui.ImVec2(cx, cy),
                r * (1 + k * 0.6),
                _u32(_alpha(color, 0.18 * (1 - k))), 24)
        end
    end)
end

-- Hexagonal brand logo (Route66 site style: stroked hex + "66" inside).
local function draw_brand_logo(size)
    size = size or 36
    pcall(function()
        local dl  = imgui.GetWindowDrawList()
        local pos = imgui.GetCursorScreenPos()
        local cx  = pos.x + size / 2
        local cy  = pos.y + size / 2
        local r_outer = size / 2 - 1
        local r_inner = size / 2 - 5

        -- Soft pulsing glow behind hex
        local glow_a = pulse(0.55, 1.0, 1.6)
        draw_glow(dl, cx, cy, r_outer * 0.55,
            _alpha(C_ACCENT, glow_a), 5)

        -- Outer hex (stroked)
        local accent_u32 = _u32(C_ACCENT)
        local inner_u32  = _u32(_alpha(C_ACCENT, 0.45))
        local function hex_stroke(r, color, thickness)
            for i = 0, 5 do
                local a1 = math.rad(-90 + i * 60)
                local a2 = math.rad(-90 + (i + 1) * 60)
                dl:AddLine(
                    imgui.ImVec2(cx + r * math.cos(a1), cy + r * math.sin(a1)),
                    imgui.ImVec2(cx + r * math.cos(a2), cy + r * math.sin(a2)),
                    color, thickness)
            end
        end
        hex_stroke(r_outer, accent_u32, 2.0)
        hex_stroke(r_inner, inner_u32, 1.0)

        -- "66" label centered
        local label = '66'
        local ts = imgui.CalcTextSize(label)
        dl:AddText(
            imgui.ImVec2(cx - ts.x / 2, cy - ts.y / 2),
            accent_u32, label)
    end)
    imgui.Dummy(imgui.ImVec2(size, size))
end

-- Custom status pill: rounded rect + colored dot + text label, drawn entirely
-- on the draw list so it works on any mimgui build without relying on text
-- glyphs like ● / ○ (which the loaded font doesn't always have → render as ?).
-- `dot_color` defaults to text color; pass `animate=true` for a pulsing dot+halo.
local function draw_status_pill(label, color, border_color, dot_color, animate)
    border_color = border_color or C_BORDER_SOFT
    dot_color    = dot_color    or color

    local pad_x   = 14
    local pad_y   = 6
    local dot_r   = 4
    local dot_gap = 9
    local ts      = imgui.CalcTextSize(label)
    local h       = pad_y * 2 + math.max(ts.y, dot_r * 2)
    local w       = pad_x + dot_r * 2 + dot_gap + ts.x + pad_x

    local pos = imgui.GetCursorScreenPos()
    local p1  = imgui.ImVec2(pos.x, pos.y)
    local p2  = imgui.ImVec2(pos.x + w, pos.y + h)
    local dl  = imgui.GetWindowDrawList()

    pcall(function()
        -- Rounded background
        dl:AddRectFilled(p1, p2, _u32(C_PANEL_INNER), h / 2)
        -- Subtle highlight gradient overlay (top→bottom)
        draw_gradient_v(dl, p1,
            imgui.ImVec2(p2.x, p1.y + h * 0.5),
            _alpha(C_TEXT, 0.04), C_TRANS)
        -- Border
        dl:AddRect(p1, p2, _u32(border_color), h / 2, 0, 1.0)

        -- Dot (with optional pulse + halo)
        local dx = pos.x + pad_x + dot_r
        local dy = pos.y + h / 2
        if animate then
            local a = pulse(0.5, 1.0, 3.0)
            draw_glow(dl, dx, dy, dot_r,
                _alpha(dot_color, 0.55 * a), 3)
            dl:AddCircleFilled(imgui.ImVec2(dx, dy), dot_r,
                _u32(_alpha(dot_color, a)), 16)
        else
            dl:AddCircleFilled(imgui.ImVec2(dx, dy), dot_r,
                _u32(dot_color), 16)
        end

        -- Text
        dl:AddText(
            imgui.ImVec2(pos.x + pad_x + dot_r * 2 + dot_gap,
                         pos.y + (h - ts.y) / 2),
            _u32(color), label)
    end)

    imgui.Dummy(imgui.ImVec2(w, h))
end

-- ─── Topbar ────────────────────────────────────────────────────────────────
local function draw_topbar()
    imgui.PushStyleColor(imgui.Col.ChildBg, C_PANEL)
    imgui.PushStyleColor(imgui.Col.Border,  C_BORDER_SOFT)
    safe_push_style_var(imgui.StyleVar.ChildRounding,  16.0)
    safe_push_style_var(imgui.StyleVar.ChildBorderSize, 1.0)
    safe_push_style_var(imgui.StyleVar.WindowPadding,   imgui.ImVec2(16, 10))
    imgui.BeginChild('topbar', imgui.ImVec2(0, TOPBAR_H), true)

    -- Animated gradient background (purple-tinted glow on the right edge)
    do
        local p_min = imgui.GetWindowPos()
        local size  = imgui.GetWindowSize()
        local p_max = imgui.ImVec2(p_min.x + size.x, p_min.y + size.y)
        local dl    = imgui.GetWindowDrawList()
        local glow_a = pulse(0.10, 0.18, 1.2)
        draw_gradient_h(dl, p_min, p_max,
            C_PANEL,
            rgb(123, 44, 255, glow_a))
        -- Subtle bottom hairline accent
        pcall(function()
            dl:AddLine(
                imgui.ImVec2(p_min.x + 8, p_max.y - 1),
                imgui.ImVec2(p_max.x - 8, p_max.y - 1),
                _u32(_alpha(C_ACCENT, 0.20)), 1.0)
        end)
    end

    -- Brand: hex logo + ROUTE66 / MARKET text block (matches site nav)
    local cy = imgui.GetCursorPosY()
    imgui.SetCursorPosY(cy + 2)
    draw_brand_logo(36)
    imgui.SameLine(0, 12)
    imgui.SetCursorPosY(cy + 4)
    imgui.BeginGroup()
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT)
    imgui.Text('ROUTE66')
    imgui.PopStyleColor()
    imgui.PushStyleColor(imgui.Col.Text, _alpha(C_ACCENT, 0.85))
    imgui.Text('MARKET')
    imgui.PopStyleColor()
    imgui.EndGroup()

    -- Right cluster: status pill + close button
    local right_w = 260
    imgui.SameLine(0, 0)
    local avail = imgui.GetContentRegionAvail().x
    imgui.SetCursorPosX(imgui.GetCursorPosX() + math.max(0, avail - right_w))
    imgui.SetCursorPosY(cy + 8)

    local pill_label, pill_color, pill_border, pill_dot, pill_anim
    if cfg.api_key == '' then
        pill_label, pill_color, pill_border = 'Не подключено', C_TEXT_MUTE, C_BORDER_SOFT
        pill_dot, pill_anim = C_TEXT_MUTE, false
    elseif sync_ok then
        pill_label, pill_color, pill_border = 'Подключено',    C_GREEN,     C_BORDER
        pill_dot, pill_anim = C_GREEN, false
    else
        pill_label, pill_color, pill_border = 'Подключение',   C_AMBER,     C_BORDER_SOFT
        pill_dot, pill_anim = C_AMBER, true
    end
    draw_status_pill(pill_label, pill_color, pill_border, pill_dot, pill_anim)

    imgui.SameLine(0, 10)
    imgui.SetCursorPosY(cy + 6)
    safe_push_style_var(imgui.StyleVar.FrameRounding, 999.0)
    safe_push_style_var(imgui.StyleVar.FrameBorderSize, 1.0)
    imgui.PushStyleColor(imgui.Col.Button,        C_PANEL_INNER)
    imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACCENT_SOFT)
    imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.Border,        C_BORDER_SOFT)
    imgui.PushStyleColor(imgui.Col.Text,          C_TEXT)
    if imgui.Button('  X  ##close', imgui.ImVec2(34, 30)) then
        wnd_open[0] = false
    end
    imgui.PopStyleColor(5)
    safe_pop_style_var(2)

    imgui.EndChild()
    safe_pop_style_var(3)
    imgui.PopStyleColor(2)
end

-- ─── Sidebar ───────────────────────────────────────────────────────────────
-- Custom nav button drawn entirely on the draw list:
--   • rounded background (gradient when active)
--   • left accent stripe with glow when active
--   • colored circle "dot" (filled when active, ringed when idle)
--   • text label
-- Uses InvisibleButton for hit-testing so we get hover/click states without
-- relying on imgui.Button's text rendering (which can't position our dot).
local function draw_nav_button(t)
    local sel    = (current_tab == t.id)
    local btn_h  = 38
    local pad_x  = 14
    local dot_r  = 4
    local dot_gap = 11

    local p_min  = imgui.GetCursorScreenPos()
    local avail  = imgui.GetContentRegionAvail().x
    local p_max  = imgui.ImVec2(p_min.x + avail, p_min.y + btn_h)

    -- Hit area
    local clicked = imgui.InvisibleButton('##nav_' .. t.id,
        imgui.ImVec2(avail, btn_h))
    local hovered = imgui.IsItemHovered()

    local dl = imgui.GetWindowDrawList()
    pcall(function()
        -- Background: gradient when selected, faint hover when hovered
        if sel then
            -- Soft purple gradient (left-bright → right-faded)
            draw_gradient_h(dl, p_min, p_max,
                _alpha(C_ACCENT, 0.28),
                _alpha(C_ACCENT, 0.08))
            dl:AddRectFilled(p_min, p_max, _u32(C_TRANS), 12.0)  -- noop, kept for symmetry
            dl:AddRect(p_min, p_max, _u32(C_ACCENT_BRD), 12.0, 0, 1.0)
            -- Left accent stripe (glowing)
            local stripe_x1 = p_min.x + 2
            local stripe_x2 = p_min.x + 5
            local stripe_y1 = p_min.y + 8
            local stripe_y2 = p_max.y - 8
            local glow_a = pulse(0.7, 1.0, 2.5)
            dl:AddRectFilled(
                imgui.ImVec2(stripe_x1, stripe_y1),
                imgui.ImVec2(stripe_x2, stripe_y2),
                _u32(_alpha(C_ACCENT, glow_a)), 2.0)
            -- soft glow around the stripe
            draw_glow(dl, (stripe_x1 + stripe_x2)/2, (stripe_y1 + stripe_y2)/2,
                4, _alpha(C_ACCENT, 0.35 * glow_a), 3)
        elseif hovered then
            dl:AddRectFilled(p_min, p_max, _u32(C_HOVER), 12.0)
        end

        -- Dot
        local dx = p_min.x + pad_x + dot_r
        local dy = p_min.y + btn_h / 2
        if sel then
            dl:AddCircleFilled(imgui.ImVec2(dx, dy), dot_r, _u32(C_ACCENT), 16)
        else
            dl:AddCircle(imgui.ImVec2(dx, dy), dot_r,
                _u32(_alpha(C_TEXT_MUTE, hovered and 0.9 or 0.55)), 16, 1.5)
        end

        -- Label text
        local ts = imgui.CalcTextSize(t.label)
        local tx = p_min.x + pad_x + dot_r * 2 + dot_gap
        local ty = p_min.y + (btn_h - ts.y) / 2
        local txt_color = sel and C_TEXT
            or (hovered and C_TEXT_DIM or _alpha(C_TEXT, 0.65))
        dl:AddText(imgui.ImVec2(tx, ty), _u32(txt_color), t.label)
    end)

    if clicked then
        current_tab = t.id
        if t.id == 'arbitrage' and (not arb_data or os.time() - arb_last_load > DATA_REFRESH_INTERVAL) then
            lua_thread.create(refresh_arbitrage)
        end
    end
end

local function draw_sidebar_status_row(label, value, value_color, border_color)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text(label)
    imgui.PopStyleColor()
    imgui.SameLine()
    local avail = imgui.GetContentRegionAvail().x
    -- New pill width: pad(14) + dot(8) + gap(9) + text + pad(14) ≈ text + 45
    local pill_w = imgui.CalcTextSize(value).x + 45
    imgui.SetCursorPosX(imgui.GetCursorPosX() + math.max(0, avail - pill_w))
    draw_status_pill(value, value_color or C_TEXT,
        border_color or C_BORDER_SOFT, value_color or C_TEXT, false)
end

local function draw_sidebar()
    imgui.PushStyleColor(imgui.Col.ChildBg, C_PANEL_SIDE)
    imgui.PushStyleColor(imgui.Col.Border,  C_BORDER_SOFT)
    safe_push_style_var(imgui.StyleVar.ChildRounding,  16.0)
    safe_push_style_var(imgui.StyleVar.ChildBorderSize, 1.0)
    safe_push_style_var(imgui.StyleVar.WindowPadding,   imgui.ImVec2(12, 12))
    safe_push_style_var(imgui.StyleVar.ItemSpacing,     imgui.ImVec2(8, 6))
    imgui.BeginChild('sidebar', imgui.ImVec2(SIDEBAR_W, 0), true)

    -- Section header
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_MUTE)
    imgui.Text('  НАВИГАЦИЯ')
    imgui.PopStyleColor()
    imgui.Spacing()

    for i, t in ipairs(TABS) do
        if t.id == 'settings' then
            imgui.Spacing()
            imgui.PushStyleColor(imgui.Col.Separator, C_BORDER_SOFT)
            imgui.Separator()
            imgui.PopStyleColor()
            imgui.Spacing()
        end
        draw_nav_button(t)
    end

    -- Status footer pinned to bottom
    local h = imgui.GetWindowHeight()
    local footer_h = 56
    local cur_y = imgui.GetCursorPosY()
    local target_y = h - footer_h - 12
    if target_y > cur_y then imgui.SetCursorPosY(target_y) end

    imgui.PushStyleColor(imgui.Col.ChildBg, C_PANEL_INNER)
    imgui.PushStyleColor(imgui.Col.Border,  C_BORDER_SOFT)
    safe_push_style_var(imgui.StyleVar.ChildRounding,  14.0)
    safe_push_style_var(imgui.StyleVar.WindowPadding,   imgui.ImVec2(12, 10))
    imgui.BeginChild('side_status', imgui.ImVec2(-1, footer_h), true)

    local online = (cfg.api_key ~= '' and sync_ok)
    draw_sidebar_status_row('Состояние',
        online and 'Online' or (cfg.api_key == '' and 'Нет ключа' or 'Offline'),
        online and C_GREEN or C_RED,
        online and C_BORDER or C_BORDER_SOFT)

    imgui.EndChild()
    safe_pop_style_var(2)
    imgui.PopStyleColor(2)

    imgui.EndChild()
    safe_pop_style_var(4)
    imgui.PopStyleColor(2)
end

-- ─── Content header ────────────────────────────────────────────────────────
local function tab_header(title, subtitle)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT)
    imgui.Text(title)
    imgui.PopStyleColor()
    if subtitle and subtitle ~= '' then
        imgui.PushStyleColor(imgui.Col.Text, C_TEXT_MUTE)
        imgui.Text(subtitle)
        imgui.PopStyleColor()
    end
    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Separator, C_BORDER_SOFT)
    imgui.Separator()
    imgui.PopStyleColor()
    imgui.Spacing()
end

-- Tracks which card the mouse hovered last frame (per index) so we can apply
-- a cosmetic glow/border on the *next* frame. We can't styling-condition a
-- BeginChild based on a hover state we haven't measured yet.
local _arb_hover = {}

local function draw_deal_card(i, d)
    local card_h    = 86
    local was_hover = _arb_hover[i] or false

    -- Use last frame's hover for the visual styling of *this* frame.
    local bg_color     = C_PANEL_INNER
    local border_color = was_hover and C_ACCENT_BRD or C_BORDER_SOFT

    imgui.PushStyleColor(imgui.Col.ChildBg, bg_color)
    imgui.PushStyleColor(imgui.Col.Border,  border_color)
    safe_push_style_var(imgui.StyleVar.ChildRounding,    14.0)
    safe_push_style_var(imgui.StyleVar.ChildBorderSize,   1.0)
    safe_push_style_var(imgui.StyleVar.WindowPadding,    imgui.ImVec2(16, 12))

    imgui.BeginChild('deal_' .. i, imgui.ImVec2(-1, card_h), true,
        imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoScrollWithMouse)

    -- Card overlay graphics (gradient + left accent stripe).
    local p_min = imgui.GetWindowPos()
    local size  = imgui.GetWindowSize()
    local p_max = imgui.ImVec2(p_min.x + size.x, p_min.y + size.y)
    local dl    = imgui.GetWindowDrawList()
    pcall(function()
        -- Soft purple highlight from the top
        draw_gradient_v(dl, p_min,
            imgui.ImVec2(p_max.x, p_min.y + size.y * 0.6),
            _alpha(C_ACCENT, was_hover and 0.10 or 0.05), C_TRANS)
        -- Left accent stripe (slightly brighter on hover)
        local stripe_a = was_hover and 0.85 or 0.55
        dl:AddRectFilled(
            imgui.ImVec2(p_min.x + 1, p_min.y + 14),
            imgui.ImVec2(p_min.x + 4, p_max.y - 14),
            _u32(_alpha(C_ACCENT, stripe_a)), 2.0)
    end)

    -- ─── Top row: lavka badge + item name ────────────────────────────────
    local lavka_label = '#' .. tostring(d.lavka_sell or '-')
    local pad         = 7
    local lp1         = imgui.GetCursorScreenPos()
    local lts         = imgui.CalcTextSize(lavka_label)
    local lw          = lts.x + pad * 2
    local lh          = lts.y + 4
    local lp2         = imgui.ImVec2(lp1.x + lw, lp1.y + lh)
    pcall(function()
        dl:AddRectFilled(lp1, lp2, _u32(_alpha(C_ACCENT, 0.20)), 6.0)
        dl:AddRect(lp1, lp2, _u32(C_ACCENT_BRD), 6.0, 0, 1.0)
        dl:AddText(imgui.ImVec2(lp1.x + pad, lp1.y + 2),
            _u32(C_ACCENT), lavka_label)
    end)
    imgui.Dummy(imgui.ImVec2(lw, lh))

    imgui.SameLine(0, 10)
    -- Slight vertical alignment fix so the item name sits next to the badge
    local cy = imgui.GetCursorPosY()
    imgui.SetCursorPosY(cy + 2)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT)
    imgui.Text(tostring(d.item_name or ''))
    imgui.PopStyleColor()

    -- ─── Bottom row: prices ───────────────────────────────────────────────
    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_MUTE)
    imgui.Text('Покупка')
    imgui.PopStyleColor()
    imgui.SameLine(0, 6)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT)
    imgui.Text(fmt_price(d.price_buy, d.buy_currency or 'SA$'))
    imgui.PopStyleColor()
    imgui.SameLine(0, 14)
    imgui.PushStyleColor(imgui.Col.Text, C_ACCENT)
    imgui.Text('→')
    imgui.PopStyleColor()
    imgui.SameLine(0, 14)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_MUTE)
    imgui.Text('Скупка')
    imgui.PopStyleColor()
    imgui.SameLine(0, 6)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT)
    imgui.Text(fmt_price(d.price_sell, d.sell_currency or 'VC$'))
    imgui.PopStyleColor()

    -- ─── Right side: profit + % + Найти button (absolute positioned) ─────
    local profit_text = '+' .. fmt_money(d.profit) .. ' ' .. (d.buy_currency or 'SA$')
    local pct_text    = string.format('%.1f %%', tonumber(d.profit_pct or 0))
    local profit_ts   = imgui.CalcTextSize(profit_text)
    local pct_ts      = imgui.CalcTextSize(pct_text)

    local right_pad = 14
    local btn_w     = 110
    local btn_h     = 26

    -- Profit number in top-right (large, green)
    imgui.SetCursorScreenPos(imgui.ImVec2(
        p_max.x - right_pad - profit_ts.x,
        p_min.y + 12))
    imgui.PushStyleColor(imgui.Col.Text, C_GREEN)
    imgui.Text(profit_text)
    imgui.PopStyleColor()

    -- Percent under profit (muted)
    imgui.SetCursorScreenPos(imgui.ImVec2(
        p_max.x - right_pad - pct_ts.x,
        p_min.y + 12 + profit_ts.y + 2))
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_MUTE)
    imgui.Text(pct_text)
    imgui.PopStyleColor()

    -- Найти-button bottom-right (rounded, accent style)
    imgui.SetCursorScreenPos(imgui.ImVec2(
        p_max.x - right_pad - btn_w,
        p_max.y - right_pad - btn_h + 6))
    safe_push_style_var(imgui.StyleVar.FrameRounding, 999.0)
    safe_push_style_var(imgui.StyleVar.FrameBorderSize, 1.0)
    imgui.PushStyleColor(imgui.Col.Button,        C_ACCENT_SOFT)
    imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.Border,        C_ACCENT_BRD)
    imgui.PushStyleColor(imgui.Col.Text,          C_TEXT)
    if imgui.Button('Найти лавку##find_' .. i, imgui.ImVec2(btn_w, btn_h)) then
        if d.lavka_sell then
            pcall(function()
                sampSendChat('/findilavka ' .. tostring(d.lavka_sell), 1)
            end)
        end
    end
    imgui.PopStyleColor(5)
    safe_pop_style_var(2)

    imgui.EndChild()

    -- Capture *this frame's* hover for the next frame's styling.
    _arb_hover[i] = imgui.IsItemHovered()

    safe_pop_style_var(3)
    imgui.PopStyleColor(2)
end

local function draw_arbitrage()
    local subtitle = ''
    if arb_data then
        local n = arb_data.deals and #arb_data.deals or 0
        subtitle = string.format('%d связок · %s → %s',
            n,
            arb_data.buy_name or '',
            arb_data.sell_name or '')
    else
        subtitle = 'Лучшие связки покупка → скупка прямо сейчас'
    end
    tab_header('Арбитраж', subtitle)

    -- Toolbar: refresh button + last updated timestamp
    safe_push_style_var(imgui.StyleVar.FrameRounding,   999.0)
    safe_push_style_var(imgui.StyleVar.FrameBorderSize, 1.0)
    imgui.PushStyleColor(imgui.Col.Button,        C_ACCENT_SOFT)
    imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.Border,        C_ACCENT_BRD)
    imgui.PushStyleColor(imgui.Col.Text,          C_TEXT)
    if imgui.Button(arb_loading and 'Загрузка...' or 'Обновить',
            imgui.ImVec2(130, 30)) and not arb_loading then
        lua_thread.create(refresh_arbitrage)
    end
    imgui.PopStyleColor(5)
    safe_pop_style_var(2)

    imgui.SameLine(0, 12)
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_MUTE)
    if arb_last_load > 0 then
        imgui.Text('Обновлено: ' .. os.date('%H:%M:%S', arb_last_load))
    else
        imgui.Text('Ещё не загружалось')
    end
    imgui.PopStyleColor()
    imgui.Spacing(); imgui.Spacing()

    if cfg.api_key == '' then
        imgui.PushStyleColor(imgui.Col.Text, C_RED)
        imgui.Text('Нужен API ключ. Откройте «Настройки».')
        imgui.PopStyleColor()
        return
    end

    if arb_error ~= '' then
        imgui.PushStyleColor(imgui.Col.Text, C_RED)
        imgui.Text('Ошибка: ' .. arb_error)
        imgui.PopStyleColor()
        return
    end

    if not arb_data or not arb_data.deals or #arb_data.deals == 0 then
        imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
        imgui.Text('Нет данных. Нажмите «Обновить».')
        imgui.PopStyleColor()
        return
    end

    -- Cards inside a scrollable child so the toolbar stays put.
    imgui.PushStyleColor(imgui.Col.ChildBg, C_TRANS)
    safe_push_style_var(imgui.StyleVar.WindowPadding, imgui.ImVec2(0, 0))
    safe_push_style_var(imgui.StyleVar.ItemSpacing,   imgui.ImVec2(0, 10))
    imgui.BeginChild('arb_cards', imgui.ImVec2(0, 0), false)
    for i, d in ipairs(arb_data.deals) do
        draw_deal_card(i, d)
    end
    imgui.EndChild()
    safe_pop_style_var(2)
    imgui.PopStyleColor()
end

local function draw_settings()
    tab_header('Настройки', 'API ключ и адрес сервера Road66')

    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('API ключ')
    imgui.PopStyleColor()
    imgui.PushItemWidth(-1)
    imgui.InputText('##apikey', inp_api_key, ffi.sizeof(inp_api_key) - 1)
    imgui.PopItemWidth()

    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('URL сервера')
    imgui.PopStyleColor()
    imgui.PushItemWidth(-1)
    imgui.InputText('##srvurl', inp_srv_url, ffi.sizeof(inp_srv_url) - 1)
    imgui.PopItemWidth()

    imgui.Spacing()
    imgui.PushStyleColor(imgui.Col.Button,        C_ACCENT_SOFT)
    imgui.PushStyleColor(imgui.Col.ButtonHovered, C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.ButtonActive,  C_ACCENT_HOV)
    imgui.PushStyleColor(imgui.Col.Text,          C_ACCENT)
    if imgui.Button('Сохранить и проверить подключение', imgui.ImVec2(-1, 32)) then
        cfg.api_key    = ffi.string(inp_api_key)
        cfg.server_url = ffi.string(inp_srv_url)
        if cfg.server_url == '' then cfg.server_url = 'http://localhost:5000' end
        cfg.server_url = cfg.server_url:gsub('/+$', '')
        save_cfg()
        sync_status_msg = 'Проверка подключения...'
        sync_ok = false
        lua_thread.create(test_connection)
    end
    imgui.PopStyleColor(4)

    imgui.Spacing(); imgui.Separator(); imgui.Spacing()

    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('Состояние')
    imgui.PopStyleColor()

    imgui.Text('Статус: ' .. (sync_status_msg ~= '' and sync_status_msg or 'Ожидание'))
    imgui.Text('Баланс: ' .. (balance_known and (fmt_money(current_balance) .. ' SA$') or '—'))
    imgui.Text('Сделок отправлено: ' .. tostring(trades_sent))
    imgui.Text('Сделок поймано: ' .. tostring(trades_captured))
    imgui.Text('В очереди: ' .. tostring(#pending_trades))
end

local function draw_placeholder(title)
    tab_header(title, 'Раздел в разработке')
    imgui.PushStyleColor(imgui.Col.Text, C_TEXT_DIM)
    imgui.Text('Скоро здесь появится тот же функционал, что и на сайте.')
    imgui.PopStyleColor()
end

local function draw_content()
    imgui.PushStyleColor(imgui.Col.ChildBg, C_PANEL)
    imgui.PushStyleColor(imgui.Col.Border,  C_BORDER_SOFT)
    safe_push_style_var(imgui.StyleVar.ChildRounding,  16.0)
    safe_push_style_var(imgui.StyleVar.ChildBorderSize, 1.0)
    safe_push_style_var(imgui.StyleVar.WindowPadding,   imgui.ImVec2(18, 16))
    imgui.BeginChild('content', imgui.ImVec2(0, 0), true)

    local meta = tab_meta(current_tab)
    tab_header(meta.title, meta.desc)

    if     current_tab == 'arbitrage' then draw_arbitrage()
    elseif current_tab == 'market'    then draw_placeholder('Рынок')
    elseif current_tab == 'avg'       then draw_placeholder('Средние цены')
    elseif current_tab == 'top'       then draw_placeholder('Топ сделок')
    elseif current_tab == 'settings'  then draw_settings()
    end

    imgui.EndChild()
    safe_pop_style_var(3)
    imgui.PopStyleColor(2)
end

local function draw_window()
    -- Always fullscreen: pin to (0, 0) at the game's full resolution every frame
    -- so the window can't drift/resize and the topbar can't ever scroll out.
    local sw, sh = 1280, 720
    pcall(function() sw, sh = getScreenResolution() end)
    imgui.SetNextWindowPos(imgui.ImVec2(0, 0), imgui.Cond.Always)
    imgui.SetNextWindowSize(imgui.ImVec2(sw, sh), imgui.Cond.Always)

    color_block_begin()
    safe_push_style_color('WindowBg',             C_BG)
    safe_push_style_color('Border',               C_BORDER_SOFT)
    safe_push_style_color('Text',                 C_TEXT)
    safe_push_style_color('FrameBg',              C_PANEL_INNER)
    safe_push_style_color('FrameBgHovered',       C_PANEL_INNER)
    safe_push_style_color('FrameBgActive',        C_PANEL_INNER)
    safe_push_style_color('TitleBg',              C_BG)
    safe_push_style_color('TitleBgActive',        C_BG)
    safe_push_style_color('TitleBgCollapsed',     C_BG)
    safe_push_style_color('ScrollbarBg',          C_TRANS)
    safe_push_style_color('ScrollbarGrab',        C_PANEL_INNER)
    safe_push_style_color('ScrollbarGrabHovered', C_ACCENT_SOFT)
    safe_push_style_color('ScrollbarGrabActive',  C_ACCENT_HOV)
    -- Table colors only exist on newer mimgui builds; skipped silently if missing.
    safe_push_style_color('TableBorderLight',     C_BORDER_SOFT)
    safe_push_style_color('TableBorderStrong',    C_BORDER_SOFT)
    safe_push_style_color('TableHeaderBg',        C_PANEL_INNER)
    safe_push_style_color('TableRowBg',           C_TRANS)
    safe_push_style_color('TableRowBgAlt',        C_HOVER)

    safe_push_style_var(imgui.StyleVar.WindowRounding,    18.0)
    safe_push_style_var(imgui.StyleVar.WindowBorderSize,   1.0)
    safe_push_style_var(imgui.StyleVar.WindowPadding,     imgui.ImVec2(PANEL_PAD, PANEL_PAD))
    safe_push_style_var(imgui.StyleVar.ItemSpacing,       imgui.ImVec2(PANEL_GAP, PANEL_GAP))
    safe_push_style_var(imgui.StyleVar.FrameRounding,     12.0)
    safe_push_style_var(imgui.StyleVar.ScrollbarRounding, 999.0)
    safe_push_style_var(imgui.StyleVar.ScrollbarSize,     10.0)

    -- Fullscreen + NoMove/NoResize/NoScroll keeps the topbar pinned at the top.
    -- Only the inner 'content' child scrolls when its body overflows.
    imgui.Begin('Road66##road66', wnd_open,
        imgui.WindowFlags.NoTitleBar
            + imgui.WindowFlags.NoCollapse
            + imgui.WindowFlags.NoMove
            + imgui.WindowFlags.NoResize
            + imgui.WindowFlags.NoBringToFrontOnFocus
            + imgui.WindowFlags.NoScrollbar
            + imgui.WindowFlags.NoScrollWithMouse)

    -- ESC closes the window
    if imgui.IsKeyPressed(0x1B) then wnd_open[0] = false end

    draw_topbar()
    draw_sidebar()
    imgui.SameLine()
    draw_content()

    imgui.End()
    safe_pop_style_var(7)
    color_block_end()
end

imgui.OnFrame(function() return wnd_open[0] end, function() draw_window() end)

local function cmd_r66()
    ffi.copy(inp_api_key, cfg.api_key)
    ffi.copy(inp_srv_url, cfg.server_url ~= '' and cfg.server_url or 'http://localhost:5000')
    wnd_open[0] = not wnd_open[0]
end

function main()
    repeat wait(250) until isSampAvailable()
    load_cfg()
    -- Spin up the HTTP worker thread early so the first real request
    -- doesn't pay the LuaSocket/LuaSec init cost on the main thread.
    pcall(_ensure_http_worker)

    -- Auto-connect: if an API key was saved on a previous launch, ping the
    -- server right away so the user doesn't have to open Settings every time.
    if cfg.api_key ~= '' then
        sync_status_msg = 'Автоподключение...'
        sync_ok = false
        lua_thread.create(function()
            wait(500)  -- let SAMP and the worker fully settle
            test_connection()
            -- Trigger an immediate background refresh of the arbitrage tab
            -- so it has data ready by the time the user opens the window.
            if sync_ok then refresh_arbitrage() end
        end)
    end

    sampRegisterChatCommand('r66', cmd_r66)

    while true do
        wait(1000)
        local now = os.time()

        if now - last_sync_time >= SYNC_INTERVAL and cfg.api_key ~= '' then
            last_sync_time = now
            lua_thread.create(sync_balance)
        end

        if #pending_trades > 0 and cfg.api_key ~= '' and now - last_trade_send >= TRADE_SEND_INTERVAL then
            last_trade_send = now
            lua_thread.create(sync_pending_trades)
        end

        if now - last_cmd_poll >= CMD_POLL_INTERVAL and cfg.api_key ~= '' then
            last_cmd_poll = now
            lua_thread.create(poll_remote_commands)
        end

        if wnd_open[0] and current_tab == 'arbitrage' and cfg.api_key ~= ''
           and arb_last_load > 0 and not arb_loading
           and now - arb_last_load >= DATA_REFRESH_INTERVAL then
            lua_thread.create(refresh_arbitrage)
        end
    end
end
