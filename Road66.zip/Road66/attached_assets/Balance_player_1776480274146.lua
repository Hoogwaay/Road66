script_name('Balance Monitor v1.6')
script_author('bakhusse + modified')
script_version('1.6')

require 'lib.moonloader'
local sampev = require 'samp.events'
local json = require 'dkjson'
local encoding = require 'encoding'

encoding.default = 'CP1251'
u8 = encoding.UTF8

-- ======================================================
-- Константы
-- ======================================================
local PREFIX = '{66CCFF}[Balance Monitor]{FFFFFF} '
local SAVE_FILE = getWorkingDirectory() .. '/balance_monitor.json'

local current_cash_money = 0
local current_cash_money_known = false
local updates_count = 0

-- ======================================================
-- Утилиты
-- ======================================================
local function chat(msg, color)
    if isSampAvailable() then
        sampAddChatMessage(PREFIX .. msg, color or -1)
    end
end

local function format_money(num)
    num = math.floor(tonumber(num) or 0)
    if num < 0 then num = 0 end
    local s = tostring(num)
    local r = s:reverse():gsub('(%d%d%d)', '%1 '):reverse()
    return r:gsub('^%s+', '')
end

-- ======================================================
-- ПРОСТОЙ JSON - ТОЛЬКО balance
-- ======================================================
local function save_balance_to_file()
    local data = {
        balance = current_cash_money
    }
    pcall(function()
        local file = io.open(SAVE_FILE, 'w')
        if file then
            file:write(json.encode(data))
            file:close()
        end
    end)
end

-- ======================================================
-- Строгий фильтр Наличные
-- ======================================================
local function is_player_balance_text(text)
    if type(text) ~= 'string' then return false end
    text = text:lower()
    return text:find('наличн') and (
        text:find('sa%$') or
        text:find('stats') or
        text:find('статистик')
    )
end

local function parse_part_value(value, scale)
    value = tostring(value or '')
    local whole, frac = value:match('^(%d+)%.(%d+)$')
    if whole then
        local base = tonumber(whole) or 0
        local decimals = tonumber(frac) or 0
        local factor = 10 ^ #frac
        return base * scale + math.floor(decimals * scale / factor)
    end
    return (tonumber(value) or 0) * scale
end

local function extract_player_balance_from_text(text)
    if not is_player_balance_text(text) then return nil end

    local total = 0
    local found = false

    for part in text:gmatch(':M:%s*([%d%.]+)') do
        total = total + parse_part_value(part, 1000000000)
        found = true
    end
    for part in text:gmatch(':KK:%s*([%d%.]+)') do
        total = total + parse_part_value(part, 1000000)
        found = true
    end
    for part in text:gmatch(':K:%s*([%d%.]+)') do
        total = total + parse_part_value(part, 1000)
        found = true
    end

    return found and total or nil
end

-- ======================================================
-- Безопасный CEF пакет 220
-- ======================================================
local function safe_raknet_read(bs, func)
    local ok, result = pcall(func, bs)
    return ok and result or nil
end

local add_handler = addEventHandler or registerHandler
if add_handler then
    add_handler('onReceivePacket', function(id, bs)
        if id ~= 220 then return end

        pcall(function()
            raknetBitStreamIgnoreBits(bs, 8)

            local packet_id = safe_raknet_read(bs, function() return raknetBitStreamReadInt8(bs) end)
            if packet_id ~= 17 then return end

            safe_raknet_read(bs, function() return raknetBitStreamReadInt32(bs) end)

            local text = safe_raknet_read(bs, function()
                local len = safe_raknet_read(bs, function() return raknetBitStreamReadInt16(bs) end)
                local enc = safe_raknet_read(bs, function() return raknetBitStreamReadInt8(bs) end)
                if len and len > 0 then
                    if enc == 0 then
                        return raknetBitStreamReadString(bs, len)
                    else
                        return raknetBitStreamDecodeString(bs, len + 1)
                    end
                end
                return ''
            end)

            if text and text:find('event.player.updateMoney') then
                local json_part = text:match("`(.*)`")
                if json_part then
                    local ok, decoded = pcall(json.decode, json_part)
                    if ok and type(decoded) == 'table' then
                        local money = tonumber(decoded[1])
                        if money and money >= 0 then
                            set_current_cash_money(money)
                        end
                    end
                end
            end
        end)
    end)
end

-- ======================================================
-- set_current_cash_money
-- ======================================================
function set_current_cash_money(num)
    num = tonumber(num) or 0
    if num < 0 then num = 0 end

    local old_balance = current_cash_money
    current_cash_money = math.floor(num)
    if not current_cash_money_known then
        current_cash_money_known = true
    end
    updates_count = updates_count + 1

    save_balance_to_file()

    if old_balance ~= current_cash_money then
        local time_str = os.date('%H:%M:%S')
        chat(u8:decode(('💰 [%d] %s: {FFDD00}$%s'):format(updates_count, time_str, format_money(current_cash_money))))
    end
end

-- ======================================================
-- Минимальные события
-- ======================================================
function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
    pcall(function()
        if is_player_balance_text(title or '') then
            local cash = extract_player_balance_from_text(title)
            if cash then set_current_cash_money(cash) end
        end
        if is_player_balance_text(text or '') then
            local cash = extract_player_balance_from_text(text)
            if cash then set_current_cash_money(cash) end
        end
    end)
end

function sampev.onResetPlayerMoney() return false end
function sampev.onGivePlayerMoney(money) return false end

-- ======================================================
-- Команда /balance
-- ======================================================
local function show_balance()
    local time_str = os.date('%H:%M:%S')

    if current_cash_money_known and current_cash_money > 0 then
        chat(u8:decode(('💰 %s: {FFDD00}$%s'):format(time_str, format_money(current_cash_money))))
        chat(u8:decode(('📁 ' .. SAVE_FILE)), 0xAAAAAA)
    else
        chat(u8:decode('⏳ /stats или Arizona HUD'), 0xAAAAAA)
    end
end

-- ======================================================
-- Главная функция
-- ======================================================
function main()
    repeat wait(250) until isSampAvailable()

    current_cash_money = 0
    current_cash_money_known = false
    updates_count = 0

    sampRegisterChatCommand('balance', show_balance)
    sampRegisterChatCommand('bal', show_balance)

    chat(u8:decode('🚀 Balance Monitor v1.6 — ПРОСТОЙ JSON!'))
    chat(u8:decode('📋 /balance — реальный баланс'))
    chat(u8:decode(('📁 ' .. SAVE_FILE)))

    while true do
        wait(15000)
        if current_cash_money_known then
            save_balance_to_file()
        end
    end
end