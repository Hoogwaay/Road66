script_name('Road66 Sync v1.0')
script_author('Road66 Market')
script_version('1.0')

require 'lib.moonloader'
local sampev   = require 'lib.samp.events'
local json     = require 'dkjson'
local imgui    = require 'mimgui'
local encoding = require 'encoding'
local requests = require 'requests'
local ffi      = require('ffi')

encoding.default = 'CP1251'
u8 = encoding.UTF8

local function safe_u8(s)
    if type(s) ~= 'string' or s == '' then return s or '' end
    local ok, result = pcall(function() return tostring(u8(s)) end)
    if ok and result and result ~= '' then return result end
    local ok2, result2 = pcall(function() return u8:decode(s) end)
    if ok2 and result2 and result2 ~= '' then return result2 end
    return s
end

local CFG_FILE = getWorkingDirectory() .. '/road66_config.json'
local SYNC_INTERVAL = 30
local TRADE_SEND_INTERVAL = 3

local cfg = {
    api_key = '',
    server_url = 'http://localhost:5000',
}

local current_balance   = 0
local balance_known     = false
local last_sync_time    = 0
local last_trade_send   = 0
local sync_ok           = false
local sync_status_msg   = ''
local pending_trades    = {}
local trades_sent       = 0
local chat_seen         = 0
local trades_captured   = 0
local last_chat_message = ''
local last_trade_error  = ''
local request_busy      = false
local syncing_busy      = false

local wnd_open    = imgui.new.bool(false)
local inp_api_key = imgui.new.char[128]('')
local inp_srv_url = imgui.new.char[256]('')

local function fmt_money(n)
    n = math.floor(tonumber(n) or 0)
    local s = tostring(n):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^%s+','')
    return '$' .. s
end

local function get_player_nick()
    local nick = 'Unknown'
    pcall(function()
        if sampGetPlayerNickname then
            nick = sampGetPlayerNickname() or 'Unknown'
        end
    end)
    return nick
end

local function load_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'r')
        if f then
            local ok, t = pcall(json.decode, f:read('*a'))
            f:close()
            if ok and type(t) == 'table' then
                cfg.api_key = t.api_key or ''
                cfg.server_url = t.server_url or 'http://localhost:5000'
            end
        end
    end)
end

local function save_cfg()
    pcall(function()
        local f = io.open(CFG_FILE, 'w')
        if f then
            f:write(json.encode({ api_key = cfg.api_key, server_url = cfg.server_url }))
            f:close()
        end
    end)
end

local function post_json(url, body_table)
    if request_busy then return nil end
    request_busy = true
    local ok, res = pcall(function()
        return requests.post(url, {
            headers = {
                ['Content-Type'] = 'application/json',
                ['X-API-Key'] = cfg.api_key,
            },
            data = json.encode(body_table),
            timeout = 8,
        })
    end)
    request_busy = false
    if ok and res then
        local status = res.status_code or 0
        local ok2, data = pcall(json.decode, res.text or '')
        return ok2 and data or { success = status >= 200 and status < 300 }
    end
    return nil
end

local function test_connection()
    if cfg.api_key == '' then
        sync_ok = false
        sync_status_msg = safe_u8('? ������� API ����')
        return
    end
    local data = post_json(cfg.server_url .. '/api/sync/ping', { api_key = cfg.api_key })
    if data and data.success then
        sync_ok = true
        sync_status_msg = safe_u8('? ����������')
    elseif data and data.error then
        sync_ok = false
        sync_status_msg = safe_u8('? ' .. tostring(data.error))
    else
        sync_ok = false
        sync_status_msg = safe_u8('? ��� ������ �� �������')
    end
end

local function sync_balance()
    if cfg.api_key == '' or not balance_known or syncing_busy then return end
    syncing_busy = true
    local data = post_json(cfg.server_url .. '/api/sync/balance', {
        api_key = cfg.api_key,
        balance = current_balance
    })
    syncing_busy = false
    if data and data.success then
        sync_ok = true
        sync_status_msg = safe_u8('? ������ ���������')
    else
        sync_ok = false
    end
end

local function sync_pending_trades()
    if cfg.api_key == '' or #pending_trades == 0 or syncing_busy then return end
    syncing_busy = true
    local to_send = {}
    for i = 1, #pending_trades do
        to_send[i] = pending_trades[i]
    end
    pending_trades = {}
    local data = post_json(cfg.server_url .. '/api/sync/trades', {
        api_key = cfg.api_key,
        trades = to_send
    })
    if data and data.success then
        trades_sent = trades_sent + (data.inserted or #to_send)
    else
        for i = 1, #to_send do
            table.insert(pending_trades, to_send[i])
        end
    end
    syncing_busy = false
end

local function set_balance(num)
    num = tonumber((num)) or 0
    if num < 0 then num = 0 end
    current_balance = math.floor(num)
    balance_known = true
end

local function parse_num(s)
    if not s then return 0 end
    local cleaned = tostring(s):gsub('[%s%. ]', '')
    return tonumber((cleaned)) or 0
end

local CP_BUY_WORD  = string.char(0xEA, 0xF3, 0xEF, 0xE8, 0xEB, 0xE8)
local CP_SELL_WORD = string.char(0xEF, 0xF0, 0xEE, 0xE4, 0xE0, 0xEB, 0xE8)
local CP_SHT_WORD  = string.char(0xF8, 0xF2)

local function strip_chat_markup(s)
    return tostring(s or ''):gsub('{%x%x%x%x%x%x}', ''):gsub('\194\160', ' ')
end

local function trim(s)
    return tostring(s or ''):match('^%s*(.-)%s*$')
end

local function append_trade(trade)
    table.insert(pending_trades, trade)
    trades_captured = trades_captured + 1
end

local function append_parsed_trade(action, item, qty, price, total, currency)
    qty = tonumber((qty)) or 1
    price = parse_num(price)
    total = parse_num(total)
    if total == 0 then total = qty * price end
    local clean_item = trim(item)
    if clean_item == '' then clean_item = 'Unknown' end
    append_trade({
        action = action,
        item = clean_item,
        quantity = qty,
        count = qty,
        price = price,
        total = total,
        currency = currency or '',
        nick = get_player_nick(),
        type = action,
        ts = os.date('%Y-%m-%d %H:%M:%S')
    })
end

local function is_trade_noise(msg)
    if type(msg) ~= 'string' then return false end
    local s = safe_u8(strip_chat_markup(msg))
    local low = s:lower()
    if low:find('tradelog') then return true end
    if low:find('�������') then return true end
    if low:find('�������') then return true end
    if low:find('�����') then return true end
    if low:find('�� ������� ������') then return true end
    if low:find('�� ������� �������') then return true end
    if low:find('��� ��� �������� �������') then return true end
    if low:find('�� ������') then return true end
    if low:find('�� ���������') then return true end
    if low:find('�� �������') then return true end
    if low:find('����� ����� � ���') then return true end
    if low:find('����� � ���') then return true end
    return false
end

local function try_parse_trade_raw(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    msg = strip_chat_markup(msg)

    do
        local item, qty, price = msg:match('%[sell%] (.+) x(%d+) | (%d+) VC%$')
        if item then
            append_parsed_trade('sell', safe_u8(item), qty, price, tonumber((qty)) * parse_num(price), 'VC$')
            return true
        end
        item, qty, price = msg:match('%[buy%] (.+) x(%d+) | (%d+) VC%$')
        if item then
            append_parsed_trade('buy', safe_u8(item), qty, price, tonumber((qty)) * parse_num(price), 'VC$')
            return true
        end
    end

    local action
    if msg:find(CP_BUY_WORD, 1, true) then action = 'buy'
    elseif msg:find(CP_SELL_WORD, 1, true) then action = 'sell'
    else return false end

    local price_raw, currency
    local p_m = msg:match(':M:%s*([%d%.]+)')
    local p_kk = msg:match(':KK:%s*([%d%.]+)')
    local p_k = msg:match(':K:%s*([%d%.]+)')
    if p_m then price_raw = p_m; currency = 'M'
    elseif p_kk then price_raw = p_kk; currency = 'KK'
    elseif p_k then price_raw = p_k; currency = 'K'
    else
        price_raw = msg:match('([%d][%d%.%s]-)%s*$')
        currency = 'K'
    end
    if not price_raw or parse_num(price_raw) == 0 then return false end

    local qty = msg:match('%((%d+)%s+' .. CP_SHT_WORD .. '%.?%)')
            or msg:match('%((%d+)')
            or msg:match('[xX��](%d+)')
            or '1'

    local kword = (action == 'buy') and CP_BUY_WORD or CP_SELL_WORD
    local item_raw = msg:match(kword .. '%s+(.-)%s+%(%d')
                  or msg:match(kword .. '%s+(.-)%s+:K:')
                  or msg:match(kword .. '%s+(.-)%s+:M:')
                  or msg:match(kword .. '%s+(.-)%s+%s�%s')

    local item_utf8 = item_raw and safe_u8(item_raw) or 'Unknown'
    append_parsed_trade(action, item_utf8, qty, price_raw, tonumber((qty)) * parse_num(price_raw), currency)
    return true
end

local function try_parse_trade_from_chat(msg)
    if type(msg) ~= 'string' or msg == '' then return false end
    local item, qty, price, total

    item, qty, price = msg:match('[��]� ������%s+(.-)%s+[x�](%d+)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[��]����%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber((qty)) * parse_num(price) end
        append_parsed_trade('buy', item, qty, price, total, '$')
        return true
    end

    item, qty, total = msg:match('[��]� ������%s+(.-)%s+[x�](%d+)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('[��]� ���������%s+(.-)%s+%((%d+)%s*[��][��]%.?%)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, price = msg:match('[��]� �������%s+(.-)%s+[x�](%d+)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local total_raw = msg:match('[��]����%s*:?%s*%$?([%d%s]+)')
        total = parse_num(total_raw)
        if total == 0 then total = tonumber((qty)) * parse_num(price) end
        append_parsed_trade('sell', item, qty, price, total, '$')
        return true
    end

    item, qty, total = msg:match('[��]� �������%s+(.-)%s+[x�](%d+)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('sell', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('[��]���� ����� � ���%s+(.-)%s+[x�](%d+)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    item, qty, total = msg:match('����� � ���%s+(.-)%s+[x�](%d+)%s+��%s+%$([%d%s]+)')
    if item and qty then
        local q = tonumber((qty)); local t = parse_num(total)
        append_parsed_trade('player_buy', item, q, (q > 0 and math.floor(t / q) or 0), t, '$')
        return true
    end

    return false
end

function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
    pcall(function()
        for _, s in ipairs({ title, text }) do
            if is_balance_text(s or '') then
                local cash = extract_balance(s)
                if cash then set_balance(cash) end
            end
        end
    end)
end

function sampev.onServerMessage(color, msg)
    local ok, err = pcall(function()
        chat_seen = chat_seen + 1
        last_chat_message = tostring(msg or '')

        if is_trade_noise(msg) then
            return true
        end

        local decoded = safe_u8(strip_chat_markup(msg or ''))
        last_chat_message = decoded

        if try_parse_trade_raw(decoded) then
            return true
        end

        if try_parse_trade_from_chat(decoded) then
            return true
        end
    end)
    if not ok then
        last_trade_error = tostring(err or '')
    end
end

function sampev.onResetPlayerMoney() return false end
function sampev.onGivePlayerMoney(money) return false end

local function imgui_window()
    imgui.SetNextWindowSize(imgui.ImVec2(480, 260), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(200, 200), imgui.Cond.FirstUseEver)

    imgui.Begin(u8('Road66 Sync v1.0'), wnd_open, imgui.WindowFlags.NoCollapse)

    imgui.Text(u8('Road66 Market � �������������'))
    imgui.Separator()

    imgui.Text(u8('������� ������:'))
    imgui.SameLine()
    if balance_known then
        imgui.Text(fmt_money(current_balance))
    else
        imgui.Text(u8('�'))
    end

    imgui.Text(sync_status_msg ~= '' and sync_status_msg or u8('�������� �������������...'))
    imgui.Text(u8('������ ����������: ') .. tostring(trades_sent))
    imgui.Text(u8('������ �������: ') .. tostring(trades_captured))
    imgui.Text(u8('� �������: ') .. tostring(#pending_trades))

    imgui.Separator()
    imgui.Text(u8('API ����:'))
    imgui.PushItemWidth(-1)
    imgui.InputText('##apikey', inp_api_key, ffi.sizeof(inp_api_key) - 1)
    imgui.PopItemWidth()

    imgui.Text(u8('URL �������:'))
    imgui.PushItemWidth(-1)
    imgui.InputText('##srvurl', inp_srv_url, ffi.sizeof(inp_srv_url) - 1)
    imgui.PopItemWidth()

    if imgui.Button(u8('  ��������� � ��������� �����������  '), imgui.ImVec2(-1, 30)) then
        cfg.api_key = ffi.string(inp_api_key)
        cfg.server_url = ffi.string(inp_srv_url)
        if cfg.server_url == '' then cfg.server_url = 'http://localhost:5000' end
        cfg.server_url = cfg.server_url:gsub('/+$', '')
        save_cfg()
        sync_status_msg = safe_u8('? �������� �����������...')
        sync_ok = false
        lua_thread.create(function()
            test_connection()
        end)
    end

    imgui.End()
end

imgui.OnFrame(function() return wnd_open[0] end, function() imgui_window() end)

local function cmd_r66()
    ffi.copy(inp_api_key, cfg.api_key)
    ffi.copy(inp_srv_url, cfg.server_url ~= '' and cfg.server_url or 'http://localhost:5000')
    wnd_open[0] = not wnd_open[0]
end

function main()
    repeat wait(250) until isSampAvailable()
    load_cfg()
    sampRegisterChatCommand('r66', cmd_r66)

    while true do
        wait(1000)
        local now = os.time()

        if now - last_sync_time >= SYNC_INTERVAL and cfg.api_key ~= '' then
            last_sync_time = now
            sync_balance()
        end

        if #pending_trades > 0 and cfg.api_key ~= '' and now - last_trade_send >= TRADE_SEND_INTERVAL then
            last_trade_send = now
            sync_pending_trades()
        end
    end
end