script_name("BalanceLogger")
script_author("Custom")
script_version("1.4")

require 'moonloader'
local sampev = require 'samp.events'

local WORK_DIR      = getWorkingDirectory()
local BALANCE_FILE  = WORK_DIR .. '\\player_balance.json'
local HISTORY_FILE  = WORK_DIR .. '\\market_history.json'

local gojson = nil
pcall(function() gojson = require 'gojson' end)

local function jsonVal(v)
    local t = type(v)
    if t == 'nil' then return 'null' end
    if t == 'boolean' then return tostring(v) end
    if t == 'number' then return tostring(v) end
    if t == 'string' then
        return '"' .. v:gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n'):gsub('\r','\\r') .. '"'
    end
    if t == 'table' then
        local parts = {}
        if #v > 0 then
            for _, item in ipairs(v) do
                parts[#parts + 1] = jsonVal(item)
            end
            return '[' .. table.concat(parts, ',') .. ']'
        else
            for k, item in pairs(v) do
                parts[#parts + 1] = '"' .. tostring(k) .. '":' .. jsonVal(item)
            end
            return '{' .. table.concat(parts, ',') .. '}'
        end
    end
    return 'null'
end

local function encodeJson(data)
    if gojson then
        local ok, result = pcall(gojson.encode, data)
        if ok then return result end
    end
    return jsonVal(data)
end

local function decodeJson(str)
    if not str or str == '' then return nil end
    if gojson then
        local ok, result = pcall(gojson.decode, str)
        if ok then return result end
    end
    return nil
end

local function readJsonFile(path)
    local f = io.open(path, 'r')
    if not f then return nil end
    local content = f:read('*a')
    f:close()
    return decodeJson(content)
end

local function writeJsonFile(path, data)
    local f = io.open(path, 'w')
    if not f then return end
    f:write(encodeJson(data))
    f:flush()
    f:close()
end

local function getSaMoney()
    local ok, char = pcall(PLAYER_PED)
    if ok and char then
        local res = raknetBitStreamReadInt32 and nil or nil
    end
    local ok2, money = pcall(getPlayerMoney)
    if ok2 and money then return money end
    return 0
end

local function saveBalance()
    if not isSampAvailable() then return end
    local money = getSaMoney()
    writeJsonFile(BALANCE_FILE, {
        balance = money,
        balance_fmt = tostring(money) .. ' SA$',
        updated = os.date('%Y-%m-%d %H:%M:%S')
    })
end

local function logDeal(action, item, count, price_each)
    local total = count * price_each
    local balance = isSampAvailable() and getSaMoney() or 0
    local history = readJsonFile(HISTORY_FILE)
    if type(history) ~= 'table' or type(history.deals) ~= 'table' then
        history = { deals = {} }
    end
    table.insert(history.deals, 1, {
        action = action,
        item = item,
        count = count,
        price_each = price_each,
        total = total,
        balance_after = balance,
        time = os.date('%Y-%m-%d %H:%M:%S'),
        timestamp = os.time()
    })
    while #history.deals > 1000 do
        table.remove(history.deals)
    end
    history.total_deals = #history.deals
    history.last_updated = os.date('%Y-%m-%d %H:%M:%S')
    writeJsonFile(HISTORY_FILE, history)
end

local BUY_PATTERNS = {
    { 'Вы купили (%d+) (.+) за (%d+) SA%$', 1, 2, 3 },
    { 'Вы купили: (.+) x(%d+) за (%d+)%$', 2, 1, 3 },
    { 'Покупка: (%d+)x (.+) %- (%d+) SA%$', 1, 2, 3 },
    { '[Лл]авка.*куплено (%d+) (.+) по (%d+) SA%$', 1, 2, 3 },
    { 'You bought (%d+) (.+) for (%d+)%$', 1, 2, 3 },
}

local SELL_PATTERNS = {
    { 'Вы продали (%d+) (.+) за (%d+) SA%$', 1, 2, 3 },
    { 'Вы продали: (.+) x(%d+) за (%d+)%$', 2, 1, 3 },
    { 'Продажа: (%d+)x (.+) %- (%d+) SA%$', 1, 2, 3 },
    { '[Лл]авка.*продано (%d+) (.+) по (%d+) SA%$', 1, 2, 3 },
    { 'You sold (%d+) (.+) for (%d+)%$', 1, 2, 3 },
}

local function tryMatchDeal(text)
    local function check(patterns, action)
        for _, p in ipairs(patterns) do
            local a, b, c = text:match(p[1])
            if a and b and c then
                local caps = { a, b, c }
                local count = tonumber(caps[p[2]])
                local item = caps[p[3]]:match('^%s*(.-)%s*$')
                local total = tonumber(caps[p[4]])
                if count and total and count > 0 then
                    logDeal(action, item, count, math.floor(total / count))
                    return true
                end
            end
        end
        return false
    end
    if not check(BUY_PATTERNS, 'buy') then
        check(SELL_PATTERNS, 'sell')
    end
end

function sampev.onServerMessage(color, text)
    if text and #text > 0 then
        tryMatchDeal(text)
        saveBalance()
    end
    return true
end

function sampev.onSendChat(message)
    if message == '/balancelog' then
        local history = readJsonFile(HISTORY_FILE)
        if not history or not history.deals or #history.deals == 0 then
            sampAddChatMessage('{FF6666}[BalanceLogger] История пуста.', -1)
        else
            sampAddChatMessage('{35CF0A}[BalanceLogger] Последние сделки (' .. #history.deals .. ' всего):', -1)
            for i = 1, math.min(10, #history.deals) do
                local d = history.deals[i]
                local col = (d.action == 'buy') and '{FF9900}' or '{35CF0A}'
                local sign = (d.action == 'buy') and '-' or '+'
                sampAddChatMessage(col .. '[' .. d.time .. '] ' .. string.upper(d.action) .. '  ' .. d.item .. '  x' .. d.count .. '  ' .. sign .. d.total .. ' SA$' .. '  (баланс: ' .. d.balance_after .. ')', -1)
            end
        end
        return false
    end
end

function main()
    while not isSampAvailable() do wait(500) end
    wait(1000)
    sampAddChatMessage('{35CF0A}[BalanceLogger] v1.4 запущен.', -1)
    saveBalance()
    while true do
        saveBalance()
        wait(5000)
    end
end