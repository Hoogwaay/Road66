"""
Arizona Scanner — Арбитраж сервер 18 (Casa Grande) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 18
SERVER_NAME = "Casa Grande"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 18 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
