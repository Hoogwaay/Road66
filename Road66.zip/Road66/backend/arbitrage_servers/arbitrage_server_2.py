"""
Arizona Scanner — Арбитраж сервер 2 (Tucson) → Сервер 0
Курс продажи: 1 VC$ = 156 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 2
SERVER_NAME = "Tucson"
SELL_RATE   = 156


def scan():
    """Запускает сканирование арбитража для сервера 2 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
