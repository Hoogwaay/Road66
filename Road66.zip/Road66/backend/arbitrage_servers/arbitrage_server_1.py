"""
Arizona Scanner — Арбитраж сервер 1 (Phoenix) → Сервер 0
Курс продажи: 1 VC$ = 112 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 1
SERVER_NAME = "Phoenix"
SELL_RATE   = 112


def scan():
    """Запускает сканирование арбитража для сервера 1 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
