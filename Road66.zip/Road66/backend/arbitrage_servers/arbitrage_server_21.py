"""
Arizona Scanner — Арбитраж сервер 21 (Queen Creek) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 21
SERVER_NAME = "Queen Creek"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 21 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
