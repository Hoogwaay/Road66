"""
Arizona Scanner — Арбитраж сервер 4 (Chandler) → Сервер 0
Курс продажи: 1 VC$ = 110 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 4
SERVER_NAME = "Chandler"
SELL_RATE   = 110


def scan():
    """Запускает сканирование арбитража для сервера 4 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
