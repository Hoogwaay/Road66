"""
Arizona Scanner — Арбитраж сервер 13 (Kingman) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 13
SERVER_NAME = "Kingman"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 13 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
