"""
Arizona Scanner — Арбитраж сервер 25 (Yava) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 25
SERVER_NAME = "Yava"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 25 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
