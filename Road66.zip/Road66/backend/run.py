#!/usr/bin/env python3
"""
Arizona Scanner v3.0 — Launcher
Главный файл для запуска приложения
"""

import sys
import os

if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(__file__))
    from app import app

    print("🚀 Arizona Scanner v3.0 запускается...")
    print("📊 Веб-интерфейс: http://localhost:5000")
    print("🔄 Автоскан сделок включен")
    print("💰 Автоарбитраж включен")
    print("\nДля остановки нажми CTRL+C\n")

    app.run(host="0.0.0.0", port=5000, debug=False)
