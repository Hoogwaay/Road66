"""
Arizona Scanner — Arbitrage Engine
"""

import requests
import time
from collections import defaultdict

MARKETPLACE_URL = "https://api.arz.market/api/getSelectedMarketplace/-1"
ITEMS_URL = "https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items"
SELL_COMMISSION = 0.91
EXCLUDE_WORDS = ["maketbones"]

_lavki_cache = None
_lavki_cache_time = 0
_items_cache = None
_items_cache_time = 0
CACHE_TTL = 60


def fetch_lavki():
    global _lavki_cache, _lavki_cache_time
    now = time.time()
    if _lavki_cache and (now - _lavki_cache_time) < CACHE_TTL:
        return _lavki_cache
    try:
        resp = requests.get(MARKETPLACE_URL, timeout=20)
        resp.raise_for_status()
        _lavki_cache = resp.json()
        _lavki_cache_time = now
        return _lavki_cache
    except Exception:
        return _lavki_cache or []


def fetch_items_db():
    global _items_cache, _items_cache_time
    now = time.time()
    if _items_cache and (now - _items_cache_time) < CACHE_TTL * 5:
        return _items_cache
    try:
        resp = requests.get(ITEMS_URL, timeout=15)
        resp.raise_for_status()
        _items_cache = {int(item['id']): item['name'] for item in resp.json()}
        _items_cache_time = now
        return _items_cache
    except Exception:
        return _items_cache or {}


def _calc_profit(buy_price, sell_price, buy_server_id, sell_server_id, buy_info, sell_info,
                 commission=None):
    """
    Calculate profit based on server pair.

    Prices from the API are raw (VC$ on server 0, SA$ on servers 1-32).

    N→0  (SA → Vice City):  profit_sa = sell_vc  * comm * buy_sell_rate  - buy_sa
    0→N  (Vice City → SA):  profit_vc = sell_sa  * comm / sell_buy_rate  - buy_vc
    N→M  (SA → SA):         profit_sa = (sell_sa * comm / sell_buy_rate) * buy_sell_rate - buy_sa
    0→0  (VC → VC):         profit_vc = sell_vc  * comm - buy_vc
    """
    if commission is None:
        commission = SELL_COMMISSION
    is_buy_vc  = (buy_server_id  == 0)
    is_sell_vc = (sell_server_id == 0)
    buy_sr     = buy_info.get('sell_rate', 1)   # SA$ per VC$ when selling VC$ on buy server
    sell_br    = sell_info.get('buy_rate',  1)  # SA$ per VC$ when buying  VC$ on sell server

    if is_buy_vc and is_sell_vc:
        profit       = sell_price * commission - buy_price
        buy_currency = 'VC$'
    elif not is_buy_vc and is_sell_vc:
        profit       = sell_price * commission * buy_sr - buy_price
        buy_currency = 'SA$'
    elif is_buy_vc and not is_sell_vc:
        profit       = sell_price * commission / sell_br - buy_price
        buy_currency = 'VC$'
    else:
        profit       = (sell_price * commission / sell_br) * buy_sr - buy_price
        buy_currency = 'SA$'

    profit_pct    = round(profit / buy_price * 100, 1) if buy_price > 0 else 0
    sell_currency = 'VC$' if is_sell_vc else 'SA$'
    return profit, profit_pct, buy_currency, sell_currency


def scan_arbitrage_for_server(buy_server_id: int, sell_server_id: int, currency_rates: dict) -> dict:
    """
    Ищет арбитражные сделки: купить на buy_server_id, продать на sell_server_id.
    """
    try:
        lavki    = fetch_lavki()
        items_db = fetch_items_db()

        if not lavki:
            return {'deals': [], 'status': '❌ Нет данных от API', 'last_update': None}

        buy_info  = currency_rates.get(buy_server_id,  {'buy_rate': 1, 'sell_rate': 1})
        sell_info = currency_rates.get(sell_server_id, {'buy_rate': 1, 'sell_rate': 1})

        buy_map  = {l['LavkaUid']: l for l in lavki if l.get('serverId') == buy_server_id}
        sell_map = {l['LavkaUid']: l for l in lavki if l.get('serverId') == sell_server_id}

        if not buy_map:
            return {'deals': [], 'status': f'❌ Нет лавок на сервере {buy_server_id}', 'last_update': None}
        if not sell_map:
            return {'deals': [], 'status': f'❌ Нет скупщиков на сервере {sell_server_id}', 'last_update': None}

        item_sell_lavka_count = defaultdict(set)
        best_sell_prices = {}
        for lavka_uid, data in sell_map.items():
            if not data.get('items_buy') or not data.get('price_buy'):
                continue
            for idx, item_id in enumerate(data['items_buy']):
                try:
                    price = float(data['price_buy'][idx])
                    count = data['count_buy'][idx]
                    item_sell_lavka_count[item_id].add(lavka_uid)
                    if item_id not in best_sell_prices or price > best_sell_prices[item_id][0]:
                        best_sell_prices[item_id] = (price, lavka_uid, count)
                except Exception:
                    continue

        opportunities = []

        for item_id, (best_sell_price, best_sell_lavka, best_sell_count) in best_sell_prices.items():
            item_name = items_db.get(item_id, f"ID_{item_id}")
            if any(w in item_name.lower() for w in EXCLUDE_WORDS):
                continue

            for buy_lavka_uid, buy_data in buy_map.items():
                if not buy_data.get('items_sell') or not buy_data.get('price_sell'):
                    continue

                for buy_idx, buy_item_id in enumerate(buy_data['items_sell']):
                    if buy_item_id != item_id:
                        continue
                    try:
                        buy_price = float(buy_data['price_sell'][buy_idx])
                        buy_count = int(buy_data['count_sell'][buy_idx])

                        profit, profit_pct, buy_currency, sell_currency = _calc_profit(
                            buy_price, best_sell_price,
                            buy_server_id, sell_server_id,
                            buy_info, sell_info
                        )

                        if profit > 0:
                            qty = min(buy_count, best_sell_count)
                            opportunities.append({
                                'lavka_buy':        buy_lavka_uid,
                                'lavka_sell':       best_sell_lavka,
                                'item':             item_name,
                                'item_id':          item_id,
                                'price_buy':        int(buy_price),
                                'price_sell':       int(best_sell_price),
                                'profit':           int(profit),
                                'profit_pct':       profit_pct,
                                'total_profit':     int(profit * qty),
                                'count_buy':        qty,
                                'sell_lavka_count': len(item_sell_lavka_count[item_id]),
                                'buy_currency':     buy_currency,
                                'sell_currency':    sell_currency,
                            })
                    except Exception:
                        continue

        deals = sorted(opportunities, key=lambda x: x['total_profit'], reverse=True)
        return {
            'deals':       deals,
            'status':      f'✅ {len(deals)} сделок',
            'last_update': time.strftime('%H:%M:%S'),
            'timestamp':   int(time.time()),
        }

    except Exception as e:
        return {
            'deals':       [],
            'status':      f'❌ {str(e)}',
            'last_update': time.strftime('%H:%M:%S'),
        }


def scan_best_deals(currency_rates: dict):
    """
    Ищет лучшую цену покупки и лучшую цену скупки по ВСЕМ серверам.
    Сравнение ведётся в VC$ (общая валюта).
    """
    try:
        lavki    = fetch_lavki()
        items_db = fetch_items_db()

        # best_buy_price[item_id]  = (vc_equiv, raw_price, lavka_uid, server_id, sell_rate, count)
        # best_sell_price[item_id] = (effective_vc, raw_price, lavka_uid, server_id, buy_rate, count)
        best_buy_price  = {}
        best_sell_price = {}

        for l in lavki:
            server_id = l.get('serverId')
            lavka_uid = l.get('LavkaUid')
            rate_info = currency_rates.get(server_id, {'buy_rate': 1, 'sell_rate': 1})
            sell_rate = rate_info.get('sell_rate', 1)
            buy_rate  = rate_info.get('buy_rate',  1)
            is_vc     = (server_id == 0)

            if l.get('items_sell') and l.get('price_sell') and l.get('count_sell'):
                for idx, raw_id in enumerate(l['items_sell']):
                    try:
                        iid   = raw_id if isinstance(raw_id, int) else int(str(raw_id).split('(')[0])
                        price = float(l['price_sell'][idx])
                        count = int(l['count_sell'][idx])
                        vc_equiv = price if is_vc else price / sell_rate
                        if iid not in best_buy_price or vc_equiv < best_buy_price[iid][0]:
                            best_buy_price[iid] = (vc_equiv, price, lavka_uid, server_id, sell_rate, count)
                    except Exception:
                        continue

            if l.get('items_buy') and l.get('price_buy') and l.get('count_buy'):
                for idx, raw_id in enumerate(l['items_buy']):
                    try:
                        iid   = raw_id if isinstance(raw_id, int) else int(str(raw_id).split('(')[0])
                        price = float(l['price_buy'][idx])
                        count = int(l['count_buy'][idx])
                        effective_vc = price * SELL_COMMISSION if is_vc else price * SELL_COMMISSION / buy_rate
                        if iid not in best_sell_price or effective_vc > best_sell_price[iid][0]:
                            best_sell_price[iid] = (effective_vc, price, lavka_uid, server_id, buy_rate, count)
                    except Exception:
                        continue

        deals = []
        for item_id, (buy_vc, buy_raw, buy_lavka, buy_server, buy_sr, buy_count) in best_buy_price.items():
            if item_id not in best_sell_price:
                continue
            item_name = items_db.get(item_id, f"ID_{item_id}")
            if any(w in item_name.lower() for w in EXCLUDE_WORDS):
                continue

            sell_vc, sell_raw, sell_lavka, sell_server, sell_br, sell_count = best_sell_price[item_id]
            profit_vc = sell_vc - buy_vc

            if profit_vc > 0:
                qty        = min(buy_count, sell_count)
                profit_pct = round(profit_vc / buy_vc * 100, 1) if buy_vc > 0 else 0
                deals.append({
                    'item':             item_name,
                    'item_id':          item_id,
                    'buy_server':       buy_server,
                    'sell_server':      sell_server,
                    'lavka_buy':        buy_lavka,
                    'lavka_sell':       sell_lavka,
                    'price_buy':        int(buy_raw),
                    'price_sell':       int(sell_raw),
                    'buy_currency':     'VC$' if buy_server  == 0 else 'SA$',
                    'sell_currency':    'VC$' if sell_server == 0 else 'SA$',
                    'profit_vc':        round(profit_vc, 2),
                    'profit_pct':       profit_pct,
                    'total_profit_vc':  round(profit_vc * qty, 2),
                    'count_buy':        qty,
                })

        deals.sort(key=lambda x: x['total_profit_vc'], reverse=True)
        return {
            'deals':       deals,
            'status':      f'✅ {len(deals)} лучших сделок',
            'last_update': time.strftime('%H:%M:%S'),
            'timestamp':   int(time.time()),
        }

    except Exception as e:
        return {
            'deals':       [],
            'status':      f'❌ {str(e)}',
            'last_update': time.strftime('%H:%M:%S'),
        }
