"""
🌌 Arizona Chatlog Scanner v3.0
Мониторит chatlog → генерирует inventory.json для основного сканера
"""

import os
import re
import json
import time
import glob
from collections import defaultdict
import threading

# ✅ ПУТИ (относительно папки проекта)
CHATLOG_FOLDER = r"C:\Users\sasha\Documents\GTA San Andreas User Files\SAMP\arizona\chatlog"
OUTPUT_JSON = "inventory.json"

state = {
    "current_file": None,
    "last_file_size": 0,
    "processed_lines": set(),
    "inventory": defaultdict(list)
}

# ✅ Паттерны покупок/продаж
buy_pattern = re.compile(
    r"\[(\d{2}:\d{2}:\d{2})\]\s+Вы успешно купили\s+(.+?)\s*\((\d+)\s*шт?\.\)\s+у\s+(.+?)\s+за\s+\$([\d,]+)",
    re.IGNORECASE)

sell_pattern = re.compile(
    r"\[(\d{2}:\d{2}:\d{2})\]\s+Вы успешно продали\s+(.+?)\s*\((\d+)\s*шт?\.\)\s+торговцу\s+(.+?),",
    re.IGNORECASE)


def safe_int(value):
    """Безопасное преобразование в int"""
    try:
        return int(str(value).replace(",", ""))
    except:
        return 0


def find_latest_file():
    """Находит последний chatlog файл"""
    files = glob.glob(os.path.join(CHATLOG_FOLDER, "*.txt"))
    return max(files, key=os.path.getmtime) if files else None


def add_purchase(item_name, qty, total_price, seller, dt_str):
    """Добавляет покупку в инвентарь"""
    qty = safe_int(qty)
    total_price = safe_int(total_price)
    price_per_unit = total_price // qty if qty > 0 else 0

    entry = {
        "qty": qty,
        "price_per_unit": price_per_unit,
        "seller": seller.strip(),
        "time": dt_str
    }
    state["inventory"][item_name].append(entry)
    print(f"🛒 +{qty} {item_name} за {total_price:,}$")


def apply_sale(item_name, qty, buyer, dt_str):
    """Вычитывает продажу из инвентаря"""
    qty = safe_int(qty)
    entries = state["inventory"].get(item_name, [])
    remaining = qty

    for entry in entries[:]:
        if remaining <= 0: break
        if entry.get("qty", 0) <= 0: continue
        take = min(entry["qty"], remaining)
        entry["qty"] -= take
        remaining -= take

    # Удаляем пустые записи
    state["inventory"][item_name] = [e for e in entries if e.get("qty", 0) > 0]
    print(f"💰 -{qty} {item_name}")


def scan_file():
    """Сканирует новый chatlog"""
    file_path = find_latest_file()
    if not file_path:
        return False

    # Новый файл - сбрасываем состояние
    if file_path != state["current_file"]:
        state["current_file"] = file_path
        state["last_file_size"] = os.path.getsize(file_path)
        state["processed_lines"] = set()
        print(f"\n📄 Новый файл: {os.path.basename(file_path)}")
        return True

    # Файл не изменился
    if os.path.getsize(file_path) == state["last_file_size"]:
        return False

    state["last_file_size"] = os.path.getsize(file_path)
    changed = False

    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
            recent_lines = lines[-50:]  # Проверяем последние 50 строк

        for line in recent_lines:
            raw = line.strip()
            if not raw or not raw.startswith("["):
                continue

            line_key = f"{file_path}:{hash(raw)}"
            if line_key in state["processed_lines"]:
                continue

            # 🛒 Покупка
            m_buy = buy_pattern.search(raw)
            if m_buy:
                dt_str, item_name, qty_str, seller, total_price_str = m_buy.groups()
                add_purchase(item_name.strip(), qty_str, total_price_str, seller.strip(), dt_str)
                state["processed_lines"].add(line_key)
                changed = True
                continue

            # 💰 Продажа
            m_sell = sell_pattern.search(raw)
            if m_sell:
                dt_str, item_name, qty_str, buyer = m_sell.groups()
                apply_sale(item_name.strip(), qty_str, buyer.strip(), dt_str)
                state["processed_lines"].add(line_key)
                changed = True
                continue

        if changed:
            save_json_state()
            show_inventory_summary()
        return changed

    except Exception as e:
        print(f"❌ Ошибка чтения: {e}")
        return False


def save_json_state():
    """Сохраняет инвентарь в inventory.json"""
    data = {}
    for item_name, entries in state["inventory"].items():
        item_qty = sum(e.get("qty", 0) for e in entries)
        if item_qty > 0:
            data[item_name] = {
                "qty": item_qty,
                "entries": entries
            }

    try:
        with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"💾 inventory.json обновлен ({len(data)} товаров)")
    except Exception as e:
        print(f"❌ Ошибка сохранения: {e}")


def show_inventory_summary():
    """Показывает краткую сводку инвентаря"""
    total_qty = 0
    active_items = 0
    for item_name, entries in state["inventory"].items():
        item_qty = sum(e.get("qty", 0) for e in entries)
        if item_qty > 0:
            print(f"  📦 {item_name}: {item_qty} шт")
            total_qty += item_qty
            active_items += 1

    print(f"📊 Всего: {active_items} товаров, {total_qty} шт")
    print("-" * 50)


def load_state():
    """Загружает состояние из inventory.json"""
    try:
        if os.path.exists(OUTPUT_JSON):
            with open(OUTPUT_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                for item_name, info in data.items():
                    state["inventory"][item_name] = info.get("entries", [])
            print(f"📂 Загружено {len(data)} товаров из inventory.json")
    except Exception as e:
        print(f"⚠️ Не удалось загрузить inventory.json: {e}")


def scanner_loop():
    """Основной цикл сканера"""
    print("🚀 Chatlog Scanner запущен (0.2 сек интервал)")
    print(f"📁 Мониторинг: {CHATLOG_FOLDER}")
    print(f"💾 Вывод: {OUTPUT_JSON}")

    while True:
        try:
            scan_file()
            time.sleep(0.2)
        except KeyboardInterrupt:
            print("\n🛑 Остановка...")
            save_json_state()
            show_inventory_summary()
            break
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            time.sleep(1)


def main():
    """Запуск сканера"""
    if not os.path.exists(CHATLOG_FOLDER):
        print(f"❌ Папка не найдена: {CHATLOG_FOLDER}")
        return

    load_state()
    show_inventory_summary()

    # Запуск в фоне + основной Flask
    scanner_thread = threading.Thread(target=scanner_loop, daemon=True)
    scanner_thread.start()

    print("\n🌌 Сканнер работает в фоне!")
    print("🔗 Основной сканер: http://127.0.0.1:5555")
    print("⏹️ Ctrl+C для остановки")

    # Держим процесс живым
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n👋 До свидания!")


if __name__ == "__main__":
    main()