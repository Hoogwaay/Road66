import requests
import threading
import time
import json
import os
import uuid
import string
import random
from collections import defaultdict
from datetime import datetime, date, timedelta
from functools import wraps
from flask import Flask, render_template, request, jsonify, make_response, session, redirect, url_for

from arbitrage_engine import scan_arbitrage_for_server, fetch_lavki, fetch_items_db, scan_best_deals, _calc_profit

app = Flask(__name__)
app.secret_key = 'route66-market-secret-key-2024'

INVENTORY_FILE   = "inventory.json"
BALANCE_FILE     = "balance.json"
CURRENCY_FILE    = "currencyrate.json"
CREDS_FILE       = "Data_Cred.json"
LOG_FILE         = "activity_log.json"
MAP_CACHE_FILE   = "arizona_map_cache.json"
TRASH_MAP_FILE   = "trash_map.json"
AVTOMARKET_FILE  = "avtomarket.json"
ITEMS_URL       = "https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items"
MARKETPLACE_URL = "https://api.arz.market/api/getSelectedMarketplace/-1"
SELL_COMMISSION = 0.91

PLAN_SCAN_COOLDOWN = {
    'free':  3600,
    'basic': 1800,
    'pro':   0,
}

# In-memory scan cooldown tracking: {username: timestamp}
scan_last_time     = {}
scan_last_time_lock = threading.Lock()


# ─── Currency rates ────────────────────────────────────────────────────────────

def load_currency_rates():
    try:
        with open(CURRENCY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return {s['id']: s for s in data['servers']}
    except Exception:
        return {}

CURRENCY_RATES = load_currency_rates()


# ─── Activity log ─────────────────────────────────────────────────────────────

def write_log(username, action, details=''):
    try:
        log = []
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                log = json.load(f)
        log.append({
            'time':     datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'username': username,
            'action':   action,
            'details':  details,
            'ip':       request.remote_addr if request else '',
        })
        log = log[-2000:]
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(log, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ─── Credentials ──────────────────────────────────────────────────────────────

def load_creds():
    try:
        with open(CREDS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'users': [], 'activation_codes': []}


def save_creds(creds):
    with open(CREDS_FILE, 'w', encoding='utf-8') as f:
        json.dump(creds, f, ensure_ascii=False, indent=2)


def get_user_from_session():
    username = session.get('username', '')
    if not username:
        return None
    creds = load_creds()
    return next((u for u in creds.get('users', []) if u.get('username') == username), None)


def get_effective_plan(user):
    if not user:
        return 'free'
    if user.get('role') == 'admin':
        return 'pro'
    plan = user.get('plan', 'free')
    expires = user.get('plan_expires')
    if plan in ('basic', 'pro') and expires:
        try:
            exp_dt = datetime.fromisoformat(expires)
            if datetime.now() > exp_dt:
                return 'free'
        except Exception:
            pass
    return plan


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect('/')
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return jsonify({'success': False, 'error': 'Not logged in'}), 401
        user = get_user_from_session()
        if not user or user.get('role') != 'admin':
            return jsonify({'success': False, 'error': 'Forbidden'}), 403
        return f(*args, **kwargs)
    return decorated


# ─── Scan cooldown helpers ────────────────────────────────────────────────────

def check_scan_cooldown(username, plan, scan_type='scanner'):
    cooldown = PLAN_SCAN_COOLDOWN.get(plan, 3600)
    if cooldown == 0:
        return True, 0
    key = f"{username}:{scan_type}"
    with scan_last_time_lock:
        last = scan_last_time.get(key, 0)
    elapsed = time.time() - last
    if elapsed >= cooldown:
        return True, 0
    remaining = int(cooldown - elapsed)
    return False, remaining


def mark_scan_done(username, scan_type='scanner'):
    key = f"{username}:{scan_type}"
    with scan_last_time_lock:
        scan_last_time[key] = time.time()


# ─── Arbitrage state (keyed by "buy_sell") ────────────────────────────────────

arb_cache      = {}
arb_cache_lock = threading.Lock()

bd_cache      = {'deals': [], 'status': 'Нажмите «Скан»', 'last_update': None, 'timestamp': None}
bd_cache_lock = threading.Lock()

def get_bd_state():
    with bd_cache_lock:
        return dict(bd_cache)

def set_bd_state(state):
    global bd_cache
    with bd_cache_lock:
        bd_cache = state

def arb_key(buy, sell):
    return f"{buy}_{sell}"

def get_arb_state(buy, sell):
    with arb_cache_lock:
        return dict(arb_cache.get(arb_key(buy, sell), {
            'deals': [], 'status': 'Нажмите «Скан»', 'last_update': None, 'timestamp': None
        }))

def set_arb_state(buy, sell, state):
    with arb_cache_lock:
        arb_cache[arb_key(buy, sell)] = state


# ─── Scanner state ────────────────────────────────────────────────────────────

scanner_data = None
scanner_lock = threading.Lock()

auto_scanner_running   = False
auto_arbitrage_running = False
auto_bd_running        = False
auto_arb_buy  = 2
auto_arb_sell = 0


# ─── Inventory ────────────────────────────────────────────────────────────────

def load_inventory():
    if not os.path.exists(INVENTORY_FILE):
        return {}
    try:
        with open(INVENTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def get_items_data_from_json():
    inventory = load_inventory()
    items_data = []
    for item_name, data in inventory.items():
        total_qty = data.get('qty', 0)
        entries   = data.get('entries', [])
        if total_qty <= 0 or not entries:
            continue
        total_cost = sum(e.get('qty', 0) * e.get('price_per_unit', 0) for e in entries)
        avg_price  = total_cost / total_qty if total_qty > 0 else 0
        min_sell   = min((e.get('price_per_unit', 0) for e in entries), default=0)
        min_sell   = int(min_sell * 1.1) if min_sell > 0 else 0
        items_data.append({
            'name':              item_name,
            'quantity':          total_qty,
            'buy_price':         int(total_cost),
            'buy_price_per_unit':int(avg_price),
            'min_sell_price':    min_sell,
            'entries':           entries,
        })
    return items_data


def get_inventory_summary():
    inventory = load_inventory()
    items_list, total_items, total_cost = [], 0, 0
    for item_name, data in inventory.items():
        qty = data.get('qty', 0)
        if qty > 0:
            cost = sum(e.get('qty', 0) * e.get('price_per_unit', 0) for e in data.get('entries', []))
            items_list.append({'name': item_name, 'qty': qty, 'total_cost': int(cost)})
            total_items += qty
            total_cost  += cost
    return {'items': items_list, 'total_items': total_items,
            'total_cost': int(total_cost), 'item_types': len(items_list)}


# ─── Balance ──────────────────────────────────────────────────────────────────

def load_balance():
    if not os.path.exists(BALANCE_FILE):
        return []
    try:
        with open(BALANCE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []

def save_balance(records):
    with open(BALANCE_FILE, 'w', encoding='utf-8') as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


# ─── Fetch helper ─────────────────────────────────────────────────────────────

def fetch_with_retry(url, retries=3, timeout=15):
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except Exception:
            pass
        if attempt < retries:
            time.sleep(min(2 ** attempt, 10))
    return []


# ─── Scanner ─────────────────────────────────────────────────────────────────

def scan_scanner():
    global scanner_data
    try:
        with scanner_lock:
            items_data_api = fetch_with_retry(ITEMS_URL, retries=3, timeout=20)
            lavki_data     = fetch_with_retry(MARKETPLACE_URL, retries=3, timeout=20)
            all_lavki      = [l for l in lavki_data if l.get('serverId') == 0]
            sheet_items    = get_items_data_from_json()

            def get_item_id_by_name(name, db):
                for item in db:
                    if item['name'].strip().lower() == name.strip().lower():
                        return item['id']
                return None

            def find_all_lavki_for_item(item_id, lavki):
                offers = []
                for lavka in lavki:
                    items_buy = lavka.get('items_buy', [])
                    price_buy = lavka.get('price_buy', [])
                    count_buy = lavka.get('count_buy', [])
                    for i, bid in enumerate(items_buy):
                        if (str(bid).split('(')[0] == str(item_id) and
                                i < len(price_buy) and i < len(count_buy) and count_buy[i] > 0):
                            offers.append({'lavka_uid': lavka['LavkaUid'],
                                           'price': price_buy[i], 'count': count_buy[i]})
                return sorted(offers, key=lambda x: x['price'], reverse=True)

            def calculate_profit(buy_price_sa_total, lavka_price_vc, quantity):
                buy_per_unit  = buy_price_sa_total // quantity if quantity > 0 else 0
                vc_after_comm = lavka_price_vc * SELL_COMMISSION
                sa_per_unit   = vc_after_comm * 107
                return int((sa_per_unit - buy_per_unit) * quantity)

            item_offers = []
            for json_item in sheet_items:
                item_id = get_item_id_by_name(json_item['name'], items_data_api)
                if item_id:
                    offers = find_all_lavki_for_item(item_id, all_lavki)
                    if offers:
                        best   = offers[0]
                        profit = calculate_profit(
                            json_item['buy_price'], best['price'], json_item['quantity'])
                        item_offers.append({
                            'name':              json_item['name'],
                            'quantity':          json_item['quantity'],
                            'buy_price':         json_item['buy_price'],
                            'buy_price_per_unit':json_item['buy_price_per_unit'],
                            'min_sell_price':    json_item['min_sell_price'],
                            'lavka_uid':         best['lavka_uid'],
                            'lavka_price':       best['price'],
                            'lavka_count':       best['count'],
                            'profit':            profit,
                            'entries':           json_item['entries'],
                        })

            lavka_item_groups = defaultdict(lambda: defaultdict(list))
            total_stats = {'total_profit': 0, 'total_items': 0,
                           'lavka_count': 0, 'item_groups': 0}
            for item in item_offers:
                lavka_item_groups[item['lavka_uid']][item['name']].append(item)
                total_stats['total_profit'] += item['profit']
                total_stats['total_items']  += 1

            total_stats['item_groups'] = sum(len(v) for v in lavka_item_groups.values())
            sorted_lavki = sorted(
                lavka_item_groups.items(),
                key=lambda x: max(i['lavka_price'] for items in x[1].values() for i in items),
                reverse=True)
            total_stats['lavka_count'] = len(sorted_lavki)
            scanner_data = (sorted_lavki, total_stats)
    except Exception:
        with scanner_lock:
            scanner_data = None


# ─── Arbitrage scan ───────────────────────────────────────────────────────────

def do_scan_arbitrage(buy_id, sell_id):
    set_arb_state(buy_id, sell_id, {
        'deals': [], 'status': '⏳ Сканирую...', 'last_update': None, 'timestamp': None
    })
    try:
        result = scan_arbitrage_for_server(buy_id, sell_id, CURRENCY_RATES)
        set_arb_state(buy_id, sell_id, result)
    except Exception as e:
        set_arb_state(buy_id, sell_id, {
            'deals': [], 'status': f'❌ {str(e)}', 'last_update': time.strftime('%H:%M:%S'), 'timestamp': None
        })


def do_scan_best_deals():
    set_bd_state({'deals': [], 'status': '⏳ Сканирую все серверы...', 'last_update': None, 'timestamp': None})
    try:
        result = scan_best_deals(CURRENCY_RATES)
        set_bd_state(result)
    except Exception as e:
        set_bd_state({'deals': [], 'status': f'❌ {str(e)}', 'last_update': time.strftime('%H:%M:%S'), 'timestamp': None})


# ─── Auto loops ───────────────────────────────────────────────────────────────

def auto_scanner_loop():
    global auto_scanner_running
    while auto_scanner_running:
        try:
            scan_scanner()
            time.sleep(30)
        except Exception:
            time.sleep(5)


def auto_arbitrage_loop():
    global auto_arbitrage_running
    while auto_arbitrage_running:
        try:
            do_scan_arbitrage(auto_arb_buy, auto_arb_sell)
            time.sleep(15)
        except Exception:
            time.sleep(5)


def auto_bd_loop():
    global auto_bd_running
    while auto_bd_running:
        try:
            do_scan_best_deals()
            time.sleep(30)
        except Exception:
            time.sleep(5)


# ─── Code generator ───────────────────────────────────────────────────────────

def generate_code():
    chars = string.ascii_uppercase + string.digits
    parts = [''.join(random.choices(chars, k=4)) for _ in range(4)]
    return '-'.join(parts)


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if session.get('logged_in'):
        return redirect('/panel')
    return render_template('landing.html')


@app.route("/panel")
@login_required
def panel():
    return render_template('index.html')


@app.route("/api/login", methods=["POST"])
def api_login():
    data     = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    ip       = request.remote_addr or ''
    creds    = load_creds()
    for user in creds.get('users', []):
        if user.get('username') == username and user.get('password') == password:
            if user.get('blocked', False):
                write_log(username, 'login_blocked', f'IP: {ip}')
                return jsonify({'success': False, 'error': 'Аккаунт заблокирован'})
            if not user.get('activated', True):
                write_log(username, 'login_not_activated', f'IP: {ip}')
                return jsonify({'success': False, 'error': 'Аккаунт не активирован. Обратитесь к администратору'})
            user['last_ip'] = ip
            save_creds(creds)
            session['logged_in'] = True
            session['username']  = username
            write_log(username, 'login', f'IP: {ip}')
            return jsonify({'success': True})
    write_log(username, 'login_fail', f'IP: {ip}')
    return jsonify({'success': False, 'error': 'Неверный логин или пароль'})


@app.route("/logout")
def logout():
    username = session.get('username', '')
    if username:
        write_log(username, 'logout')
    session.clear()
    return redirect('/')


@app.route("/api/activate", methods=["POST"])
@login_required
def api_activate():
    data     = request.json or {}
    code_val = data.get('code', '').strip().upper()
    if not code_val:
        return jsonify({'success': False, 'error': 'Код не указан'})
    username = session.get('username', '')
    creds    = load_creds()
    codes    = creds.get('activation_codes', [])
    found    = None
    for c in codes:
        if isinstance(c, dict):
            if c.get('code', '').upper() == code_val:
                found = c
                break
        elif isinstance(c, str):
            if c.upper() == code_val:
                found = {'code': c, 'plan': 'basic', 'duration_days': 30}
                break
    if not found:
        return jsonify({'success': False, 'error': 'Неверный или уже использованный код'})

    plan     = found.get('plan', 'basic')
    days     = found.get('duration_days', 30)
    expires  = (datetime.now() + timedelta(days=days)).isoformat()

    for user in creds.get('users', []):
        if user.get('username') == username:
            user['plan']         = plan
            user['plan_expires'] = expires
            break

    creds['activation_codes'] = [c for c in codes if
        (c.get('code', '').upper() if isinstance(c, dict) else c.upper()) != code_val]
    save_creds(creds)
    write_log(username, 'activate_code', f'code={code_val} plan={plan} days={days}')

    plan_names = {'free': 'Бесплатный', 'basic': 'Базовый', 'pro': 'Профи'}
    return jsonify({'success': True,
                    'message': f'Тариф «{plan_names.get(plan, plan)}» активирован на {days} дней!'})


@app.route("/api/me")
@login_required
def api_me():
    username = session.get('username', 'User')
    creds    = load_creds()
    user     = next((u for u in creds.get('users', []) if u.get('username') == username), None)
    if user:
        is_admin = user.get('role', '').lower() == 'admin'
        plan     = get_effective_plan(user)
        expires  = user.get('plan_expires')
        commission = user.get('commission', 9)
        user_server = user.get('user_server', 2)
        server_changed_at = user.get('server_changed_at')
    else:
        is_admin = False
        plan     = 'free'
        expires  = None
        commission = 9
        user_server = 2
        server_changed_at = None

    days_left = None
    if expires and not is_admin:
        try:
            exp_dt = datetime.fromisoformat(expires)
            days_left = max(0, (exp_dt - datetime.now()).days)
        except Exception:
            pass

    return jsonify({
        'success':          True,
        'username':         username,
        'is_admin':         is_admin,
        'plan':             plan,
        'plan_expires':     expires,
        'days_left':        days_left,
        'commission':       commission,
        'user_server':      user_server,
        'server_changed_at': server_changed_at,
    })


@app.route("/api/save_settings", methods=["POST"])
@login_required
def api_save_settings():
    data       = request.json or {}
    commission = data.get('commission')
    if commission is None:
        return jsonify({'success': False, 'error': 'Не указана комиссия'})
    try:
        commission = float(commission)
        if commission < 0 or commission > 100:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Некорректное значение'})

    username = session.get('username', '')
    creds    = load_creds()
    updated  = False
    for user in creds.get('users', []):
        if user.get('username') == username:
            user['commission'] = commission
            updated = True
            break
    if updated:
        try:
            save_creds(creds)
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': True})


@app.route("/api/save_server", methods=["POST"])
@login_required
def api_save_server():
    data      = request.json or {}
    server_id = data.get('server_id')
    if server_id is None:
        return jsonify({'success': False, 'error': 'Не указан сервер'})
    try:
        server_id = int(server_id)
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Некорректный сервер'})
    if server_id == 0:
        return jsonify({'success': False, 'error': 'Vice City нельзя выбрать как основной сервер'})

    username = session.get('username', '')
    creds    = load_creds()
    for user in creds.get('users', []):
        if user.get('username') == username:
            changed_at = user.get('server_changed_at')
            if changed_at:
                try:
                    last_change = datetime.fromisoformat(changed_at)
                    elapsed = (datetime.now() - last_change).total_seconds()
                    if elapsed < 21600:
                        remaining = int(21600 - elapsed)
                        h, m = divmod(remaining // 60, 60)
                        return jsonify({'success': False,
                                        'error': f'Сервер можно менять раз в 6 часов. Осталось {h}ч {m}м'})
                except Exception:
                    pass
            user['user_server']      = server_id
            user['server_changed_at'] = datetime.now().isoformat()
            save_creds(creds)
            write_log(username, 'server_change', f'server={server_id}')
            return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Пользователь не найден'})


@app.route("/api/register", methods=["POST"])
def api_register():
    data     = request.json or {}
    username = data.get('username', '').strip()
    email    = data.get('email', '').strip()
    password = data.get('password', '').strip()
    ip       = request.remote_addr or ''

    if not username or not email or not password:
        return jsonify({'success': False, 'error': 'Заполните все поля'})
    if len(username) < 3:
        return jsonify({'success': False, 'error': 'Логин минимум 3 символа'})
    if '@' not in email or '.' not in email.split('@')[-1]:
        return jsonify({'success': False, 'error': 'Некорректный email'})
    if len(password) < 6:
        return jsonify({'success': False, 'error': 'Пароль минимум 6 символов'})

    creds = load_creds()
    for u in creds.get('users', []):
        if u.get('username', '').lower() == username.lower():
            return jsonify({'success': False, 'error': 'Логин уже занят'})
        if u.get('email', '').lower() == email.lower():
            return jsonify({'success': False, 'error': 'Email уже используется'})

    new_user = {
        'username':         username,
        'email':            email,
        'password':         password,
        'role':             'user',
        'plan':             'free',
        'plan_expires':     None,
        'commission':       9,
        'user_server':      2,
        'reg_date':         datetime.now().isoformat(),
        'reg_ip':           ip,
        'last_ip':          ip,
        'server_changed_at': None,
        'activated':        True,
        'blocked':          False,
    }
    creds.setdefault('users', []).append(new_user)
    try:
        save_creds(creds)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

    write_log(username, 'register', f'email={email} IP={ip}')
    return jsonify({'success': True, 'email': email})


@app.route("/api/currency_rates")
def api_currency_rates():
    return jsonify({'success': True, 'rates': list(CURRENCY_RATES.values())})


@app.route("/api/scanner")
@login_required
def api_scanner():
    with scanner_lock:
        if scanner_data:
            return jsonify({'success': True, 'data': scanner_data})
        return jsonify({'success': False, 'error': 'Нет данных'})


@app.route("/api/arbitrage")
@login_required
def api_arbitrage():
    try:
        buy_id  = int(request.args.get('buy',  2))
        sell_id = int(request.args.get('sell', 0))
    except ValueError:
        buy_id, sell_id = 2, 0

    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))

    try:
        commission_pct = float(request.args.get('commission', 9))
        commission_pct = max(0.0, min(100.0, commission_pct))
    except (ValueError, TypeError):
        commission_pct = 9.0
    commission = (100.0 - commission_pct) / 100.0

    user = get_user_from_session()
    plan = get_effective_plan(user)

    state     = get_arb_state(buy_id, sell_id)
    buy_info  = CURRENCY_RATES.get(buy_id,  {})
    sell_info = CURRENCY_RATES.get(sell_id, {})
    sell_rate = sell_info.get('sell_rate', 1)

    deals = state.get('deals', [])
    if deals and abs(commission - 0.91) > 0.001:
        recalced = []
        for d in deals:
            try:
                profit, profit_pct, buy_cur, sell_cur = _calc_profit(
                    d['price_buy'], d['price_sell'],
                    buy_id, sell_id, buy_info, sell_info,
                    commission=commission
                )
                if profit > 0:
                    nd = dict(d)
                    nd['profit']        = int(profit)
                    nd['profit_pct']    = profit_pct
                    nd['total_profit']  = int(profit * d.get('count_buy', 1))
                    nd['buy_currency']  = buy_cur
                    nd['sell_currency'] = sell_cur
                    recalced.append(nd)
            except Exception:
                continue
        state = dict(state)
        state['deals'] = sorted(recalced, key=lambda x: x['total_profit'], reverse=True)

    # Apply plan profit limit
    profit_limit = None
    if plan == 'free':
        profit_limit = 150000
    elif plan == 'basic':
        profit_limit = 500000

    if profit_limit is not None and state.get('deals'):
        state = dict(state)
        state['deals'] = [d for d in state['deals'] if d.get('total_profit', 0) <= profit_limit]

    return jsonify({
        'success':      True,
        'buy_id':       buy_id,
        'sell_id':      sell_id,
        'buy_name':     buy_info.get('name',  f'Сервер {buy_id}'),
        'sell_name':    sell_info.get('name', f'Сервер {sell_id}'),
        'sell_rate':    sell_rate,
        'data':         state,
        'plan':         plan,
    })


@app.route("/api/market")
@login_required
def api_market():
    query     = request.args.get('q', '').strip().lower()
    server_id = int(request.args.get('server', 0))

    if not query:
        return jsonify({'success': False, 'error': 'Введите название товара'})

    lavki    = fetch_lavki()
    items_db = fetch_items_db()

    if not lavki:
        return jsonify({'success': False, 'error': 'Нет данных от маркета'})

    name_to_ids = {}
    for iid, name in items_db.items():
        if query in name.lower():
            name_to_ids[iid] = name

    if not name_to_ids:
        return jsonify({'success': True, 'buy_shops': [], 'sell_shops': [], 'matched_items': []})

    matched_item_names = sorted(set(name_to_ids.values()))
    server_lavki = [l for l in lavki if l.get('serverId') == server_id]
    buy_shops  = []
    sell_shops = []

    for l in server_lavki:
        lavka_uid = l.get('LavkaUid')
        if l.get('items_buy') and l.get('price_buy'):
            for idx, item_id in enumerate(l['items_buy']):
                iid = item_id if isinstance(item_id, int) else None
                if iid is None:
                    try:
                        iid = int(str(item_id).split('(')[0])
                    except Exception:
                        continue
                if iid in name_to_ids:
                    try:
                        price_raw = float(l['price_buy'][idx])
                        count     = int(l['count_buy'][idx]) if l.get('count_buy') else 0
                        buy_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     int(price_raw),
                            'count':     count,
                        })
                    except Exception:
                        continue

        if l.get('items_sell') and l.get('price_sell'):
            for idx, item_id in enumerate(l['items_sell']):
                iid = item_id if isinstance(item_id, int) else None
                if iid is None:
                    try:
                        iid = int(str(item_id).split('(')[0])
                    except Exception:
                        continue
                if iid in name_to_ids:
                    try:
                        price_raw = float(l['price_sell'][idx])
                        count     = int(l['count_sell'][idx]) if l.get('count_sell') else 0
                        sell_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     price_raw,
                            'count':     count,
                        })
                    except Exception:
                        continue

    return jsonify({
        'success':       True,
        'buy_shops':     buy_shops,
        'sell_shops':    sell_shops,
        'matched_items': matched_item_names,
        'server_id':     server_id,
        'query':         query,
    })


@app.route("/api/inventory")
@login_required
def api_inventory():
    return jsonify({'success': True, 'data': load_inventory()})


@app.route("/api/inventory-summary")
@login_required
def api_inventory_summary():
    resp = make_response(jsonify({'success': True, 'data': get_inventory_summary()}))
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma']        = 'no-cache'
    resp.headers['Expires']       = '0'
    return resp


@app.route("/api/search-items")
@login_required
def api_search_items():
    query = request.args.get('q', '').lower()
    try:
        items    = fetch_with_retry(ITEMS_URL, retries=2)
        filtered = [i for i in items if query in i.get('name', '').lower()]
        return jsonify({'success': True, 'items': filtered[:30]})
    except Exception:
        return jsonify({'success': False, 'items': []})


@app.route("/api/add-item", methods=["POST"])
@login_required
def api_add_item():
    try:
        data           = request.json
        item_name      = data.get('name', '')
        qty            = int(data.get('qty', 0))
        price_per_unit = int(data.get('price_per_unit', 0))
        if not item_name or qty <= 0:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name not in inventory:
            inventory[item_name] = {'qty': 0, 'entries': []}
        inventory[item_name]['qty'] += qty
        inventory[item_name]['entries'].append({
            'qty': qty, 'price_per_unit': price_per_unit,
            'seller': 'Admin', 'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        })
        with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(inventory, f, ensure_ascii=False, indent=2)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/delete-item", methods=["POST"])
@login_required
def api_delete_item():
    try:
        data      = request.json
        item_name = data.get('name', '')
        if not item_name:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name in inventory:
            del inventory[item_name]
            with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(inventory, f, ensure_ascii=False, indent=2)
            return jsonify({'success': True})
        return jsonify({'success': False, 'error': 'Item not found'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Авторынок ────────────────────────────────────────────────────────────────

def load_avtomarket():
    try:
        if os.path.exists(AVTOMARKET_FILE):
            with open(AVTOMARKET_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return []

def save_avtomarket(listings):
    with open(AVTOMARKET_FILE, 'w', encoding='utf-8') as f:
        json.dump(listings, f, ensure_ascii=False, indent=2)

@app.route("/api/avtomarket")
@login_required
def api_avtomarket_list():
    listings = load_avtomarket()
    resp = make_response(jsonify({'success': True, 'listings': listings}))
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma']        = 'no-cache'
    resp.headers['Expires']       = '0'
    return resp

@app.route("/api/avtomarket/add", methods=["POST"])
@login_required
def api_avtomarket_add():
    try:
        data = request.json
        model     = data.get('model', '').strip()
        price     = int(data.get('price', 0))
        server_id = int(data.get('server_id', 1))
        condition = int(data.get('condition', 100))
        contact   = data.get('contact', '').strip()
        ad_type   = data.get('ad_type', 'sell')
        note      = data.get('note', '').strip()
        if not model or price < 0:
            return jsonify({'success': False, 'error': 'Некорректные данные'})
        listings = load_avtomarket()
        listing = {
            'id':        str(uuid.uuid4())[:8],
            'model':     model,
            'price':     price,
            'server_id': server_id,
            'condition': max(0, min(100, condition)),
            'contact':   contact,
            'ad_type':   ad_type,
            'note':      note,
            'added_by':  session.get('username', ''),
            'added_at':  datetime.now().strftime('%Y-%m-%d %H:%M'),
        }
        listings.insert(0, listing)
        save_avtomarket(listings)
        return jsonify({'success': True, 'listing': listing})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route("/api/avtomarket/delete", methods=["POST"])
@login_required
def api_avtomarket_delete():
    try:
        listing_id = request.json.get('id', '')
        listings   = load_avtomarket()
        username   = session.get('username', '')
        creds      = load_creds()
        is_admin   = creds.get(username, {}).get('role', '') == 'admin'
        new_list   = [l for l in listings if l.get('id') != listing_id or (not is_admin and l.get('added_by') != username)]
        if len(new_list) == len(listings) and not is_admin:
            return jsonify({'success': False, 'error': 'Нет доступа'})
        save_avtomarket(new_list)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/auto_status")
@login_required
def api_auto_status():
    return jsonify({
        'scanner_running':   auto_scanner_running,
        'arbitrage_running': auto_arbitrage_running,
        'bd_running':        auto_bd_running,
        'arb_buy':           auto_arb_buy,
        'arb_sell':          auto_arb_sell,
    })


# ─── Balance ──────────────────────────────────────────────────────────────────

@app.route("/api/balance/add", methods=["POST"])
@login_required
def api_balance_add():
    try:
        data    = request.json
        amount  = data.get('amount')
        note    = data.get('note', '')
        if amount is None:
            return jsonify({'success': False, 'error': 'amount required'})
        amount  = int(amount)
        records = load_balance()
        record  = {'amount': amount, 'note': note,
                   'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                   'date': date.today().isoformat()}
        records.append(record)
        save_balance(records)
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/delete", methods=["POST"])
@login_required
def api_balance_delete():
    try:
        data    = request.json
        index   = data.get('index')
        records = load_balance()
        if index is None or index < 0 or index >= len(records):
            return jsonify({'success': False, 'error': 'Invalid index'})
        records.pop(index)
        save_balance(records)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/history")
@login_required
def api_balance_history():
    try:
        records     = load_balance()
        today       = date.today().isoformat()
        income_today, income_all = 0, 0
        if records:
            income_all  = records[-1]['amount'] - records[0]['amount']
            today_recs  = [r for r in records if r.get('date') == today]
            if len(today_recs) >= 2:
                income_today = today_recs[-1]['amount'] - today_recs[0]['amount']
            elif len(today_recs) == 1:
                prev = [r for r in records if r.get('date', '') < today]
                if prev:
                    income_today = today_recs[-1]['amount'] - prev[-1]['amount']
        return jsonify({'success': True, 'records': records,
                        'income_today': income_today, 'income_all': income_all})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Scan / toggle routes ─────────────────────────────────────────────────────

@app.route("/scan_scanner", methods=["POST"])
@login_required
def scan_scanner_route():
    username = session.get('username', '')
    user     = get_user_from_session()
    plan     = get_effective_plan(user)
    ok, remaining = check_scan_cooldown(username, plan, 'scanner')
    if not ok:
        m, s = divmod(remaining, 60)
        return jsonify({'status': 'cooldown', 'remaining': remaining,
                        'message': f'Следующий скан через {m}м {s}с'})
    mark_scan_done(username, 'scanner')
    threading.Thread(target=scan_scanner, daemon=True).start()
    write_log(username, 'scan_scanner')
    return jsonify({'status': 'started'})


@app.route("/scan_arbitrage", methods=["POST"])
@login_required
def scan_arbitrage_route():
    global auto_arb_buy, auto_arb_sell
    username = session.get('username', '')
    user     = get_user_from_session()
    plan     = get_effective_plan(user)
    ok, remaining = check_scan_cooldown(username, plan, 'arbitrage')
    if not ok:
        m, s = divmod(remaining, 60)
        return jsonify({'status': 'cooldown', 'remaining': remaining,
                        'message': f'Следующий скан через {m}м {s}с'})
    try:
        buy_id  = int(request.args.get('buy',  2))
        sell_id = int(request.args.get('sell', 0))
    except ValueError:
        buy_id, sell_id = 2, 0
    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))
    mark_scan_done(username, 'arbitrage')
    auto_arb_buy  = buy_id
    auto_arb_sell = sell_id
    threading.Thread(target=do_scan_arbitrage, args=(buy_id, sell_id), daemon=True).start()
    write_log(username, 'scan_arbitrage', f'buy={buy_id} sell={sell_id}')
    return jsonify({'status': 'started', 'buy': buy_id, 'sell': sell_id})


@app.route("/toggle_auto_scanner", methods=["POST"])
@login_required
def toggle_auto_scanner():
    global auto_scanner_running
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan != 'pro':
        return jsonify({'success': False, 'error': 'Автосканирование доступно только в тарифе Профи'})
    if auto_scanner_running:
        auto_scanner_running = False
        return jsonify({'status': 'stopped', 'scanner_running': False})
    else:
        auto_scanner_running = True
        threading.Thread(target=auto_scanner_loop, daemon=True).start()
        return jsonify({'status': 'started', 'scanner_running': True})


@app.route("/toggle_auto_arbitrage", methods=["POST"])
@login_required
def toggle_auto_arbitrage():
    global auto_arbitrage_running, auto_arb_buy, auto_arb_sell
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan != 'pro':
        return jsonify({'success': False, 'error': 'Автоарбитраж доступен только в тарифе Профи'})
    try:
        body    = request.get_json(silent=True) or {}
        buy_id  = int(body.get('buy',  auto_arb_buy))
        sell_id = int(body.get('sell', auto_arb_sell))
    except Exception:
        buy_id, sell_id = auto_arb_buy, auto_arb_sell
    auto_arb_buy  = buy_id
    auto_arb_sell = sell_id
    if auto_arbitrage_running:
        auto_arbitrage_running = False
        return jsonify({'status': 'stopped', 'arbitrage_running': False})
    else:
        auto_arbitrage_running = True
        threading.Thread(target=auto_arbitrage_loop, daemon=True).start()
        return jsonify({'status': 'started', 'arbitrage_running': True})


@app.route("/toggle_auto_bestdeals", methods=["POST"])
@login_required
def toggle_auto_bestdeals():
    global auto_bd_running
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan != 'pro':
        return jsonify({'success': False, 'error': 'Автосканирование топ-сделок доступно только в тарифе Профи'})
    if auto_bd_running:
        auto_bd_running = False
        return jsonify({'status': 'stopped', 'bd_running': False})
    else:
        auto_bd_running = True
        threading.Thread(target=auto_bd_loop, daemon=True).start()
        return jsonify({'status': 'started', 'bd_running': True})


@app.route("/api/best_deals")
@login_required
def api_best_deals():
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan not in ('pro',):
        return jsonify({'success': False, 'error': 'plan_required',
                        'message': 'Топ сделки доступны только в тарифе Профи'})
    return jsonify(get_bd_state())


@app.route("/scan_best_deals", methods=["POST"])
@login_required
def scan_best_deals_route():
    user = get_user_from_session()
    plan = get_effective_plan(user)
    if plan not in ('pro',):
        return jsonify({'success': False, 'error': 'Доступно только в тарифе Профи'})
    username = session.get('username', '')
    write_log(username, 'scan_best_deals')
    threading.Thread(target=do_scan_best_deals, daemon=True).start()
    return jsonify({'status': 'started'})


# ─── Admin routes ─────────────────────────────────────────────────────────────

@app.route("/api/admin/users")
@admin_required
def api_admin_users():
    creds = load_creds()
    users = []
    for u in creds.get('users', []):
        plan     = get_effective_plan(u)
        expires  = u.get('plan_expires')
        days_left = None
        if expires:
            try:
                exp_dt = datetime.fromisoformat(expires)
                days_left = max(0, (exp_dt - datetime.now()).days)
            except Exception:
                pass
        users.append({
            'username':     u.get('username'),
            'email':        u.get('email'),
            'role':         u.get('role', 'user'),
            'plan':         plan,
            'plan_raw':     u.get('plan', 'free'),
            'plan_expires': expires,
            'days_left':    days_left,
            'reg_date':     u.get('reg_date', '—'),
            'reg_ip':       u.get('reg_ip', '—'),
            'last_ip':      u.get('last_ip', '—'),
            'activated':    u.get('activated', True),
            'blocked':      u.get('blocked', False),
            'commission':   u.get('commission', 9),
            'user_server':  u.get('user_server', 2),
        })
    return jsonify({'success': True, 'users': users})


@app.route("/api/admin/grant_plan", methods=["POST"])
@admin_required
def api_admin_grant_plan():
    data     = request.json or {}
    username = data.get('username', '')
    plan     = data.get('plan', 'free')
    days     = int(data.get('days', 30))

    if plan not in ('free', 'basic', 'pro'):
        return jsonify({'success': False, 'error': 'Неверный тариф'})

    creds   = load_creds()
    updated = False
    for u in creds.get('users', []):
        if u.get('username') == username:
            u['plan'] = plan
            if plan == 'free':
                u['plan_expires'] = None
            else:
                u['plan_expires'] = (datetime.now() + timedelta(days=days)).isoformat()
            updated = True
            break

    if not updated:
        return jsonify({'success': False, 'error': 'Пользователь не найден'})

    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_grant_plan', f'user={username} plan={plan} days={days}')
    return jsonify({'success': True})


@app.route("/api/admin/codes")
@admin_required
def api_admin_codes():
    creds = load_creds()
    codes = []
    for c in creds.get('activation_codes', []):
        if isinstance(c, dict):
            codes.append(c)
        else:
            codes.append({'code': c, 'plan': 'basic', 'duration_days': 30})
    return jsonify({'success': True, 'codes': codes})


@app.route("/api/admin/codes/generate", methods=["POST"])
@admin_required
def api_admin_generate_code():
    data  = request.json or {}
    plan  = data.get('plan', 'basic')
    days  = int(data.get('duration_days', 30))
    code  = generate_code()
    creds = load_creds()
    creds.setdefault('activation_codes', []).append({
        'code': code, 'plan': plan, 'duration_days': days
    })
    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_generate_code', f'code={code} plan={plan} days={days}')
    return jsonify({'success': True, 'code': code, 'plan': plan, 'duration_days': days})


@app.route("/api/admin/codes/delete", methods=["POST"])
@admin_required
def api_admin_delete_code():
    data     = request.json or {}
    code_val = data.get('code', '').upper()
    creds    = load_creds()
    creds['activation_codes'] = [
        c for c in creds.get('activation_codes', [])
        if (c.get('code', '').upper() if isinstance(c, dict) else c.upper()) != code_val
    ]
    save_creds(creds)
    return jsonify({'success': True})


@app.route("/api/admin/log")
@admin_required
def api_admin_log():
    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                log = json.load(f)
        else:
            log = []
        return jsonify({'success': True, 'log': list(reversed(log[-500:]))})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/admin/users/edit", methods=["POST"])
@admin_required
def api_admin_edit_user():
    data       = request.json or {}
    username   = data.get('username', '')
    creds      = load_creds()
    updated    = False
    for u in creds.get('users', []):
        if u.get('username') == username:
            if 'email' in data and data['email']:
                u['email'] = data['email'].strip()
            if 'plan' in data and data['plan'] in ('free', 'basic', 'pro'):
                u['plan'] = data['plan']
                if data['plan'] == 'free':
                    u['plan_expires'] = None
                elif 'days' in data and int(data['days']) > 0:
                    u['plan_expires'] = (datetime.now() + timedelta(days=int(data['days']))).isoformat()
            if 'role' in data and data['role'] in ('user', 'admin'):
                u['role'] = data['role']
            if 'commission' in data:
                try:
                    u['commission'] = float(data['commission'])
                except Exception:
                    pass
            if 'user_server' in data:
                try:
                    u['user_server'] = int(data['user_server'])
                except Exception:
                    pass
            if 'password' in data and data['password']:
                u['password'] = data['password'].strip()
            updated = True
            break
    if not updated:
        return jsonify({'success': False, 'error': 'Пользователь не найден'})
    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_edit_user', f'user={username}')
    return jsonify({'success': True})


@app.route("/api/admin/users/activate", methods=["POST"])
@admin_required
def api_admin_activate_user():
    data     = request.json or {}
    username = data.get('username', '')
    creds    = load_creds()
    for u in creds.get('users', []):
        if u.get('username') == username:
            u['activated'] = not u.get('activated', True)
            save_creds(creds)
            admin = session.get('username', 'admin')
            write_log(admin, 'admin_activate_user', f'user={username} activated={u["activated"]}')
            return jsonify({'success': True, 'activated': u['activated']})
    return jsonify({'success': False, 'error': 'Пользователь не найден'})


@app.route("/api/admin/users/block", methods=["POST"])
@admin_required
def api_admin_block_user():
    data     = request.json or {}
    username = data.get('username', '')
    creds    = load_creds()
    for u in creds.get('users', []):
        if u.get('username') == username:
            if u.get('role') == 'admin':
                return jsonify({'success': False, 'error': 'Нельзя заблокировать администратора'})
            u['blocked'] = not u.get('blocked', False)
            save_creds(creds)
            admin = session.get('username', 'admin')
            write_log(admin, 'admin_block_user', f'user={username} blocked={u["blocked"]}')
            return jsonify({'success': True, 'blocked': u['blocked']})
    return jsonify({'success': False, 'error': 'Пользователь не найден'})


@app.route("/api/admin/users/delete", methods=["POST"])
@admin_required
def api_admin_delete_user():
    data     = request.json or {}
    username = data.get('username', '')
    creds    = load_creds()
    before   = len(creds.get('users', []))
    creds['users'] = [u for u in creds.get('users', []) if u.get('username') != username or u.get('role') == 'admin']
    if len(creds['users']) == before:
        return jsonify({'success': False, 'error': 'Пользователь не найден или является администратором'})
    save_creds(creds)
    admin = session.get('username', 'admin')
    write_log(admin, 'admin_delete_user', f'user={username}')
    return jsonify({'success': True})


@app.route('/api/arizona_map/<int:server_id>')
def arizona_map_api(server_id):
    if server_id < 1 or server_id > 32:
        return jsonify({'error': 'Server must be between 1 and 32'}), 400
    cache = {}
    if os.path.exists(MAP_CACHE_FILE):
        try:
            with open(MAP_CACHE_FILE, 'r', encoding='utf-8') as f:
                cache = json.load(f)
        except Exception:
            cache = {}
    try:
        resp = requests.get(
            f'https://n-api.arizona-rp.com/api/map/{server_id}',
            headers={
                'User-Agent': 'Mozilla/5.0 Route66Market/1.0',
                'Accept': 'application/json,text/plain,*/*',
            },
            timeout=35
        )
        resp.raise_for_status()
        data = resp.json()
        cache[str(server_id)] = {'saved_at': datetime.now().isoformat(), 'data': data}
        try:
            with open(MAP_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(cache, f, ensure_ascii=False)
        except Exception:
            pass
        return jsonify(data)
    except Exception as e:
        cached = cache.get(str(server_id), {}).get('data')
        if cached:
            return jsonify(cached)
        return jsonify({'error': str(e)}), 502


# ── Map object photos ──────────────────────────────────────────────────────
MAP_PHOTOS_DIR  = os.path.join('static', 'uploads', 'map_photos')
MAP_PHOTOS_JSON = os.path.join(MAP_PHOTOS_DIR, 'index.json')
os.makedirs(MAP_PHOTOS_DIR, exist_ok=True)

ALLOWED_PHOTO_EXT = {'jpg', 'jpeg', 'png', 'webp', 'gif'}

def _load_photo_index():
    try:
        with open(MAP_PHOTOS_JSON, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _save_photo_index(idx):
    with open(MAP_PHOTOS_JSON, 'w', encoding='utf-8') as f:
        json.dump(idx, f, ensure_ascii=False)

@app.route('/api/map_photo/<key>')
def api_get_map_photo(key):
    idx = _load_photo_index()
    fn  = idx.get(key)
    if not fn:
        return jsonify({'error': 'not found'}), 404
    return jsonify({'url': f'/static/uploads/map_photos/{fn}', 'key': key})

@app.route('/api/admin/map_photo', methods=['POST'])
@admin_required
def api_upload_map_photo():
    key  = request.form.get('key', '').strip()
    file = request.files.get('file')
    if not key or not file:
        return jsonify({'error': 'missing key or file'}), 400
    ext = (file.filename.rsplit('.', 1)[-1] if '.' in file.filename else '').lower()
    if ext not in ALLOWED_PHOTO_EXT:
        return jsonify({'error': 'unsupported file type'}), 400
    idx = _load_photo_index()
    # Remove old file if exists
    old_fn = idx.get(key)
    if old_fn:
        old_path = os.path.join(MAP_PHOTOS_DIR, old_fn)
        if os.path.exists(old_path):
            os.remove(old_path)
    fn   = f'{key}.{ext}'
    path = os.path.join(MAP_PHOTOS_DIR, fn)
    file.save(path)
    idx[key] = fn
    _save_photo_index(idx)
    return jsonify({'url': f'/static/uploads/map_photos/{fn}', 'key': key})

@app.route('/api/admin/map_photo/<key>', methods=['DELETE'])
@admin_required
def api_delete_map_photo(key):
    idx = _load_photo_index()
    fn  = idx.pop(key, None)
    if fn:
        path = os.path.join(MAP_PHOTOS_DIR, fn)
        if os.path.exists(path):
            os.remove(path)
        _save_photo_index(idx)
    return jsonify({'ok': True})


# ── Trash map ──────────────────────────────────────────────────────────────

def _load_trash_map():
    try:
        with open(TRASH_MAP_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
        return data.get('locations', [])
    except Exception:
        return []

def _save_trash_map(locations):
    with open(TRASH_MAP_FILE, 'w', encoding='utf-8') as f:
        json.dump({'locations': locations}, f, ensure_ascii=False, indent=2)

@app.route('/api/trash_map')
@login_required
def api_get_trash_map():
    locations = _load_trash_map()
    return jsonify({'ok': True, 'locations': locations, 'count': len(locations)})

@app.route('/api/trash_map/upload', methods=['POST'])
@admin_required
def api_upload_trash_map():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Файл не передан'}), 400
        f = request.files['file']
        if not f.filename.lower().endswith('.json'):
            return jsonify({'error': 'Разрешены только .json файлы'}), 400
        raw = json.load(f)

        # Normalise to flat list of {x, y, name} entries
        # Supported formats:
        #   1. Dict of groups: {"ModelName": [{model, name, pos:[x,y,z]}, ...], ...}
        #   2. Flat list:      [{x, y, name}, ...]
        #   3. Wrapped list:   {"locations": [...]} / {"points": [...]}
        flat = []
        if isinstance(raw, dict):
            # Check if it looks like grouped format (values are lists of objects with "pos")
            first_val = next(iter(raw.values()), None) if raw else None
            if isinstance(first_val, list):
                # Grouped format: {"ModelName": [{name, pos:[x,y,z]}, ...]}
                for group_name, entries in raw.items():
                    if not isinstance(entries, list):
                        continue
                    for entry in entries:
                        if not isinstance(entry, dict):
                            continue
                        pos = entry.get('pos')
                        if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                            flat.append({
                                'x':    pos[0],
                                'y':    pos[1],
                                'name': entry.get('name', group_name),
                            })
            else:
                # Wrapped list format
                inner = raw.get('locations', raw.get('points', raw.get('data', [])))
                if isinstance(inner, list):
                    flat = inner
        elif isinstance(raw, list):
            flat = raw
        else:
            return jsonify({'error': 'Неверный формат JSON'}), 400

        existing = _load_trash_map()
        existing_keys = set()
        for loc in existing:
            x = loc.get('x', loc.get('lx'))
            y = loc.get('y', loc.get('ly'))
            if x is not None and y is not None:
                existing_keys.add((round(float(x), 2), round(float(y), 2)))

        added = 0
        for item in flat:
            if not isinstance(item, dict):
                continue
            # Support both pos-array format and flat x/y format
            pos = item.get('pos')
            if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                x, y = pos[0], pos[1]
            else:
                x = item.get('x', item.get('lx', item.get('posX', item.get('pos_x'))))
                y = item.get('y', item.get('ly', item.get('posY', item.get('pos_y'))))
            if x is None or y is None:
                continue
            try:
                x, y = float(x), float(y)
            except (ValueError, TypeError):
                continue
            key = (round(x, 2), round(y, 2))
            if key in existing_keys:
                continue
            existing_keys.add(key)
            entry = {
                'id':   item.get('id', str(uuid.uuid4())[:8]),
                'x':    x,
                'y':    y,
                'name': item.get('name', item.get('label', item.get('title', 'Мусорка'))),
            }
            existing.append(entry)
            added += 1

        _save_trash_map(existing)
        write_log(session.get('username', '?'), 'trash_map_upload',
                  f'Добавлено {added} точек, всего {len(existing)}')
        return jsonify({'ok': True, 'added': added, 'total': len(existing)})
    except json.JSONDecodeError:
        return jsonify({'error': 'Ошибка разбора JSON'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trash_map/clear', methods=['POST'])
@admin_required
def api_clear_trash_map():
    _save_trash_map([])
    write_log(session.get('username', '?'), 'trash_map_clear', 'База мусорок очищена')
    return jsonify({'ok': True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
