# Road66

## Overview
Flask web application for Arizona RP market/arbitrage scanning and dashboard management.

## Tech Stack
- Python 3.11
- Flask 3.0.3
- Gunicorn (production WSGI server)
- Jinja2 templates with static CSS/JS
- SQLite databases (`average_prices.db`, `sync_data.db`) for price/trade data
- Local JSON files for inventory, balance, credentials, and settings

## Project Layout
- `app.py` — main Flask application (all routes, business logic)
- `run.py` — development launcher (binds to `0.0.0.0:5000`)
- `arbitrage_engine.py` — core arbitrage scanning logic
- `chatlog_scanner.py` — game chat log scanning utility
- `arbitrage_servers/` — per-server arbitrage scripts (server_1..32)
- `templates/` — Jinja2 HTML templates (`index.html`, `landing.html`)
- `static/` — CSS, JavaScript, and image assets
- `*.json` — local data files (inventory, balance, credentials, activity log, `sections.json` for admin section toggles, etc.)
- `*.db` — SQLite databases
- `road66.lua` — Lua sync script for in-game MoonLoader integration
- `attached_assets/` — logs, images, and auxiliary assets

## Runtime
- Development workflow: `python3 run.py` (named "Start application", port 5000, webview)
- Production command: `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`
- Web preview port: 5000
- Host: `0.0.0.0` (Flask serves any host header by default — works through Replit proxy)

## Deployment
- Target: VM (always-running, due to in-memory background threads for auto-scanning)
- Run: `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`
- Configured via Replit deployment system

## Replit Setup Notes
- Python 3.11 module installed
- Dependencies installed via pip: flask 3.0.3, gunicorn, requests 2.32.3
- The app starts background threads on import for auto-scanning, so VM deployment is required (not autoscale)

## Lua Sync Notes
- The in-game script creates `moonloader/ArzMarket/UsersInfo/trade_log.json` on startup
- Recognized trades are sent to `/api/sync/trades`
- `road66.lua` uses `lib.samp.events` for chat event capture
