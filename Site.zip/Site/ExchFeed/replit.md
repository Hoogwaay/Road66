# ARZscaner - Arizona Scanner v3.0

## Overview
A web-based arbitrage scanning tool for the Arizona RP GTA San Andreas Multiplayer server. Tracks currency rates, balances, and inventory across multiple arbitrage servers and provides a web interface for users to view this data.

## Architecture
- **Backend:** Python (Flask 3.0.3)
- **Frontend:** HTML/CSS/JavaScript (served via Flask templates)
- **Data Storage:** JSON files (no external database)

## Key Files
- `app.py` - Main Flask application with all routes and background workers
- `run.py` - Launcher script
- `arbitrage_engine.py` - Core arbitrage scanning logic
- `chatlog_scanner.py` - Chat log scanning component
- `arbitrage_servers/` - Individual server scripts (32 servers)
- `templates/` - Jinja2 HTML templates (index.html, landing.html)
- `static/` - CSS and JS assets
- `Data_Cred.json` - User credentials
- `balance.json`, `inventory.json`, `currencyrate.json` - App data files

## Running the Application
- **Development:** `python3 run.py` (serves on 0.0.0.0:5000)
- **Production:** `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`

## Dependencies
- Flask==3.0.3
- requests==2.32.3
- gunicorn

## Deployment
- Target: VM (uses threading and in-memory state)
- Port: 5000
