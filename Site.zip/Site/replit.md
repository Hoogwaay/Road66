# ARZscaner - Arizona Scanner v3.0

## Overview
A web-based arbitrage scanning tool for the Arizona RP GTA San Andreas Multiplayer server. Tracks currency rates, balances, and inventory across multiple arbitrage servers and provides a web interface for users to view and act on this data.

## Architecture
- **Backend:** Python (Flask 3.0.3) — serves both API and HTML via Jinja2 templates
- **Frontend:** HTML/CSS/JavaScript (served via Flask templates in `ExchFeed/templates/`)
- **Data Storage:** JSON files (no external database)
- **Concurrency:** Background threading for scanning tasks

## Project Layout
```
ExchFeed/               # Main application directory
├── app.py              # Main Flask app with all routes and background workers
├── run.py              # Dev launcher (python3 run.py)
├── arbitrage_engine.py # Core arbitrage scanning logic
├── chatlog_scanner.py  # Chat log scanning component
├── arbitrage_servers/  # 32 per-server Python scripts + __init__.py
├── templates/          # Jinja2 HTML templates (index.html, landing.html)
├── static/             # CSS and JS assets
│   ├── css/ (landing.css, style.css)
│   └── js/ (landing.js, main.js)
├── Data_Cred.json      # User credentials and activation codes
├── balance.json        # Player balances data
├── inventory.json      # Item inventories data
├── currencyrate.json   # Exchange rates data
└── requirements.txt    # Python dependencies
```

## Running the Application
- **Development:** `cd ExchFeed && python3 run.py` (serves on 0.0.0.0:5000)
- **Production:** `cd ExchFeed && gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`

## Dependencies
- Flask==3.0.3
- requests==2.32.3
- gunicorn

## Workflow
- Workflow "Start application" runs `cd ExchFeed && python3 run.py` on port 5000 (webview)

## External APIs
- `api.arz.market` — marketplace data
- `server-api.arizona.games` — item database and server info

## Notes
- Uses threading and in-memory state; designed for single-instance deployment
- All data stored as flat JSON files in ExchFeed/
